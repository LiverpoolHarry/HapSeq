use strict;
use warnings;
use lib 'path/lib/ensembl/ensembl/modules/';
use lib 'path/lib/ensembl/ensembl-variation/modules/';
use lib 'path/gatk/vcftools_0.1.7/lib/';
use Vcf;
use Bio::EnsEMBL::Registry;
use Bio::EnsEMBL::Variation::VariationFeature;


open(LOG, ">MissenseCountsAngusCow.txt") || die "MissenseCounts.txt $! \n"; 
print (LOG "File\tTotal Missense SNP in Scaffolds\tLinked Missense SNP in scaffolds\n");
# get registry
my $reg = 'Bio::EnsEMBL::Registry';
$reg->load_registry_from_db(-host => 'ensembldb.ensembl.org',-user => 'anonymous');
my $vfa = $reg->get_adaptor('cow', 'variation', 'variationfeature');
my $sa = $reg->get_adaptor('cow', 'core', 'slice');
my $transcript_adaptor =$reg->get_adaptor('cow', 'core','Transcript');
foreach my $chr (1..29){
#	if($chr == 8 || $chr ==10) {next}
	my $slice = $sa->fetch_by_region('chromosome', $chr);
	my @genes = @{ $slice->get_all_Genes() };
	my $i = 0;
	my %MissenseSnp; 
	my $interStart = 0;
	my $totalCount = 0;
	my $linkedMissense = 0;
	foreach my $gene (@genes){
		$i++;
        	my $start = $gene->start();
        	my $region = "Chr" . $chr . ":" . $start . "-" . $gene->end();;
		my $com = " ~/gatk/bcftools/bcftools/bcftools view --regions $region ../sih/vcfFiles/Chr$chr.ann.sort.vcf.gz | ~/gatk/bcftools/bcftools/bcftools query --format '" . "%CHROM %POS %INFO/Cons\n" . "'  | grep  missense";
		my @output = `$com`;
		my $count =0;
		my $prePos = 0;
		foreach my $out(@output){
			chomp($out);
			if($out =~ m/missense/){
				my @res = split(/\s+/,$out);
				if($prePos == 0){
					$prePos = $res[1];
					next;
				}	
				$MissenseSnp{"$prePos-$res[1]"} = 1;
				$count++;
				$prePos = $res[1];
			}
		}

		$totalCount += $count;
		if($count > 1){
			$linkedMissense += $count;
		}
	}
	print (LOG "Chr$i\t Count Genes\t$i\n");		
	print (LOG "Genes\t$totalCount\t$linkedMissense\n");


	my $search = "../targetCut/Chr$chr" . '_Scaffolds/ -name "*.gff3"';
	my @gff3files = `find $search`;
	foreach my $file (@gff3files){
		chomp($file);
		my $lib = substr($file,index($file,"Scaffolds")+10, rindex($file,"_") - index($file,"Scaffolds") - 10);
		#if($lib =~ m/^[0-9]/){next}
		open(IN, "<$file") || die "$file $!\n";
		$totalCount = 0;
		$linkedMissense = 0;
		while(<IN>){
			my @data = split(/\s+/);
			my $position = $data[0] . ":" . $data[3] . "-" . $data[4];

			my $com = " ~/gatk/bcftools/bcftools/bcftools view --regions $position ../sih/vcfFiles/Chr$chr.ann.sort.vcf.gz | ~/gatk/bcftools/bcftools/bcftools query --format '" . "%CHROM %POS %INFO/Cons\n" . "'  | grep  missense";
			my @output = `$com`;
			my $count =0;
			my $prePos = 0;
 			foreach my $out(@output){
				chomp($out);
				if($out =~ m/missense/){
					my @res = split(/\s+/,$out);
					if($prePos == 0){
						$prePos = $res[1];
						next;
					}
					if($MissenseSnp{"$prePos-$res[1]"}){	
						$MissenseSnp{"$prePos-$res[1]"}++;
						$count++;
					}
					$prePos = $res[1];
				}
			}
			$totalCount += $count;
			if($count > 1){
				$linkedMissense += $count;
			}
		}
		close(IN);
		print "$file $totalCount, $linkedMissense\n";
		print (LOG "$file\t$totalCount\t$linkedMissense\n");
		#last;
	}
	my %hapCounts;
	my %seperations;
	foreach my $key (sort  keys %MissenseSnp){
		$hapCounts{$MissenseSnp{$key}}++;
		my ($first, $second) = split(/-/,$key);
		my $sep = $second - $first;
		$seperations{$MissenseSnp{$key}} += $sep;
		#print(LOG "Chr$chr\t$key\t$MissenseSnp{$key}\n");
	}
	print(LOG "Number Of Times Haplotype Observed\tNumber of two SNP haplotypes\n");
	foreach my $key (sort {$a<=>$b}  keys %hapCounts){
		my $count = $key -1;
		my $mean = $seperations{$key}/$hapCounts{$key};
		print(LOG "$count\t$hapCounts{$key}\t$mean\n");
	}			
	
}
close(LOG);
			
