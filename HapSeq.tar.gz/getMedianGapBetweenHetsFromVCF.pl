use strict;
use warnings;

my @files = `ls ../sih/vcfFiles/*vcf.gz 2>&1 `;
	my %snpPos;
	my %snpCount;
	my %allele;
	my %library;
	my %all1;
	my %all2;
	my %all3;
	my %all4;
	my %all1c;
	my %all2c;
	my %all3c;
	my %all4c;
	my %coverageByAlleleCount;
	my %countCoverageByAlleleCount;
	my %coverageByLibraryCount;
	my %countCoverageByLibraryCount;
	my %posCumalative;
	my %posCount;
my $cumlativeCoverage = 0;
my $lineCount = 0;
my $outfile = "MeanMediansStdDevGapInterval.txt";
open(OUT, ">$outfile") || die "$outfile $!\n";
foreach my $file (@files){
 	print "File $file";
	#unless($file =~ m/Chr21/){next}
	chomp($file);
	my (@gaps, $sumOfGaps, $gapCount);
	my $prePos = 0;
        system "bgzip -df $file ";
	$file =~ s/\.gz$//;
	open (IN1, "<$file") || die "$file $!\n";
	while(<IN1>){
		if(m/^#/){next}
		chomp();
		my @data = split(/\t/,$_);
		if($prePos == 0){
			$prePos = $data[1];
			next;
		}
		else{
			my $gap = $data[1] - $prePos;
			push(@gaps, $gap);
			$gapCount++;
			$sumOfGaps += $gap;
			$prePos = $data[1];
		}
	}
	close(IN1);
	system ("bgzip -f $file");
	@gaps = sort {$b <=> $a} @gaps;
	my $median = 0;
	unless($gapCount){
		print(OUT "No gaps for $file\n");
		next;
	}
	my $mean = $sumOfGaps / $gapCount;
	my $sum = 0;
	my $target = $sumOfGaps /2; 
	my $sumOfSquares = 0;
	while($sum < $target){
		$median = pop(@gaps);
		$sum += $median;
		$sumOfSquares += ($median - $mean) * ($median - $mean); 
	}
	
	while($#gaps > 0){
                my $gap = pop(@gaps);
                $sumOfSquares += ($gap - $mean) * ($gap - $mean);
	}
	my $var = $sumOfSquares  / $gapCount;
	my $stdDev = sqrt($var);
	my $output =  "Total gap Length = $sumOfGaps\n";
	$output .= "Gap Count = $gapCount\n";
	$output .= "Mean gap length = $mean\n";
	$output .= "Median gap length = $median\n";
	$output .= "Standard deviation of gap length = $stdDev\n";
	print "$file \n $output";
	print (OUT "$file\n $output");

	
}
close(OUT);		 
