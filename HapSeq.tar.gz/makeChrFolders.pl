use strict;
use warnings;
use File::Copy;

my @files = `ls  ~/path/to/gff3/files/*.gff3 2>&1`;
my $chros = "_";
my $i = 0;
foreach my $longfile (@files){
#	print $longfile;
	chomp($longfile);
	my $file = substr($longfile,rindex($longfile,"/"));
	my $chr = substr($file, index($file, "_FC") +2, index($file, ".gff") - index($file, "_F") - 1);
	#my $chr = substr($file, 0, index($file, "") -1);
	unless($chros =~ m/$chr/){
		print "Chr $chr\n";
		$chros .= $chr . "_";
		mkdir(substr($chr,0,-1) . "_Scaffolds");
		print "mkdir " .  substr($chr,0,-1) . "_Scaffolds\n";
	}
	my $folder  = substr($chr,0,-1) . "_Scaffolds";
	move($longfile, "$folder$file");
	#print "move $longfile, $folder$file\n";
	$i++;
	#if($i > 10){last};
}
		
