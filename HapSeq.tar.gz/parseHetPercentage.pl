use strict;
use warnings;
my @queries =('heterozygote');
my $logfile = $ARGV[0];

foreach my $query (@queries){
	my @lines = `grep "$query" $logfile`;
	print "grep $query $logfile got $#lines lines\n";
	my $sum = 0;
	my $count = 0;
	foreach my $line (@lines){
		chomp($line);
		my @data = split(/\(|\)/,$line);
		#print "$data[1]\n";
		#print " $line\n";
		$sum += $data[1];
		$count++;
	}
	my $mean = $sum/$count;
	print "$query $mean\n";
}
