#!/usr/bin/perl
use strict;
use warnings;
use IO::Handle;
use File::Copy;
#Redirect error messages to log file
open ERROR,  '>', "PerlErrorLog.txt"  or die $!;
STDERR->fdopen( \*ERROR,  'w' ) or die $!;



#locations of folder containing  bamfiles
#path to directory with bamfiles for this job
my $bampath = "/path/";
#name of user account on linux
my $user = "user";
#reference indexed genome and reference fasta file the first must have been built from the second
my $refGenomePath = "/path/";
my $refGenomeFasta = "/path/name.fasta";
#path to working directory 
my $path = "/path/";
my $scratch = "/scratch/user/";

my @machines = ("machine02","machine03", "machine04", "machine05","machine06","machine07","machine08","machine09", "machine10", "machine11","machine13","machine14","machine16", "machine17","machine18","machine19","machine20", "machine21","machine22", "machine23","machine24","machine25","machine26", "machine27","machine28");
my @freeMachines = @machines;
my $gatkJobsPerMachine = 1;
#Job scheduling parameter
my $sleeptime = 100; #Time in seconds between checks on whether mapping run has finished if mapping is expected to take several hours then set this to say 1800 or 3600 

#Picard tools
my $picardPath = "/path/picard-tools-1.48/";

#GATK
my $gatk1 = "/path/GenomeAnalysisTK-1.1-3-g1f8fc4a/GenomeAnalysisTK.jar";
my $gatk2 = "/path/GenomeAnalysisTK-2.4-7-g5e89f01/GenomeAnalysisTK.jar";
#GATK Unified Genotyper snp calling parameters from http://www.broadinstitute.org/gsa/wiki/index.php/Unified_genotyper

#Heterozygosity

=pod You can use the --heterozygosity argument to change the expected heterozygosity value used to compute prior likelihoods for any locus. The default priors are:
        het = 1e-3
        P(hom-ref genotype) = 1 - 3 * het / 2
        P(het genotype) = het
        P(hom-var genotype) = het / 2 
        my $het = 1e-3;
        
        I tried this once and it complained
=cut

#Minimum Confidence Threshold

my $stand_call_conf = 30.0; #the minimum phred-scaled Qscore threshold to separate high confidence from low confidence calls. Only genotypes with confidence >= this threshold are emitted as called sites. A reasonable threshold is 30 for high-pass calling (this is the default).
my $stand_emit_conf =10.0; #the minimum phred-scaled Qscore threshold to emit low confidence calls. Genotypes with confidence >= this but less than the calling threshold are emitted but marked as filtered. The default value is 30. 

#Arguments Specifying Outputs
my $dataThreads = 4; #Number of threads each thread will require the amount of memory requested in $memory'
my $memory = "-Xmx4g";
my $GATKoutput =  "variants.vcf"; # will be prefixed by sample and chromosome number
my $sites_only = " "; #set to '-sites_only' to write just the sites (without genotypes) to the output VCF (i.e. just the first 8 columns).
my $out_mode = "EMIT_ALL_CONFIDENT_SITES"; #possible values are EMIT_VARIANTS_ONLY (the default), EMIT_ALL_CONFIDENT_SITES (include confident reference sites), or EMIT_ALL_SITES (any callable site regardless of confidence). 
my $gt_mode = "DISCOVERY";# specifies how to determine the alternate allele to use for genotyping; possible values are DISCOVERY (the default; the Unified Genotyper will choose the most likely alternate allele) or GENOTYPE_GIVEN_ALLELES (only the alleles passed in from a VCF rod bound to the name "alleles" will be used for genotyping).
my $glm = "BOTH"; #  specifies which class of variants to call. By default only SNPs are called, but one can state that only indels (-glm INDEL) or both (-glm BOTH) should be called.
my $deletions = 0.05; # specifies the maximum fraction of fastq with deletions spanning a locus tolerated by the genotyper (the genotyper won't make calls at loci with too many deletions). Default is 0.05.
my $debug_file = " ";  # specifies the output file used to print debugging information.Set to "-debug_file filename" to implement; 
my $metrics = " ";#  specifies the output file used to print various metrics about callability. Set to "-metrics filename" to implement;

#Arguments Describing Good Bases
    
my $min_base_quality_score = 17; #specifies the minimum base quality required to consider a base for calling. Default is 17.

#Arguments for Annotations

my $nsl = " "; # instructs the Genotyper not to calculate the SLOD.Set to "-nsl" to implement
# not valid in GATK2my $anotations  = '-A DepthOfCoverage -A AlleleBalance';#  tells the Genotyper to apply one or more annotations to variant calls (e.g. '-A DepthOfCoverage -A AlleleBalance' would include those 2 annotations); see the VariantAnnotator for more details.
my $groups = " " ; # instructs the Genotyper to apply one or more annotation interfaces/groups to variant calls (e.g. '-G Standard' would apply all annotations which implement the StandardAnnotation interface); see the VariantAnnotator for more details. 

#Miscellaneous

my $dcov = 50; #positions with more than this number of fastq will be disregarded recomended 

#Build set of chromosomes to break job up into for GATK
#Chromosome names must be exactly as they appear in reference fasta file
my @chr =("Chr1");
foreach my $i (2..29){
	my $chr = "Chr" . $i;
	push (@chr,$chr);
}
push (@chr,"ChrX");
#push (@chr,"ChrY");
@chr = ("Chr20","ChrX");
mergeAndGATK();		

###############################################
# Merge bam files and remove duplicates
sub mergeAndGATK{

	
	my $MergeSamFiles  = $picardPath . "MergeSamFiles.jar";
	my $MarkDuplicates  = $picardPath . "MarkDuplicates.jar";
	my $ValidateSamFile  = $picardPath . "ValidateSamFile.jar";
	my $SortSam  = $picardPath . 'SortSam.jar';
       	my @jobNames; #list of jobs for job control
	my @availableMachines = @machines;

	#Get list of BAM files to iterate over	
	my @testBamfiles = `ls $bampath*.bam | grep Chr`;
	my $removeCom = $path . "removeUninformativeSNPfromVCF.pl";
	my $i = 0;	
	my $destination = $path . ".";
	foreach my $chr (@chr){
		print "Starting $chr with $#testBamfiles bamfiles\n";
		my @chrBamfiles;
		my $gatkcommand ="mkdir -p $scratch
				 cd $scratch
				  cp $path/$chr.list . \n";
		my $inputList = $path . $chr . ".list";
		open(OUT, ">$inputList") || die "$inputList $!\n";
		foreach my $bamfile (@testBamfiles){
			chomp($bamfile);
			if($bamfile =~ m/$chr(_1)*\.bam/){
				my $scratchBam = $bamfile;
				$scratchBam = $scratch . substr($bamfile,rindex($bamfile,"/") +1);
				$gatkcommand .= "cp $bamfile $scratchBam \n";	
				$gatkcommand .= "cp $bamfile.bai $scratchBam.bai \n";	
				print (OUT "$scratchBam\n");
				push(@chrBamfiles,$scratchBam);
			}
		}
		close(OUT);
		my $gatkInfiles = " -I " . join(", -I ", @chrBamfiles);
		my $gatkOutput = $scratch . "merged." . $chr . ".vcf";
		my $logfile = $path . $chr . "_log.txt";	
		print "Log $logfile; Output $gatkOutput\n";
		# build shell script
		$gatkcommand .=
				
			"#Call GATK unified genotyper for SNP and indel calling
			
			java $memory -jar $gatk2 -R $refGenomeFasta -T UnifiedGenotyper --input_file $inputList -o $gatkOutput -nt $dataThreads  -stand_call_conf $stand_call_conf -stand_emit_conf $stand_emit_conf -dcov 50   -glm $glm  --min_base_quality_score $min_base_quality_score  -L  $chr -deletions $deletions -out_mode $out_mode -gt_mode $gt_mode $sites_only $debug_file $metrics $groups  &> $logfile
			
                        #zip and index file
                        bgzip $gatkOutput
                        tabix -f -p vcf $gatkOutput.gz

			cp $removeCom removeUninformativeSNPfromVCF.pl
			perl removeUninformativeSNPfromVCF.pl $chr
			mv $scratch$chr.vcf.gz $path$chr.vcf.gz 
			mv $scratch$chr.vcf.tbi $path$chr.vcf.tbi			
			rm $scratch*bam* 
			#rm $inputList
		";

	        #Write shell script to file and start a seperate screen for each chromosome
                my $shellfile = "run_" .  $chr . "GATK.sh";
                my $machine =shift(@freeMachines);
                my $com =  "screen -dm -S Screen$chr ssh $machine nice bash $path$shellfile &> $chr.errors.txt";
                print "$com\n";

                open (SH, ">$shellfile") || die "$shellfile  $!\n";
                print (SH "#$com\n\n");
                print (SH $gatkcommand );
                close(SH);
                system "echo $com | tee $logfile";
                system "chmod 755 $shellfile";
                system $com;
                $i++;

                @freeMachines = @{countScreens(\@machines, $gatkJobsPerMachine)};
                sleep(100);
		
	}
}
###############################################
sub name{
	my $names = shift;
	my @names =@{$names};
	my $flag = "false";
	my $start = time;
	my $teststring = "XXXXX";
	while(length($teststring) > 1){
			
		 
		#get list of jobs in screens for user and 
		#add those that match files in @rootNames to list of running jobs
		#keep iterating until list of running jobs is empty
		system "ps -ef | grep SCREEN | grep $user  > screenLog.txt";
		$teststring = " ";
		open (LOG, '<screenLog.txt') || die "screenLog.txt $!\n";
		my $l = 0;
		my $completeProcesses = " ";
		while(<LOG>){	 
			 my $line = $_;
			 foreach my $name (@names){
				if($line =~ m/$name/){	
					$teststring .= $name;
					$completeProcesses .=  "$name; ";
					$l++;
				}
			}
				
		 }
		close(LOG);
		if(length($teststring) > 2){
			sleep($sleeptime);
		}
	 }
 
}
#################################################################
#Started shell scripts in independent screens now monitor them until they finish before running merge
sub countScreens{
        my $names = shift;
        my $jobsPerMachine = shift;
        my @names =@{$names};
        my $flag = "false";
        my $start = time;
        my $l = 0;
        my @fMachines;#free machines
        #an earlier version checked for the presence of file names because machines might have other SCREENS running
        #that are not generated by this script. However it seems better to take that risk and increase confidence
        #of assigning jobs to the correct machine
        while($flag eq "false"){
                        #get list of jobs in screens for user and 
                        #add those that match files in @rootNames to list of running jobs
                        #keep iterating until list of running jobs is empty
                        system "ps -ef | grep SCREEN | grep $user | grep machine > screenLog.txt";
                        my $teststring = " ";
                        open (LOG, '<screenLog.txt') || die "screenLog.txt $!\n";
                        my $l = 0;
                        my @runningProcesses;
                        while(<LOG>){
                                 my $line = $_;

                                 foreach my $mac (@machines){
                                        if($line =~ m/$mac/){
                                                $teststring .= $mac;
                                                push (@runningProcesses, $mac);
                                                $l++;
                                        }
                                }
                         }
                        close(LOG);
                        my $elapsed = time - $start;
                        #print " Waiting for  $l machines still running: $teststring  time so far $elapsed s\n"; #for debugging
                        if($#runningProcesses >= $#machines * $jobsPerMachine){
                                sleep(60);
                        }
                        else{
                                $flag = "true";
                        }
                        #get next free machine
                        foreach my $mac (@machines){
                                my $countProcessesOnMachine = $teststring =~ s/$mac/$mac/g;
                                if($countProcessesOnMachine < $jobsPerMachine){
                                        foreach ($countProcessesOnMachine ..$jobsPerMachine - 1){
                                                push(@fMachines, $mac);
                                        }
                                }
                        }
        }
        return(\@fMachines);
}
