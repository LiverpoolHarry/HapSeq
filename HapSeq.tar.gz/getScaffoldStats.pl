use strict;
use warnings;

my @files = `ls *filtered.gff3 `;

my $maxScaff = 0;
my $totalScaff = 0;
my $scaffCount = 0;
my @scaffLengths;
my $fileCount = 0;
my $maxFile = "XX";
foreach my $file (@files){
	chomp($file);
	open (IN, "<$file") || die "$file $!\n";
	while (<IN>){
		my @data = split(/\s+/);
		my $length = $data[4] - $data[3] + 1;
		if($length > $maxScaff){
			$maxScaff = $length;
			$maxFile = $file;
		}
		$totalScaff += $length;
		$scaffCount++;
		push(@scaffLengths,$length);
	}
	close(IN);
	$fileCount++;
}
print "Processed $fileCount files\n";
my @sortedScaffs = sort {$a<=>$b} @scaffLengths;
my $runTot = 0;
my $target = $totalScaff/2;
my $N50 =0;
my $i =0;
while ($runTot < $target){
	$runTot += $sortedScaffs[$i];
	$i++;
}
my $mean = $totalScaff / $scaffCount;
print "Mean scaff length = $mean\n";
print "Max scaff length = $maxScaff in file $maxFile\n";
print "N50 scaff length = $sortedScaffs[$i-1]\n";
print "Total scaff length = $totalScaff\n";

