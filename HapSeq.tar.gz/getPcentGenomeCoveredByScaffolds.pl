use warnings;
use strict;

my $outfile = $ARGV[0];
my $chr = $ARGV[1];
my $search = $ARGV[2];
#print "Outfile = $outfile\n";
open(OUT, ">>$outfile") || die "$outfile $!\n";
print(OUT "Chr\tGap\tLength Of Chr\tProp Chr Not Covered By Scaffolds\n");
close(OUT);
my %hist;
my $histfile = substr($outfile,0,-3) . "Histogram.txt";
getGap($chr);
#printHist();

###########################
sub getGap{
my $chr = shift;	
my @files = `ls $search`;
my %scaffs;
my @ends;
foreach my $file (@files){
	open(IN, "<$file") || die "$file $!\n";
	while(<IN>){
		my @data = split(/\t/);
		if($scaffs{$data[3]}){
			if($scaffs{$data[3]} < $data[4]){
				$scaffs{$data[3]} = $data[4];
			}
		}
		else{
			$scaffs{$data[3]} = $data[4];
		}
		$hist{int(log($data[4] -$data[3]))}++;
	}
}
my @starts = sort {$a<=> $b} keys %scaffs;
my $maxend = $scaffs{$starts[0]};
my $gap;
foreach my $i (1..$#starts){
	if($maxend < $starts[$i]){
		$gap += $starts[$i] - $maxend;
	}
	if($maxend < $scaffs{$starts[$i]}){
		$maxend = $scaffs{$starts[$i]};
	}
}
my $propNotCovered = $gap/$maxend;
open(OUT, ">>$outfile") || die "$outfile $!\n";
print "$chr\t$gap\t$maxend\t$propNotCovered\n";
print (OUT "$chr\t$gap\t$maxend\t$propNotCovered\n");
close(OUT);
	
}
####################################                                                                                                 
sub printHist{                                                                                                                       
        open(OUT, ">$histfile") || die "$histfile $!\n";                                                                             
        my @lengths = sort {$a<=> $b} keys %hist;                                                                                    
        foreach my $len (@lengths){                                                                                                  
                print(OUT "$len\t$hist{$len}\n");                                                                                    
        }                                                                                                                            
        close(OUT);                                                                                                                  
                                                                                                                                     
}   
