use strict;
use warnings;
use Cwd;

#get files in current working directory
#my $dir = getcwd;
#opendir DIR, $dir or die "cannot open dir $dir: $!";
my @files = `ls *phase  2>&1 `;
# @files = `ls Chr1.prop.phase 2>&1 `;
#closedir DIR;
my $quantileLength = 20000;
my $outfile = "HaplotypeSummaryStatsProps.txt";
open (OUT, ">$outfile") || die "$!\n";
print (OUT "File\tChromosome Length\tSum of haplotye lengths\tCount haplotypes\tMean haplotype length\tFirst haplotype length above median\tLast haplotype length below median\tProportion of haplotypes <= median haplotype length\tMax haplotype length\t Proportion in Haplotype Blocks\tProportion of haps under $quantileLength\n"); 
close (OUT); 
my $haplotypelengthThreshold = 1000;
my $logfile = "PhasedChroProp.txt";
unlink($logfile);
my $prestart = 0;
foreach my $file (@files){
		$file = substr($file,0,-1);
        if($file =~ m/phase$/){
		my $prestart = 0;
		my $maxHapLength = 0;
		my $totalLength =0;
		my $hapLengthOverThreshold = 0;
		my $prestend = 0;
		my %blocks;
		my $chr = substr($file, 0, index($file,'.'));
		my $length = 0;
		my $end = 0;
		my $flag = 1;
		my $out = $chr . "reduced.phase";
		my $out2 = $chr . "gff3";
		open (OUT, ">$out") || die "$out $!\n";
		open (OUT2, ">$out2") || die "$out $!\n";
		open(IN, "<$file") || die "$!\n";
		while(<IN>){
			if(m/^BLOCK/ ){
				chomp();	
				my @data = split(/\s+/,$_);
				if($data[6] < 2){
					next;
				}
				$length = $data[4];
				$totalLength += $length;
				if($blocks{$length}){
					$blocks{$length}++;
				}
				else{
					$blocks{$length} = 1;
				}
				if($length > $haplotypelengthThreshold){
					$hapLengthOverThreshold += $length;
				}
				if($maxHapLength < $length){
					$maxHapLength = $length;
				}
				$end = $data[2] + $data[4];
				print(OUT2 "$chr\tphase\t.\t$data[2]\t$end\t.\t.\t.\t.\n");	
			}
			unless(m/\s+-\s+-/){
				print (OUT $_);
			}
		}

		close (OUT);
		close (OUT2);
		close (IN);
		unlink ($file);
		my @sorted = sort { $a <=> $b } keys %blocks ;

		my $medianLength = 0;
		my $i = 0;
		my $blockKey;
		while($medianLength < $totalLength / 2){
			$blockKey = $sorted[$i];
			$medianLength += $blockKey * $blocks{$blockKey};
			$i++;
		}
		my $medianBlockLength = $blockKey;
		my $submedianBlockLength = $sorted[$i -2];
		my $runningTotal = 0;
		my $currentLength;
		$i = 0;
		while($currentLength <$quantileLength){
			$blockKey = $sorted[$i];
			$runningTotal += $blockKey * $blocks{$blockKey};
			$currentLength = $blockKey;
			$i++;
		}
		my $propUnderQuantileLength = $runningTotal / $totalLength ;
		$submedianBlockLength =~ s/(\d)(?=(\d{3})+(\D|$))/$1\,/g;
		$medianBlockLength =~ s/(\d)(?=(\d{3})+(\D|$))/$1\,/g;
		$medianLength = $medianLength/ $totalLength;
		$medianLength = sprintf("%.3f",$medianLength);
		my $meanHapLength = int($totalLength / $#sorted);
		$meanHapLength =~ s/(\d)(?=(\d{3})+(\D|$))/$1\,/g;
		$hapLengthOverThreshold =~ s/(\d)(?=(\d{3})+(\D|$))/$1\,/g;
		my $ratio = $totalLength / $end;
		$ratio = sprintf("%.3f",$ratio);
		$length =~ s/(\d)(?=(\d{3})+(\D|$))/$1\,/g;
		$totalLength =~ s/(\d)(?=(\d{3})+(\D|$))/$1\,/g;
		$end =~ s/(\d)(?=(\d{3})+(\D|$))/$1\,/g;
		open (OUT, ">>$outfile") || die "$!\n";
		print (OUT "$file\t$end\t$totalLength\t$#sorted\t$meanHapLength\t$medianBlockLength\t$submedianBlockLength\t$medianLength\t$maxHapLength\t$ratio\t$propUnderQuantileLength\n");
		close (OUT);
		print "File $file; End = $end; Sum of haplotye lengths = $totalLength; Sum of haplotype lengths over $haplotypelengthThreshold) = $hapLengthOverThreshold; Count haplotypes = $#sorted; Mean hap length = $meanHapLength; Median haplotype length = $medianBlockLength; Sub median haplotype length = $submedianBlockLength; Proportion <= median haplotype length = $medianLength; Max haplotype length = $maxHapLength; Proportion in Haplotype Blocks = $ratio; Proportion of haps under $quantileLength = $propUnderQuantileLength\n";
	}
}
  
				
			
