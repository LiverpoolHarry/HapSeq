use strict;
use warnings;
my $chr = $ARGV[0];
my $search = $chr . "_*.gff3";
my @files = `ls $search  | grep -v filtered `;
print "Found $#files files\n";
my %libraryCounts;
my %libraries;
my %Counts;
foreach my $file (@files){
	getMean(\%Counts, $file);
}
open (OUT, ">>Distances.txt") || die "Distances.txt $!\n"; 

my $meanDist = $Counts{"dist"} / $Counts{"length"};
print (OUT "$chr\tMean Cell Distance = $meanDist\n");
print ( "$chr\tMean Distance = $meanDist\n");
my $meanDiff = $Counts{"diff"} / $Counts{"length"};
print (OUT "$chr\tMean Cell Switch Diff = $meanDiff\n");
print ("$chr\tMean Switch Diff = $meanDiff\n");
my @keys =  (sort  keys %libraryCounts);
my $k = 0;
while($k < $#keys){
	print(OUT"$chr\tCount $keys[$k] = $libraryCounts{$keys[$k]}\n");
	print(OUT"$chr\tLength $keys[$k+3] = $libraryCounts{$keys[$k+3]}\n");
	my $mean = $libraryCounts{$keys[$k+1]} / $libraryCounts{$keys[$k+3]};
	print(OUT"$chr\tMean Switch Diff $keys[$k+1] = $mean\n");
	$mean = $libraryCounts{$keys[$k+2]} / $libraryCounts{$keys[$k+3]};
	print(OUT"$chr\tMean Dist $keys[$k+2] = $mean\n");
	$k +=4;
}
	
close(OUT);
##########################
sub getMean{
	my $counts = shift;
	my $file = shift;
	open (IN, "<$file") || die "$file $!\n";
	my @names = split(/_+/, $file);
	while(<IN>){
		my @line = split(/\s+/,$_);
		my @dist = split(/;/,$line[8]);
		my ($junk, $dist) = split(/=/,$dist[0]);
		if($dist < 0){next}
		my ($jun, $diff) = split(/=/,$dist[1]);
		my ($ju, $length) = split(/=/,$dist[2]);
		if($dist <0){next}
		$counts->{"dist"} += ($dist) * $length;
		$counts->{"diff"} += ($diff) * $length;
		$counts->{"count"}++; 
		$counts->{"length"} += $length;
		$libraryCounts{"$names[1]_dist"} += ($dist) * $length;
		$libraryCounts{"$names[1]_diff"} += ($diff) * $length;
		$libraryCounts{"$names[1]_count"}++; 
		$libraryCounts{"$names[1]_length"} += $length;
		$libraryCounts{"$names[2]_dist"} += ($dist) * $length;
		$libraryCounts{"$names[2]_diff"} += ($diff) * $length;
		$libraryCounts{"$names[2]_count"}++; 
		$libraryCounts{"$names[2]_length"} += $length;
	}
	close(IN);
#	return $counts;
}
