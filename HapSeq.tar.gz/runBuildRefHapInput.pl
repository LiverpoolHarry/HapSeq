use strict;
use warnings;
my $path = "/path/to/working/directory/";
my @machines = ("machine02", "machine01","machine03","machine04", "machine05","machine06",  "machine08", "machine09","machine10", "machine11", "machine12","machine13","machine14","machine15","machine18", "machine17","machine18","machine19", "machine20","machine21",  "machine23", "machine24","machine25", "machine26", "machine27","machine28");
my @chros= ("Chr1");
foreach my $c (2..29){
	push(@chros, "Chr" . $c);
}
#push(@chros, "ChrX");
#command for running SIH
my $jar = "java  -Xmn4g -cp  ~/path/to/SingleIndividualHaplotyper.jar mpg.molgen.sih.main.SIH -v ";
my $i = 0;
my $vcftools =  "/path/to/vcftools_0.1.7/bin/";
my $ScaffoldsGapsFile = "LengthsOfGapsbetweenScaffolds.txt";
unlink($ScaffoldsGapsFile);
unlink("Distances.txt");
#libraries can be excluded from the SIH analysis. Libraries prepared from bulk genome DNA to use as refenece should be excluded. Library names should be exactly as htey appear in hte VCF file 
my $exclude = " ";
#my $exclude = "exclude78118 exclude=s46";
#my $exclude = "exclude=A1_ exclude=A2_ exclude=A3_ exclude=A4_ exclude=A5_ exclude=A6_ exclude=B1_ exclude=B2_ exclude=B3_ exclude=B4_ exclude=B5_ exclude=B6_ exclude=C1_ exclude=C2_ exclude=C3_ exclude=C4_ exclude=C5_ exclude=C6_ exclude=D1_ exclude=D2_ exclude=D3_ exclude=D4_ exclude=D5_ exclude=D6_ exclude=E2_ exclude=E3_  exclude=E4_ exclude=E5_ exclude=E6_ exclude=F1_ exclude=F2_ exclude=F3_ exclude=F4_ exclude=F5_ exclude=F6_ exclude=G1_ exclude=G3_ exclude=G4_ exclude=G5_ exclude=G6_ exclude=H1_ exclude=H2_ exclude=H3_ exclude=H4_ exclude=H5_ exclude=H6_ exclude=E1_";
#my $exclude =  "exclude=10_ exclude=150_ exclude=23_ exclude=24_ exclude=2_ exclude=30_ exclude=31B_ exclude=34_ exclude=37_ exclude=49_ exclude=50_ exclude=63_ exclude=64_ exclude=68_ exclude=69_ exclude=6_ exclude=74_ exclude=76_ exclude=83_ exclude=88_ exclude=90B_";
foreach my $chr (@chros){
	$i++;
	my $logfile = "$chr.log.txt";
	#Before running this script all input gff3 files have been moved into a directory with a anme like ChrN_Scaffolds
	my $machineNo = $i % $#machines; 
	my $fileList = $chr . "_Scaffolds.txt";
	my $dir = $chr . "_Scaffolds";
	my $search = "$chr.gff3";
	#$fileList has a llist of gff3 fiels to be procesed by BuildRefHapInput.jar 
	system "ls $dir/$search > $fileList";
	my $gff3file = "/path/to/directory/with/gff3/files/$dir";
	my $com = "java -Xmn8g -jar BuildRefHapInput.jar chr=$chr vcftools=$vcftools minConsistency=0.9 gff3path=$gff3file writeTables=true fileList=$fileList vcfpath=/path/to/vcf/file/new$chr.vcf.gz $exclude >> $logfile 2>&1";
	print "$com\n";
	open(OUT, ">$logfile") || die "$logfile $!\n";
	print(OUT "$com\n");
	close(OUT);
	system $com;
	print "perl getConsistentProp2.pl $chr $suffix.Distances.txt '$chr$Fosmidsearch1' >> $logfile 2>&1\n";
	system "perl getConsistentProp2.pl $chr $suffix.Distances.txt '$chr$Fosmidsearch1' >> $logfile 2>&1";
	print "perl getPcentGenomeCoveredByScaffolds.pl $ScaffoldsGapsFile $chr '$Fosmidsearch2$chr.filtered.gff3' >> $logfile 2>&1 \n";
	system "perl getPcentGenomeCoveredByScaffolds.pl $ScaffoldsGapsFile $chr '$Fosmidsearch2$chr.filtered.gff3' >> $logfile 2>&1";

	my $tar = $chr . "_*.gff3"; 
	unlink ("$chr$suffix.gff3.tar.gz $tar");
	system " tar -zcf $chr$suffix.gff3.tar.gz $tar"; 
	print " tar -zcf $chr$suffix.gff3.tar.gz $tar\n"; 
	my @files = `ls $tar`;
	my $deletedCount = 0;
	foreach my  $file (@files){
		chomp($file);
		$deletedCount += unlink($file);
	}
	print "Deleted $deletedCount files\n";
	my $frag = "$path$chr" . ".frags";
        my $allvars = "$path$chr" . ".allvars";;
        my $outfile = "$path$chr" . "$suffix.phase";
        my $command = $jar .  $allvars . " " . $frag . " " . $outfile . " > SIHBreakAtHetslog$chr.$suffix.txt 2>&1";
        print "$command\n";
        system $command;
        sleep(100);
}
system "perl getHapBlockSummary.pl";
##################################


