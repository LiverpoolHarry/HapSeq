use strict;
use warnings;
use lib 'path/gatk/vcftools_0.1.7/lib/';
use Vcf;

#my $vcffile = $ARGV[0];
my %counts;
my %annotCount;

foreach my $chr (1..29){
if($chr == 8){next}
my $vcffile = "../sih/vcfFiles/Chr$chr.ann.sort.vcf.gz";
print "Processing $vcffile\n";

my $vcf = Vcf->new(file=>$vcffile);#, region=>'24:1-10000');#, region=>$region);
$vcf->parse_header();

  while (my $x=$vcf->next_data_array()){
 	if($$x[7] =~ m/Cons/){
		for my $field (split(/;/, $$x[7])){
			my ($key, $annot) = split(/=/,$field);
			if($key eq "Cons"){
				if($annot =~ m/:/){
					my @cons = split(/:/,$annot);
					foreach my $con (@cons){
						$counts{$con}++;
					}
					$annotCount{$#cons + 1}++;
				}else{
					$counts{$annot}++;
					$annotCount{1}++;
				}
			}
		}
	}
}
}
my $outfile = "ConsequenceCounts.txt";
open (OUT, ">$outfile") || die "$outfile\n";
foreach my $k (keys %counts){
	print "$k\t$counts{$k}\n";
	print (OUT "$k\t$counts{$k}\n");
}
print "Numbers of annotations\n";
foreach my $k (sort {$a<=>$b} keys %annotCount){
	print "$k\t$annotCount{$k}\n";
	print (OUT "$k\t$annotCount{$k}\n");
}
close(OUT);
