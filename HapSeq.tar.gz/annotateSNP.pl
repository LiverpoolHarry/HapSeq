use strict;
use warnings;
use Cwd;
use lib 'path/lib/ensembl/ensembl/modules/';
use lib 'path/lib/ensembl/ensembl-variation/modules/';
use lib 'path/gatk/vcftools_0.1.7/lib/';
use Vcf;
use Bio::EnsEMBL::Registry;
use Bio::EnsEMBL::Variation::VariationFeature;


my $vcffile = $ARGV[0];
my $chr = $ARGV[1];
system "tabix -f -p vcf $vcffile";
# get registry
my $reg = 'Bio::EnsEMBL::Registry';
$reg->load_registry_from_db(-host => 'ensembldb.ensembl.org',-user => 'anonymous');

my $vfa = $reg->get_adaptor('cow', 'variation', 'variationfeature');
my $sa = $reg->get_adaptor('cow', 'core', 'slice');
my $transcript_adaptor =$reg->get_adaptor('cow', 'core','Transcript');
my $slice = $sa->fetch_by_region('chromosome', $chr);
my @genes = @{ $slice->get_all_Genes() };
my $region = $chr . ":10-" . 100;
my $vcf = Vcf->new(file=>$vcffile);#, region=>'24:1-10000');#, region=>$region);
$vcf->parse_header();
my $i = 0;
my $outfile = $vcffile;
$outfile = substr($outfile,0,-6) . "annotated.vcf";
unlink($outfile);
system "zcat $vcffile | head -500 | grep ^#  > $outfile";
#Add INFO and FORMAT definitions for new INFO fields to header
annoatateHeader();
open (OUT, ">>$outfile") || die "$outfile\n";
my $interStart = 0; 
foreach my $gene (@genes){
        my $start = $gene->start();
	my $interEnd = $start -1;
	$region = "Chr" . $chr . ":" . $interStart . "-" . $interEnd;
	$vcf->open(region=>$region);
	while (my $x=$vcf->next_data_array()){
		print (OUT join("\t",@$x)."\n");
	}
        my $end = $gene->end();

	$region = "Chr" . $chr . ":" . $start . "-" . $end;
	$vcf->open(region=>$region);
	annotateSNP($vcf, $gene);
	$interStart = $end + 1;
        $i++;
        if($i % 100 == 0){
		my $ensId = $gene->stable_id();
		print "$i Chr$chr $ensId, $start\n";
	}
	sleep(5);
}
my $interEnd = 300000000;
$region = "Chr" . $chr . ":" . $interStart . "-" . $interEnd;
$vcf->open(region=>$region);
while (my $x=$vcf->next_data_array()){
      print (OUT join("\t",@$x)."\n");
}
    
close(OUT);
system "bgzip -f $outfile";
system "(zcat $outfile.gz | head -500 | grep ^#; zcat $outfile.gz | grep -v ^# | sort -k1,1d -k2,2n;) | bgzip -c > ../sih/vcfFiles/Chr$chr.ann.sort.vcf.gz";
unlink("$outfile.gz");
system "tabix -p vcf ../sih/vcfFiles/Chr$chr.ann.sort.vcf.gz";
#####################################
sub annotateSNP{
    my $vcf = shift;
    my $gene = shift;
    # This will split the fields and print a list of CHR:POS
    while (my $x=$vcf->next_data_array()) 
    {
	#print "chr $$x[0], pos $$x[1], ref $$x[3], alt $$x[4]";
	if(length($$x[4]) == 1 && length($$x[3]) == 1){
		my %h = ("chr"=>$$x[0],"pos"=>$$x[1],"ref"=>$$x[3],"alt"=>$$x[4]);
		my $consequences = getConsequence(\%h);
		if($gene->external_name()){
			my $desc =$gene->description();
			if($desc){
				$desc =~ s/\s/_/g;
				$desc =~ s/\'/prime/g;
		       		$$x[7]=$vcf->add_info_field($$x[7],'EnsId'=>$gene->stable_id(),'ExtId'=>$gene->external_name(),'Desc'=>$desc,'Cons'=>$consequences); 
		       }else{
				$$x[7]=$vcf->add_info_field($$x[7],'EnsId'=>$gene->stable_id(),'ExtId'=>$gene->external_name(),'Cons'=>$consequences); 
			}
		}else{
		       $$x[7]=$vcf->add_info_field($$x[7],'EnsId'=>$gene->stable_id(),'Cons'=>$consequences); 
		}
		#print "Position $h{'pos'} ref $h{'ref'} alt $h{'alt'}" . join("\t",@$x)."\n";
	}
	print (OUT join("\t",@$x)."\n");
    }
}
#####################################
sub getConsequence {
	my $h =shift;
	my $chr = $h->{'chr'};
	$chr =~ s/Chr//;
        # create a new VariationFeature object
           my $new_vf = Bio::EnsEMBL::Variation::VariationFeature->new(
           -start => $h->{'pos'},
           -end => $h->{'pos'},
           -slice => $slice,           # the variation must be attached to a slice
           -allele_string => "$h->{'ref'}/$h->{'alt'}",    # the first allele should be the reference allele
           -strand => 1,
           -map_weight => 1,
           -adaptor => $vfa,           # we must attach a variation feature adaptor
           -variation_name => 'newSNP',
         );
		
                # get the consequence types
                my $consequence;
                foreach my $con (@{$new_vf->get_all_TranscriptVariations}) {
=pod                        my $tva = "NULL";
                        my $pep_coord = "Null";
                        my $AAcid = "Null";
                        my $vfStart = "Null";
                        my ($AAalleles, $tvStart , $tvEnd) ;
                        my (@tv, @pc, $tsCodingStart, $tsCdnaStart);
=cut
			foreach my $string(@{$con->consequence_type}) {
				$consequence .= $string . ":";
			}
		}
		if(length($consequence) > 5){
			$consequence = substr($consequence,0,-1);
		}
		return $consequence;		

}
#############################################
sub annotateHeader{
	
my $replace = '##INFO=<ID=EnsId,Number=1,Type=String,Description="Ensembl ID"
##INFO=<ID=Acc,Number=1,Type=String,Description="Genbank Accession Number">
##INFO=<ID=Cons,Number=1,Type=String,Description="Consequence of SNP">
##INFO=<ID=Desc,Number=1,Type=String,Description="Gene description">
##INFO=<ID=ExtId,Number=1,Type=String,Description="Gene name">
##FORMAT=<ID=EnsId,Number=1,Type=String,Description="Ensembl ID">
##FORMAT=<ID=Cons,Number=1,Type=String,Description="Consequence of SNP">
##FORMAT=<ID=Desc,Number=1,Type=String,Description="Gene description">
##FORMAT=<ID=ExtId,Number=1,Type=String,Description="Gene name">
##FORMAT=<ID=Acc,Number=1,Type=String,Description="Genbank Accession Number">
';

        open(IN, "<$outfile") || die "$outfile $!\n";
        open(OUT, ">$outfile.out") || die "$outfile.out $!\n";
        while(<IN>){
                if(m/^##INFO=<ID=STR/){
	                print(OUT $_);
                        print(OUT $replace);
                }
                else{
                       print(OUT $_);
                }
        }
        close(IN);
        close(OUT);
        unlink($outfile);
        move("$outfile.out", $outfile);
}
 

