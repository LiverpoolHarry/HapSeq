use strict;
use warnings;
use Cwd;
=pod
#get files in current working directory
my $dir = getcwd;
opendir DIR, $dir or die "cannot open dir $dir: $!";
my @files = readdir DIR;
closedir DIR;
=cut
#get all bam files in a directory tree
my @chros = (1..29);
push (@chros, "X");
map ($_ = "Chr" . $_,  @chros) ;
#@chros = ("Chr21");
print "Chros: " . join(", ", @chros) . "\n";
my $logfile = "ScaffoldLengths.txt";
unlink($logfile);
my ($globalLength, $globalCount);
open (LOG, ">$logfile") || die "$logfile $!\n";
print(LOG "File\tmean length\tScaffold Count\n");
foreach my $chr (@chros){
    my @files = `find path/to/bam/files -name '*Chr*.bam' | grep $chr.bam 2>&1`;
  my $i = 0;
  foreach my $file (@files){
	$i++;
	chomp($file);
	my $root = substr($file,rindex($file,"/")+1,-4);
	print "$file\n";
	my $com = "samtools targetcut $file > targetCut.out";
	print "$com\n\n";
	system $com;
	my $outfile = "$root.gff3";
	open (IN, "<targetCut.out") || die "targetCut.out $!\n";
	open (OUT, ">$outfile") || die "$outfile $!\n";
	my ($length, $count);
	while(<IN>){
        	chomp();
        	my @data= split(/:|-|\s/);
        	$length += $data[2] - $data[1];
        	$count++;
		print(OUT "$data[0]\ttargetCut\tnull\t$data[1]\t$data[2]\t.\t.\t.\tcoverage=1\t\n");
		
	}
	close(IN);
	close(OUT);
	my $mean = 0;
	if($count > 0){
		$mean = int($length/$count);
	}
	print (LOG "$root\t$mean\t$count\n");
	print "Mean scaffold length = $mean \n";
	$globalLength += $length;
	$globalCount += $count;
  }
}
my $globalMean = int($globalLength / $globalCount);
print "Mean of all scaffolds = $globalMean\n";

print (LOG "Mean of all scaffolds = all files = $globalMean\n");
close(LOG);
