#!/usr/bin/perl
use strict;
use warnings;
use IO::Handle;

#Redirect error messages to log file
open ERROR,  '>', "PerlErrorLog.txt"  or die $!;
STDERR->fdopen( \*ERROR,  'w' ) or die $!;


=pod
The script has three functions:
1) Run BWA including csfasta2fastq if desired each fastq file is sent off to run on a seperate machine 
2) Merge output from one or more lanes / plates and remove duplicates. I may adapt this to split BAM files by readgroup 
3) Do local realignments and run GATK UnifiedGenotyper. It splits the task by chromosome and sends each chromosome off to run in a seperate screen

The first section contains all user modified variables, it should not be necessary to change any of the functions

It has not been extensively tested so almost certainly has bugs.
=cut


#Conversion of Csfasta to fastq
# Set to any value but 'true' to skip conversion of csfasta to fastq. 
#If running Bowtie the conversion will be done by Bowtie, with BWA csfasta2fastq will be used
my $csfastaToFastq = "false";

#Do test run if this is set to true then the top n lines will be taken from the input files for analysis
# With Bowtie this parameter will be ignored and you can set the -u option eg "-u"=>10000 in %bowtieParams
my $testrun = 'false';
my $headlines = '1000000'; #number of lines to take from each file for testing 

#locations and names of readfiles
#if $csfastaToFastq is set to "true" then .csfasta and _QV.qual extensions will be added else .fastq extension will be added
#use full path from root. Do not use ~/ for home directory
#$sourceReadpath and $readpath only needed for csfasta files and Bowtie. Not for BWA analysis of fastq but programme will fall over if not declared.
my $sourceReadpath = "/sol02/illum/121115_SN7001242_0100_BD1BNGACXX/";
my $readpath =" ";
#linux command that will find fastq files
my $find = 'find /sol02/illum/121115_SN7001242_0100_BD1BNGACXX  -name "*fastq.gz" | grep -v Temp | grep -v log | grep Harry';
#The read arrays will be cleared and populated by getIlluminaReads or get5500reads unless the functions are commented out
my @forwardReads = ("negF3.fastq", "posF3.fastq");#name of sample for each file
my @reverseReads = ();#If this list is populated it will be assumed that it is paired end data
my $user = "user"; #cluster user name used for monitoring job progress. must be set to your username

#reference indexed genome and reference fasta file the first must have been built from the second
my $path = "path/cow/diploid/busia/cells";
my $refGenomePath = "path/index";
my $BWAindex = "path/index/umd31all_bs";
my $refGenomeFasta = "path/index/umd31all.fasta";
my $scratchDir = "/scratch/path";
#BWA parameters. Set any legal BWA params as key => value pairs in hash 
# and add switches which take no values such as -c to array use " " if no switches used
#-N=> 0 do not output dicordant read pairs
#-n=>2 only output alignments if it has two or less alignemnts
my $runBWA = "false";
my %bwaParams = ("-t" => 8, "-q" => 20, "-n" => 2);#, "-k" => 4, "-n"=>5);
my @bwaSwitches = (" ");

#Bowtie parameters
my $runBowtie = "false";#true or false
#--mapq = 244 is a nasty codge, Bowtie seems to only write MAPQ 255 to the sam file which means unavailable which causes GATK to ignore the line completely
my %bowtieParams = ("-p" => 8, "--mapq"=>244); #-p for number of processes
my @bowtieSwitches = ("-C", "-S");#-C for colorspace -S for sam output
my $bowtie = "~/tuxedo/bowtie/bowtie-0.12.7/bowtie";
my $bowtieIndex = "~/tuxedo/bowtie/bowtie-0.12.7/indexes/umd3_c";

#read group parameters. Required by GATK. Additional parameters are available. see sam file format specification http://samtools.sourceforge.net/SAM1.pdf
#@ids and @samples will be cleared and populated by getIlluminaReads or get5500reads unless the functions are commented out
my @ids = ("neg","pos"); #free text
my @samples = ("neg", "pos"); # free text. Names of DNA samples associated with each fastq file must be one matching entry for each fastq 
my $platform = "ILLUMINA"; # Valid values: CAPILLARY, LS454, ILLUMINA, SOLID, HELICOS, IONTORRENT and PACBIO.case insensitive 

#Clear and populate arrays:- @forwardReads, @reverseReads, @samples and @ids based on Illumina file names
#Assumes that read names are in the format sample_barcode_lane_Rn_serialNumber.fastq where Rn is R1 for forward and R2 for reverse
#getIlluminaReads($find);
#populate @samples and @ids  if running GATK without bWA first
getSampleNames($path);
print join(": ", @samples);
print "\n";
#Clear and populate arrays:- @forwardReads, @reverseReads, @samples and @ids based on 5500 file names
#Assumes that read names are in the format MachineName_Year_Month_Day_PlateNo_lane_sampleId_Fn.fastq where Fn is F3 for forward and F5 for reverse
#get5500reads($sourceReadpath);
#Assign same name which is within all read files to all samples which will cause them to be merged for SNP calling
#mergeSamplesForSNPCalling("Kraken");

#The jobs will be divided by lane and GATK jobs by chromosome and distributed over these machines 
#"watt03","watt04","watt05","watt06", "watt07",
my @machines = ("watt01","watt02","watt03","watt04","watt05","watt06", "watt07","watt08","watt09","watt10", "watt11", "watt12","watt13","watt14","watt15", "watt17","watt18","watt19",  "watt20","watt22", "watt23", "watt24", "watt25", "watt26");
#my @machines = ("watt01", "watt02","watt04","watt05","watt06", "watt07", "watt08","watt09", "watt11", "watt12","watt14","watt15","watt16", "watt17", "watt18", "watt19",  "watt21","watt22", "watt23", "watt24", "watt25", "watt26");
my @freeMachines = @machines; #will be reset by countScreens;

#I usually set the mapping to use the same number of threads as there are processors on the machine 
#so it is only appropriate to run one job at a time.
#GATK only uses a single thread so it is OK to thro more jobs at each machine.
my $mappingJobsPerMachine = 1;
my $gatkJobsPerMachine = 1;

#Job scheduling parameter
my $sleeptime = 600; #Frequency in seconds between checks on whether mapping run has finished if mapping is expected to take several hours then set this to say 1800 or 3600 

#Picard tools
my $picardPath = "~/bwa/picard-tools-1.79/";

#GATK
my $gatk = "~/gatk/GenomeAnalysisTK-1.1-3-g1f8fc4a/GenomeAnalysisTK.jar";

#GATK Unified Genotyper snp calling parameters from http://www.broadinstitute.org/gsa/wiki/index.php/Unified_genotyper

#Heterozygosity

=pod You can use the --heterozygosity argument to change the expected heterozygosity value used to compute prior likelihoods for any locus. The default priors are:
        het = 1e-3
        P(hom-ref genotype) = 1 - 3 * het / 2
        P(het genotype) = het
        P(hom-var genotype) = het / 2 
        my $het = 1e-3;
        
        I tried this once and it complained
=cut

#Minimum Confidence Threshold

my $stand_call_conf = 30.0; #the minimum phred-scaled Qscore threshold to separate high confidence from low confidence calls. Only genotypes with confidence >= this threshold are emitted as called sites. A reasonable threshold is 30 for high-pass calling (this is the default).
my $stand_emit_conf =30.0; #the minimum phred-scaled Qscore threshold to emit low confidence calls. Genotypes with confidence >= this but less than the calling threshold are emitted but marked as filtered. The default value is 30. 

#Arguments Specifying Outputs

my $GATKoutput =  "variants.vcf"; # will be prefixed by sample and chromosome number
my $sites_only = " "; #set to '-sites_only' to write just the sites (without genotypes) to the output VCF (i.e. just the first 8 columns).
my $out_mode = "EMIT_ALL_CONFIDENT_SITES"; #possible values are EMIT_VARIANTS_ONLY (the default), EMIT_ALL_CONFIDENT_SITES (include confident reference sites), or EMIT_ALL_SITES (any callable site regardless of confidence). 
my $gt_mode = "DISCOVERY";# specifies how to determine the alternate allele to use for genotyping; possible values are DISCOVERY (the default; the Unified Genotyper will choose the most likely alternate allele) or GENOTYPE_GIVEN_ALLELES (only the alleles passed in from a VCF rod bound to the name "alleles" will be used for genotyping).
my $glm = "BOTH"; #  specifies which class of variants to call. By default only SNPs are called, but one can state that only indels (-glm INDEL) or both (-glm BOTH) should be called.
my $deletions = 0.05; # specifies the maximum fraction of fastq with deletions spanning a locus tolerated by the genotyper (the genotyper won't make calls at loci with too many deletions). Default is 0.05.
my $debug_file = " ";  # specifies the output file used to print debugging information.Set to "-debug_file filename" to implement; 
my $metrics = " ";#  specifies the output file used to print various metrics about callability. Set to "-metrics filename" to implement;

#Arguments Describing Good Bases
    
my $min_base_quality_score = 17; #specifies the minimum base quality required to consider a base for calling. Default is 17.
my $min_mapping_quality_score = 20; #specifies the minimum read mapping quality required to consider a read for calling. Only used in indel calling. Default is 20. 

#Arguments for Annotations

my $nsl = " "; # instructs the Genotyper not to calculate the SLOD.Set to "-nsl" to implement
my $anotations  = '-A DepthOfCoverage -A AlleleBalance';#  tells the Genotyper to apply one or more annotations to variant calls (e.g. '-A DepthOfCoverage -A AlleleBalance' would include those 2 annotations); see the VariantAnnotator for more details.
my $groups = " " ; # instructs the Genotyper to apply one or more annotation interfaces/groups to variant calls (e.g. '-G Standard' would apply all annotations which implement the StandardAnnotation interface); see the VariantAnnotator for more details. 

#Miscellaneous

my $dcov = 50; #positions with more than this number of fastq will be disregarded recomended 


	 
#Build set of chromosomes to break job up into for GATK
#Chromosome names must be exactly as they appear in reference fasta file
my @chr;
foreach my $i (1..29){
	my $chr = "Chr" . $i;
	push (@chr,$chr);
}
push (@chr,"ChrX");
#@chr = ("Chr19");

####################################################################################
#Start functions
#Declare global variables
my $samMergelist;

my @rootNames;
my $alignerName;

=pod #Now merging by chromosome not globally
#Build list for merging in case mapping step skipped
my $picardMergeList;
foreach my $i (0..$#forwardReads){
		my $bam = $forwardReads[$i] . ".bam";
		#Samtools merge list (Picard merge list has format INPUT=in.bam
		$samMergelist .= " $bam";
		$picardMergeList .= " INPUT=$bam";
	}
=cut
my $fileCount = $#forwardReads + 1;
#select runBowtie or runBWA. Bad things will happen if both are run at once
if($runBowtie eq "true" && $runBWA eq "true"){
	print "Both BWA and Bowtie have been requested, select just one of these\n";
}
elsif($runBowtie ne "true" && $runBWA ne "true"){
	print "Neither BWA nor Bowtie have been requested the run will continue assuming that appropriate bam files are available to merge and pass to GATK\n";
	mergeAndGATK();
}
elsif($runBowtie ne "true" && $runBWA eq "true"){
	print "Running BWA on $fileCount files\n";
	$alignerName = "BWA";
	runBWA();
	#mergeAndGATK();		
}
elsif($runBowtie eq "true" && $runBWA ne "true"){
	print "Running Bowtie on $fileCount files\n";
	$alignerName = "Bowtie";
	runBowtie();
	mergeAndGATK();
}
####################################################################################
#Build BWA script for each fastq file
sub runBWA{
	my $SortSam  = $picardPath . 'SortSam.jar';

	foreach my $i (0..$#forwardReads){
		
		#Build parameters for each file. Filename may contain path
		#my $read = $sourceReadpath . $forwardReads[$i];
		my $fastqF = $forwardReads[$i];
		my $fastqR = " ";
		if($reverseReads[$i]){
                        $fastqR = $reverseReads[$i];
		}
		#my @elements = split(/\//,$forwardReads[$i]);
		#my $rootName = $elements[$#elements];
		my $rootName = substr($forwardReads[$i],rindex($forwardReads[$i],"\/") + 1);
		$rootName = substr($rootName, 0, index($rootName, ".fastq"));
		push(@rootNames,$rootName);
		my $fSai = $ids[$i] . ".sai";
		my $rSai = $ids[$i]  . "R.sai";
		my $sam = $ids[$i]  . ".sam";
		my $bam = $ids[$i]  . ".bam";
		my $bai = $ids[$i]  . ".bam.bai";
		my $sortedBam = $ids[$i]  . ".sorted.bam";

		
		my $rgs = ("\'\@RG\\tID:" . $ids[$i] . "\\tPL:" . $platform . "\\tSM:" . $samples[$i] . "\'");
		my $logfile = $ids[$i]  . "_log.txt"; 	
		my $unpigz = " ";		
		my $deleteReads = " "; #Only applied if unzipping
		my $csfasta2fastq = " ";
		if($csfastaToFastq eq 'true'){		
			my $QVquals = $sourceReadpath . substr($forwardReads[$i], 0, index($forwardReads[$i], ".csfasta")) . "_QV.qual";		
			if($testrun eq 'true'){
				$fastqF = "test$i.fastq";
				my $testQV = $readpath ."test$i" . "_QV.qual";
				system "head -n $headlines $QVquals > $testQV";
				my $testCfasta = $readpath . "test$i.csfasta";
				system "head -n $headlines $sourceReadpath$forwardReads[$i].csfasta > $testCfasta";
				$csfasta2fastq = "csfasta2fastq $testCfasta $testQV > $readpath$fastqF ";
			}
			else{
				$csfasta2fastq = "csfasta2fastq $sourceReadpath$forwardReads[$i].csfasta $QVquals > $readpath$fastqF ";
			}
		}
		elsif($testrun eq 'true'){
			system "head -n $headlines $sourceReadpath$fastqF > testF$i.fastq";
			$fastqF = "testF$i.fastq";
			if($reverseReads[$i]){
				system "head -n $headlines $sourceReadpath$reverseReads[$i].fastq > testR$i.fastq";
			}
			$fastqR = "testR$i.fastq";
		}
		
		#build list of parameters for BWA
		my $bwaParamList = " ";
		while( my ($k, $v)= each(%bwaParams)){
			$bwaParamList .= "$k $v ";
		}
		foreach my $switch (@bwaSwitches){
			$bwaParamList .= "$switch ";
		}
		#build BWA query depending on whether paired ed or not
		my $bwaAlign;
		if($reverseReads[$i]){
			
			$bwaAlign = "bwa aln $bwaParamList $BWAindex $fastqF > /scratch/$fSai 2>> $logfile  \n
		     		     bwa aln $bwaParamList $BWAindex $fastqR > /scratch/$rSai 2>> $logfile  \n
						
				     bwa sampe -r $rgs $BWAindex /scratch/$fSai /scratch/$rSai $fastqF $fastqR > /scratch/$sam 2>>  $logfile \n
				     rm -f /scratch/$fSai \n
				     rm -f /scratch/$rSai \n";
		}
		else{
			$bwaAlign = "bwa aln $bwaParamList $BWAindex $fastqF > /scratch/$fSai 2>> $logfile  \n
			
			bwa samse -r $rgs $BWAindex /scratch/$fSai $fastqF > /scratch/$sam 2>> $logfile \n
						
			rm -f /scratch/$fSai \n";
		}
		
		#Build shell script for BWA
		my $shellscript = "
		cd $path \n
		echo 'STARTED BWA  at ' `date`| tee   $logfile
		echo 'STARTED BWA for $fastqF at ' `date`
		$bwaAlign \n

		echo 'aligned ' $forwardReads[$i]  `date` | tee -a  $logfile \n\n
		
		#Count matching lines
		grep -c Chr /scratch/$sam >> MappedLines.txt
		
		#Convert sam :to bam (binary) -F 4 removes unmapped lines (Flag contains 4)\n
		#-bSuh is bam output; sam input, uncompreesed output, headers carried over
		
		samtools view -bSuh -F 4 -o /scratch/$bam /scratch/$sam \n
		
		echo 'Converted sam to bam' `date` | tee -a  $logfile \n
	
		rm /scratch/$sam \n

	
		#Sort and index bam file so that individual chromosomes can be extracted
		java -jar $SortSam INPUT=/scratch/$bam OUTPUT=/scratch/$sortedBam SORT_ORDER=coordinate 2>> $logfile  \n
		mv /scratch/$sortedBam /scratch/$bam 
		
		samtools index /scratch/$bam

		echo 'Sorted bam' `date` | tee -a  $logfile \n
		
		mv /scratch/$bam $bam \n
	
		mv /scratch/$bai $bai \n
		
		echo 'Finished BWA for $fastqF at ' `date`

		";
	
		
		#Write shell script to file change permissions and launch in an anonymous screen	
		my $shellfile = "run_" . $rootName  . ".sh"; 

		open (SH, ">$shellfile") || die "$shellfile  $!\n";
		print (SH $shellscript);
		close(SH);
		system "chmod 755 $shellfile";

		my $machine = pop(@freeMachines);
		
		my $com =  "screen -dm  -S $ids[$i]  ssh $machine nice bash $path/$shellfile ";
		open(OUT, ">$logfile") || die "$logfile $!\n";
		print (OUT "$com\n\n");
		close(OUT);
		
		print "$com\n";
		if($machine){
			system $com;
		}

		@freeMachines = @{countScreens(\@rootNames, $mappingJobsPerMachine)};
	}
	waitForScreens(\@rootNames);
	
	#Get list of numbers of mapped lines and remove sam files
	
	
}
####################################################################################
#Build Bowtie script for each fastq file
sub runBowtie{
	my $SortSam  = $picardPath . 'SortSam.jar';
	#Bowtie does not include readgroup information on each line just in header
	my $ReplaceReadGroups  = $picardPath . 'AddOrReplaceReadGroups.jar';
	
	foreach my $i (0..$#forwardReads){
		
		#Build parameters for each file
		my $read = $sourceReadpath . $forwardReads[$i];
		my @elements = split(/\//,$forwardReads[$i]);
		my $rootName = $elements[$#elements];

	
		push(@rootNames,$rootName);
		my $sam = $ids[$i] . ".sam";
		my $bam = $ids[$i] . ".bam";
		my $sortedBam = $ids[$i] . ".sorted.bam";
		my $readGroupBam = $ids[$i] . ".RG.bam";

		#my $rgs = ("\'\@RG\\tID:" . $ids[$i] . "\\tPL:" . $platform . "\\tSM:" . $sample . "\'");
		my $rgs = ("--sam-RG ID:$ids[$i] --sam-RG PL:$platform  --sam-RG SM:$samples[$i]");
		my $logfile = $ids[$i] . "_log.txt"; 	
		
		my $readlist;
		if($csfastaToFastq eq "true"){
			$readlist = "-f $sourceReadpath$forwardReads[$i].csfasta -Q $readpath$forwardReads[$i]" . "_QV.qual";
		}
		else{
			$readlist = "-q $sourceReadpath$forwardReads[$i].fastq";
		}
		
		#build list of parameters for Bowtie
		my $bowtieParamList = " ";
		while( my ($k, $v)= each(%bowtieParams)){
			$bowtieParamList .= "$k $v ";
		}
		foreach my $switch (@bowtieSwitches){
			$bowtieParamList .= "$switch ";
		}
	
		
		#Build shell script for BWA
		my $shellscript = "
		cd $path \n
		#Bowtie command\n
		$bowtie $bowtieParamList  $rgs $bowtieIndex $readlist > $sam 2> $logfile
	
		echo 'aligned ' $forwardReads[$i] | tee -a  $logfile 
		
		#Convert sam to bam (binary) -F 4 removes unmapped lines (Flag contains 4)
		
		samtools view -bSuh -F 4 -o $bam $sam 
		rm -f $sam \n
		echo 'Converted sam to bam' | tee -a  $logfile
		
		java -jar $ReplaceReadGroups I=$bam O=$readGroupBam SORT_ORDER=coordinate RGID=$ids[$i] RGLB=bar RGPL=$platform RGSM=$samples[$i] RGPU=ReadGroupPlatformUnitEgBarCode  2>> $logfile
		mv $readGroupBam $bam
		
		java -jar $SortSam INPUT=$bam OUTPUT=$sortedBam SORT_ORDER=coordinate 2>> $logfile
		
		mv $sortedBam $bam
		samtools index $bam
		
		echo 'Sorted bam' | tee -a  $logfile \n
		
		";
	
		
		#Write shell script to file change permissions and launch in an anonymous screen	
		my $shellfile = "run_" . $forwardReads[$i]  . ".sh"; 
		open (SH, ">$shellfile") || die "$shellfile  $!\n";
		print (SH $shellscript);
		close(SH);
		system "chmod 755 $shellfile";
		my $machine = shift(@freeMachines);
		my $com =  "screen -dm  -S $forwardReads[$i]  ssh $machine nice bash $path/$shellfile ";
		print "$com\n";
		system $com;

		@freeMachines = @{countScreens(\@machines, $mappingJobsPerMachine)};
	}
	
	
	waitForScreens(\@rootNames);
	
}


###############################################
# Once BWA has finished merge bam files and remove duplicates
sub mergeAndGATK{

	
	my $MergeSamFiles  = $picardPath . "MergeSamFiles.jar";
	my $MarkDuplicates  = $picardPath . "MarkDuplicates.jar";
	my $ValidateSamFile  = $picardPath . "ValidateSamFile.jar";
	my $SortSam  = $picardPath . 'SortSam.jar';
	
	#Get list of unique sample names to iterate over	
	my %uniqueSamples;
	foreach my $sample (@samples){
		$uniqueSamples{$sample} = 1;
	}
	my @uniqueSamples = keys(%uniqueSamples);
	my $sampleList =  join("", @uniqueSamples);
	print"sample list: $sampleList\n" . join("; ", @samples) . "\nUnique samples" . join("; ", @uniqueSamples) . "\n";
	my $sampleCount = 0;
	my $sampleChrCount = 0;
	my $i = 0;	
	if(!-e "/scratch/path"){
		system "mkdir /scratch/path";	
	}
	foreach my $sample (@uniqueSamples){
				
		#my $dedupped = $sample . "dedup.bam";
		my $realignedBam = $sample . "realigned.bam";
		$sampleCount++;
	
		foreach my $chr (@chr){
			$sampleChrCount++;
			my $samFile = "$path/$sample$chr.bam";
			#print "Samples $samFile\n";
			if(-e $samFile){
				print "Skipping $samFile\n";
				next
			}

			my $mergedFile = $sample  . $chr . ".bam";
			my $dedupped = $sample . $chr . ".dedupped";
			my $picardMergeList = " ";
			my $logfile = $path . "/" . $sample . $chr . "_log.txt";
			my $deduplogfile=  $sample . $chr . "_log.txt";
			unlink $logfile;
			my $chrBamFiles;
			my $countFilesToMerge = 0;
			my $samtoolViewJobs;
			#Split each bam file into file for each chromosome 
			foreach my $id (@ids){
				my @elements = split(/_/,$id);
				my $read = $elements[0]; #substr($elements[1],1). "_F";
			#	print "Sample $sample Read $read\n";
				if(substr($sample,0,-1) eq $read){
					my $outbam = "/scratch/path/$id.$chr.bam";
					$samtoolViewJobs .= "cp  $path/$id.bam  /scratch/path/$id.bam\n                                ";
					$samtoolViewJobs .= "cp  $path/$id.bam.bai  /scratch/path/$id.bam.bai\n                                ";
					$samtoolViewJobs .= "samtools view -buh -o $outbam  /scratch/path/$id.bam  $chr \n                                ";
					$samtoolViewJobs .= "rm /scratch/path/$id.bam\n                                ";
					$samtoolViewJobs .= "rm /scratch/path/$id.bam.bai\n                                ";
					$picardMergeList .= " INPUT=$outbam ";
					$chrBamFiles .= " $outbam";
					$countFilesToMerge++;
				}			
			}
			print "Sample Count $sampleCount Sample Chr Count $sampleChrCount\n"; 
			# build shell script
			my $gatkcommand=
				"
				if [ -d $scratchDir ];
				then
   					echo 'File scratch directory exists'
				else
   					mkdir $scratchDir
				fi
				cd /scratch/path \n 
				#Split Bam files
				$samtoolViewJobs
				#Merge lane files
				# Could merge all bam files first and then split by chromosomes but merging is memory intensive so best to split first\n
				       
				\n
				#Change location of temporary files from /tmp which is RAM to /scratch which is disk based
				export TMPDIR=/scratch \n
				
				echo 'STARTED Picard merge  at ' `date`| tee -a  $logfile
				 
				# picard mergeSamFiles sorts as it goes \n
				java  -jar $MergeSamFiles $picardMergeList  O=$mergedFile  MERGE_SEQUENCE_DICTIONARIES=true USE_THREADING=true  2>> $logfile\n
				echo 'Finshed Picard merge  at ' `date`| tee  -a $logfile
				
				#remove input files split by chromosome
				rm $chrBamFiles
				
				
				java  -jar $SortSam INPUT=$mergedFile OUTPUT=sorted$mergedFile SORT_ORDER=coordinate 2>> $logfile
				rm $mergedFile
				mv sorted$mergedFile $mergedFile
				echo 'Sorted BAM files ' `date`| tee  -a $logfile
				\n
				#remove duplicates \n
				java  -jar $MarkDuplicates INPUT=$mergedFile  OUTPUT=$dedupped.bam METRICS_FILE=$deduplogfile REMOVE_DUPLICATES=true ASSUME_SORTED=true MAX_FILE_HANDLES_FOR_READ_ENDS_MAP=1000 2>> $logfile\n
				\n
				mv $deduplogfile $path/$deduplogfile 
				echo 'Finished Picard MarkDuplicates  at ' `date`| tee  -a $logfile
				
				#Create index for fast random access \n
				samtools index $dedupped.bam 2>> $logfile\n
		
				echo Created index \n
			
				#Build GATK command for this chromosme
				echo 'STARTED GATK at ' `date`| tee -a  $logfile
					
				#GATK realigner arround indels and resort, index  and then do it again
				java -Xmx2g   -jar $gatk -T RealignerTargetCreator  -L $chr -R $refGenomeFasta   -o $sample$chr.intervals  -I $dedupped.bam 2>> $logfile\n
				java -Xmx4g   -jar $gatk -T IndelRealigner -I $dedupped.bam -L $chr -R $refGenomeFasta   -targetIntervals $sample$chr.intervals -o $sample$chr.2.bam 2>> $logfile \n
				
				rm $sample$chr.intervals
				rm $dedupped.bam
				rm $dedupped.bam.bai
				
				
				
			
				java  -jar $SortSam I=$sample$chr.2.bam O=$sample$chr$realignedBam  SO=coordinate \n
				rm $sample$chr.2.bam
				rm $sample$chr.2.bam.bai
	
				
				mv $sample$chr$realignedBam $sample$chr.bam
				
				samtools index $sample$chr.bam
				
				java -Xmx2g   -jar $gatk -T RealignerTargetCreator  -L $chr -R $refGenomeFasta   -o $sample$chr.intervals  -I $sample$chr.bam 2>> $logfile\n
				java -Xmx4g   -jar $gatk -I $sample$chr.bam  -L $chr -R $refGenomeFasta  -T IndelRealigner -targetIntervals $sample$chr.intervals -o $sample$chr.2.bam 2>> $logfile \n
				
				rm $sample$chr.intervals 
				rm $sample$chr.bam
				
				
				java   -jar $SortSam I=$sample$chr.2.bam O=$sample$chr$realignedBam  SO=coordinate  2>> $logfile \n
				
				rm $sample$chr.2.bam
				rm $sample$chr.2.bai
				
				mv $sample$chr$realignedBam $sample$chr.bam
				
				samtools index $sample$chr.bam  2>> $logfile
				
				echo 'Finished GATK Realigner  at ' `date`| tee  -a $logfile
				
				#Call GATK unified genotyper for SNP and indel calling
			
				#java  -jar $gatk -R $refGenomeFasta -T UnifiedGenotyper -I $sample$chr.bam  -o $sample$chr$GATKoutput -stand_call_conf 50.0 -stand_emit_conf 10.0 -dcov $dcov -glm $glm $anotations --min_base_quality_score $min_base_quality_score --min_mapping_quality_score $min_mapping_quality_score  -L  $chr -deletions $deletions -out_mode $out_mode -gt_mode $gt_mode $sites_only $debug_file $metrics $groups  2>> $logfile
			
				echo 'FINISHED GATK at ' `date` | tee -a  $logfile
				#zip and index file
 		                #bgzip $sample$chr$GATKoutput
                		#tabix -f -p vcf $sample$chr$GATKoutput.gz
				mv $logfile $path/$logfile
				#mv $sample$chr$GATKoutput.gz  $path/$sample$chr$GATKoutput.gz
				#mv $sample$chr$GATKoutput.gz.tbi  $path/$sample$chr$GATKoutput.gz.tbi
				#mv $sample$chr$GATKoutput.idx  $path/$sample$chr$GATKoutput.idx
				mv $sample$chr.bam $path/$sample$chr.bam
				mv $sample$chr.bam.bai $path/$sample$chr.bam.bai
				
		
			";
		
			#Write shell script to file and start a seperate screen for each chromosome
				my $shellfile = "run_" . $sample . $chr . "GATK.sh";
				my $machine =shift(@freeMachines);
				my $com =  "screen -dm -S $sample$chr ssh $machine nice bash $path/$shellfile ";
				print "$com\n";
				
				open (SH, ">$shellfile") || die "$shellfile  $!\n";
				print (SH "#$com\n\n");			
				print (SH $gatkcommand );
				close(SH);
				system "echo $com | tee $logfile";
				system "chmod 755 $shellfile";				
				system $com;
				$i++;

				@freeMachines = @{countScreens(\@machines, $gatkJobsPerMachine)};
				sleep(10);
				#last;
		}
		#last;
	}
	#last
}

######################################################################################################
sub getIlluminaReads{
	my $find = shift;
	@forwardReads = ();
	@reverseReads = ();
	@ids = ();
	@samples =();
	my @files = `$find`; 
	foreach my $path (@files) {
		#print "$path\n";
		chomp($path);
		#Only process forward reads
		if($path =~ m/R1.+fastq.gz/){
			my $file = substr($path,rindex($path,"\/") + 1);			
			print "$file\n";
			push(@forwardReads, $path);
		        $file =~ s/^FOS_/_/;
                	$file =~ s/^FOS-/_/;
                	$file =~ s/FOSMID_/_/;
		
			my @elements = split(/_/,$file);
			#id = sampleId_LaneNo
			my $sampleId = $elements[0];;
			my $id = $sampleId . "_$elements[2]";
			#print "$id\n";
			push(@ids, $id);
			push(@samples, $sampleId .  "_");
			print "$id\t$path\n";	
			#Check if reverse read exists and if it does load that
			$path =~ s/R1/R2/;
			#my $filetest = $dirname . $file;
			if(-e $path){
				push(@reverseReads, $path);
			#	print "$path\n";
			}
		}
	}
		
}
#################################################
sub getSheepChr{

       	my $filename = shift;
	my @sheepChr ;
	my @codes = `grep chromosome $filename 2>&1`;
	foreach my $code (@codes){
		my @stuff = split(/\s/,$code);
		push (@sheepChr, substr($stuff[0],1));
		#print "Chromsome " . substr($stuff[0],1) . "\n";
	}
	return \@sheepChr;
}

#################################################
#Started shell scripts in independent screens now monitor them until they finish before running merge
sub waitForScreens{
	
	my $names = shift;
	my @names =@{$names};
	my $flag = "false";
	my $start = time;
	my $teststring = "XXXXX";
	while(length($teststring) > 1){
			
		 
			#get list of jobs in screens for user and 
			#add those that match files in @rootNames to list of running jobs
			#keep iterating until list of running jobs is empty
			system "ps -ef | grep SCREEN | grep $user  > screenLog.txt";
			$teststring = " ";
			open (LOG, '<screenLog.txt') || die "screenLog.txt $!\n";
			my $l = 0;
			my $completeProcesses = " ";
			while(<LOG>){
				 
				 my $line = $_;
				 foreach my $name (@names){
					if($line =~ m/$name/){	
						$teststring .= $name;
						$completeProcesses .=  "$name; ";
						$l++;
					}
				}
				
			 }
			close(LOG);
			my $elapsed = time - $start;
			#print " Waiting for $alignerName, $l processes still running: $completeProcesses time so far $elapsed s\n"; #for debugging
			if(length($teststring) > 2){
				sleep($sleeptime);
			}
	 }
 
}
#################################################
#Started shell scripts in independent screens now monitor them until they finish before running merge
sub countScreens{
	my $names = shift;
	my $jobsPerMachine = shift;
	my @names =@{$names};
	my $flag = "false";
	my $start = time;
	my $l = 0;
	my @fMachines;#free machines
	#an earlier version checked for the presence of file names because machines might have other SCREENS running
	#that are not generated by this script. However it seems better to take that risk and increase confidence
	#of assigning jobs to the correct machine
	while($flag eq "false"){
			#get list of jobs in screens for user and 
			#add those that match files in @rootNames to list of running jobs
			#keep iterating until list of running jobs is empty
			system "ps -ef | grep SCREEN | grep $user | grep watt > screenLog.txt";
			my $teststring = " ";
			open (LOG, '<screenLog.txt') || die "screenLog.txt $!\n";
			my $l = 0;
			my @runningProcesses;
			while(<LOG>){
				 my $line = $_;
				
				 foreach my $mac (@machines){
					if($line =~ m/$mac/){	
						$teststring .= $mac;
						push (@runningProcesses, $mac);
						$l++;
					}
				}
			 }
			close(LOG);
			my $elapsed = time - $start;
			#print " Waiting for  $l machines still running: $teststring  time so far $elapsed s\n"; #for debugging
			if($#runningProcesses >= $#machines * $jobsPerMachine){
				sleep(60);				
			}
			else{
				$flag = "true";
			}
			#get next free machine
			foreach my $mac (@machines){
				my $countProcessesOnMachine = $teststring =~ s/$mac/$mac/g;
				if($countProcessesOnMachine < $jobsPerMachine){
					foreach ($countProcessesOnMachine ..$jobsPerMachine - 1){
						push(@fMachines, $mac);
					}
				}
			}
	}
	return(\@fMachines);
}
######################################################################################################
sub get5500reads{
	my $dirname = shift;
	@forwardReads = ();
	@reverseReads = ();
	@ids = ();
	@samples =();
	#Find all fastq files under reads directory
	system "find $dirname -name *.fastq* | grep -v rejects | grep -v Unclassified | grep -v Unassigned > reads.txt";
	open(IN, "<reads.txt") or die "can't opendir reads.txt $!";
	while (<IN>) {
		if(m/F3.+fastq/){
			my $pathAndFile = $_;
			#split file name out of full path with rindex to get last instance of /
			my $file = $pathAndFile; 
			#file will still hold prt of path this will be reomved later
			$file =~ s/$dirname//;
			#remove newline character as well as .fastq or fastq.gz
			#$file = substr($file,0,index($filename,'.fastq'));			
			$file = substr($file,0,-1);			
			push(@forwardReads, $file);
			#split sample and lane out of file name
			my @elements = split(/\//,$pathAndFile);
			$file = $elements[$#elements];
			@elements = split(/_/,$file);
			#split file name in to Lane id; sample id; F3/5
			my $id = "Lane" . "$elements[$#elements - 3]_P$elements[$#elements - 1]_$elements[$#elements]";
			#my $id = "Lane" . "$elements[$#elements - 3]_P$elements[$#elements - 4]_$elements[$#elements - 1]";
			$id = substr($id,0,index($id,'.fastq'));			
			push(@ids, $id);
			#Add trailing _ so that sample names that are substrings of each other do not get matched
			my $sample = $elements[$#elements - 1] .  "_" . substr($elements[$#elements],0,1);
			push(@samples, $sample);
			#print "ID $id\tSample $elements[$#elements - 1]\tFile $forwardReads[$#forwardReads]\n";
			
			#Check if pair exists and if it does load that
			# Needs to be done here to ensure that F3 F5 pairs are matched in arrays
			$pathAndFile =~ s/F3/F5/g;
			if(-e $pathAndFile){
				#split file name out of full path
				my $file = $pathAndFile;
				$file =~ s/$dirname//;
				$file = substr($file,0,-1);			
				push(@reverseReads, $file);
			}
		}
	}
	close(IN);	
}

######################################################################################################
#Give all samples the same name which will cause them to be merged for SNP calling purposes
sub mergeSamplesForSNPCalling{
	my $key = shift;
	my $sampleCount = $#samples;
	@samples = ();

	foreach my $sample (0..$sampleCount){
		push(@samples, $key);
	}
}
#############################################
#Get ids of samples associated with bam files for use with merge and GATK. Assumes that all bam files in nominated directory will be processed
sub getSampleNames{
	my $path = shift;
#	print "ls $path/*.bam\n";
	my @bam = `ls $path/*.bam`;
	#print join(":: ", @bam) . "\n";
	@samples = ();
	@ids = ();
	foreach my $bam (@bam){
		chomp($bam);
		$bam = substr($bam,rindex($bam,"/")+1);
		my (@data) = split(/_/,$bam);
		push(@samples, $data[0] . "_");
		push(@ids,substr($bam,0,-4));	
	}
	print "Got $#bam samples\n";
	print "IDs: " . join("; ",@ids) . "\n";;
	

}

