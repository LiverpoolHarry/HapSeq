use strict;
use warnings;

my $infile = $ARGV[0];
my $outfile = $infile;
$outfile =~ s/txt$//;
$outfile .= "SummaryStatistics";
my @chros;
foreach my $c (1..29){
	my $chr = "Chr" . $c;
	push(@chros, $chr);
}
push(@chros,"ChrX");

my @libs = `grep _FChr  ScaffoldLog.txt   2>&1`;
my $preLib = 'XX';
my @uniqueLibs;
my %tags;
my %chrParams;
my %chrParamsCounts;
my %sampleParams;
my %sampleParamsCounts;
my %params;
my $ref = "78118";
my %sorter;
open (IN, "<$infile") || die "$infile $!\n";
while(<IN>){
	#\w matches alphanumeri + _
	unless(m/^\w{2,3}/){next}
	chomp();
	$sorter{$_}++;
}
close(IN);
foreach my $k (keys %sorter){
	my @data = split(/\s{5,}|=/,$k);
	unless($data[2]){next}
	if($data[1] =~ m/^Processed/){next}
	my ($sample, $chr) = split(/_/,$data[0]);
	if($sample =~ m/^78118/){
		$chr = substr($sample, 6);
		$sample = "78118";
	}
	$data[2] =~ s/,//g;
	unless($data[2] =~ m/\d+/){next}
	if($data[2] =~ m/^\sNot/){next}
	$chrParams{$chr}{$data[1]} += $data[2];
	$chrParamsCounts{$chr}{$data[1]}++;
	$sampleParams{$sample}{$data[1]} += $data[2];
	$sampleParamsCounts{$sample}{$data[1]}++;
	$params{$data[1]}++;
}
open (OUT1, ">$outfile.byChr.txt") || die "$outfile $!\n"; 
open (OUT2, ">$outfile.bySample.txt") || die "$outfile $!\n"; 
my @chrKeys = sort (keys %chrParams);
my @sampleKeys = sort (keys %sampleParams);
print (OUT1 "Parameter");
print (OUT2 "Parameter");
foreach my $pk (@chrKeys){
	print (OUT1 "\t$pk");
}
foreach my $pk (@sampleKeys){
	print (OUT2 "\t$pk");
}
print (OUT1 "\n");
print (OUT2 "\n");

foreach my $j (keys %params){
	print (OUT1 "$j");
	print (OUT2 "$j");
	foreach my $pk (@chrKeys){
		if($chrParamsCounts{$pk}{$j}){
			my $mean = $chrParams{$pk}{$j}/$chrParamsCounts{$pk}{$j};
			print(OUT1 "\t$mean");
		}
		else{
			print (OUT1 "\t");
		}	
	}
	foreach my $pk (@sampleKeys){
		if($sampleParamsCounts{$pk}{$j}){
			my $mean = $sampleParams{$pk}{$j}/$sampleParamsCounts{$pk}{$j};
			print(OUT2 "\t$mean");
		}
		else{
			print (OUT2 "\t");
		}
	}
	print (OUT1 "\n");
	print (OUT2 "\n");
}
close(OUT1);
close(OUT2);
