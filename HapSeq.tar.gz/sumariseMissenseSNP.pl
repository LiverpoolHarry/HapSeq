use strict;
use warnings;

#my $infile = "MissenseCountsFosmids.txt";
my $infile = "MissenseCountsFosmidsSNPhaplotypes.txt";
open (IN, "<$infile") || die "$infile $! \n"; 
my $totalMissense =0;
my $countGenes = 0;
my $MissenseSnpInGenesWithMoreThanOneMissense = 0;
my %hapCoverage;
my %seperation;
my %libTotalMissense;
my %libMultiMissense; 
while(<IN>){
	if(m/^Genes/){
		my @data = split(/\s+/);
		$totalMissense += $data[1];
		$MissenseSnpInGenesWithMoreThanOneMissense += $data[2];
	}
	elsif(m/phase/){
		my @data = split(/\s+/);
		my $cell = substr($data[0],index($data[0],"Scaffolds") + 10, rindex($data[0],"_") - index($data[0],"Scaffolds") - 10);
		$libTotalMissense{$cell} += $data[1];	
		$libMultiMissense{$cell} += $data[2];
	}
	elsif(m/^\d/){
		my @data = split(/\s+/);
		$hapCoverage{$data[0]} += $data[1];
		$seperation{$data[0]} += $data[2];
	}
	elsif(m/^Count/){
		my @data = split(/\s+/);
		$countGenes += $data[2];
	}
}
close(IN);
open(OUT, ">MissenseSnpHaplotypesFosmidsSummary.txt") || die " MissenseSnpSummary.txt $! \n";
#open(OUT, ">MissenseScaffoldsFosmidsSummary.txt") || die " MissenseSnpSummary.txt $! \n";
print(OUT "EAZ Fosmid SNP Haplotypes\n");
#print(OUT "EAZ Fosmid scaffolds\n");
print(OUT "Total number of genes = $countGenes\n");
print(OUT "Total Missense SNP $totalMissense\n"); 	
print(OUT "Missense SNP in Haplotypes with multiple missense SNP $MissenseSnpInGenesWithMoreThanOneMissense \n"); 	
print (OUT "Lib\tCountMissenseSNP\n");
foreach my $key (sort {$a<=>$b} keys %libTotalMissense){
	print(OUT "$key\t$libTotalMissense{$key}\t$libMultiMissense{$key}\n");
}
print (OUT "Number Of Times Haplotype Observed\tNumber of two SNP haplotypes\n");
foreach my $key (sort {$a<=>$b} keys %hapCoverage){
	my $mean = $seperation{$key}/$hapCoverage{$key};#divide by number of chromsomes
	print(OUT "$key\t$hapCoverage{$key}\t$mean\n");
}
 
close(OUT);
