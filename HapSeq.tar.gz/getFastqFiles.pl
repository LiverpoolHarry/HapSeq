use strict;
use warnings;

my @folds = ('/path1/', '/path2/',
	'/path3/', '/path4');
my $count = 0;
open (OUT, ">FastqFiles.txt") || die "FastqFiles.txt $!\n";
foreach my $fold (@folds){

	my @folders = `find $fold -name "Project_Identifier*" | grep -v Temp | grep -v log`;

	foreach my $folder (@folders){
		chomp($folder);
		my @fastqs = `find $folder -name '*fastq.gz'`;
		foreach my $fastq (@fastqs){
			chomp($fastq);
			#checksum will be required when submitting to the short read archive
			my $checksum = `md5sum $fastq`;
			$checksum = substr($checksum,0,index($checksum," "));
			print (OUT "$fastq\t$checksum\n");
			$count++;
		}
	}

}
print "Found $count files\n";
close(OUT);
