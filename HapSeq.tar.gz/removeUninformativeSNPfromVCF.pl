use strict;
use warnings;


my $chr = $ARGV[0];
my $outfile = "SNPalleleCounts" . $chr . ".txt";
my $infile = "merged." . $chr . ".vcf";
system "bgzip -d $infile.gz";
my $newVCF = "new" . $chr . ".vcf";
open (NEW, ">$newVCF") || die "$newVCF $!\n";
open(IN, "<$infile") || die "$infile $!\n";
my %headers;
my %counts;
my %homos;
my %hist;
my %depth;
my %qualVals;
my %qualCounts;
my %qualByLociVals;
my %qualByLociCounts;
my $j = 0;
while(<IN>){
	my $line = $_;
	if(m/^#/){
		if(m/^#CHROM/){
			getheaders($line);
		}
		print(NEW $line);
	}
	else{
		$j++;
		if($j % 10000000 == 0){print "Line $j\n";}
		chomp($line);
		my @data = split(/\s+/,$_);
		#No reference sample
		my $count = countAlleles(\@data);
		
		if($count > 2 && $line !~ m/0\/1/){
			print(NEW "$line\n");
		}
	}
}
close(IN);
close(NEW);
open(OUT, ">$outfile") || die "$outfile $!\n";
foreach my $key (sort keys %counts){
	print(OUT "$key\t$counts{$key}\n");
}


print(OUT "Histograms\n");
print(OUT "Count Libraries with genotypes\tcount Ref allele\tcount Alt allele\n");
foreach my $key (sort keys %hist){
	print(OUT "$key\t$hist{$key}{'0/0'}\t$hist{$key}{'1/1'}\n");
}

print (OUT "Mean Qualities by count loci with subcell data\n");
print (OUT "Count Libs\tMean Global Qual\tCount Loci\n");
foreach my $key (sort keys %qualByLociVals){
	my $mean1 = $qualByLociVals{$key} / $qualByLociCounts{$key};
	print(OUT "$key\t$mean1\t$qualByLociCounts{$key}\n");
}

close(OUT);
system "bgzip $infile";
system "tabix -f -p vcf $infile.gz";
system "bgzip $newVCF";
system "tabix -f -p vcf $newVCF.gz";
###############################################################
sub countAlleles{
	my $data = shift;
	my @data = @{$data};
	my %histCounts;
	$histCounts{'1/1'} = 0;
	$histCounts{'0/0'} = 0;
	foreach my $i (9..$#data){
		if($data[$i] ne './.'){
			my $allele = substr($data[$i],0,3);
			my $key = $headers{$i} . "_" . $allele;
			$counts{$key}++;
			$histCounts{$allele}++;
		}
	}
	my $alleleCount = keys %histCounts;
	if(%histCounts){
		$hist{$alleleCount}->{'0/0'} += $histCounts{'0/0'};
		$hist{$alleleCount}->{'1/1'} += $histCounts{'1/1'};
 		$qualByLociVals{$alleleCount} += $data[5];
		$qualByLociCounts{$alleleCount}++;
	}
	else{
		$qualByLociCounts{0}++;
 		$qualByLociVals{0} += $data[5];
	}
	#return $alleleCount;
	return $histCounts{'1/1'};
}
###############################################################
sub getheaders{
	my $headers = shift;
	my @heads = split(/\s+/,$headers);
	foreach my $i (9 .. $#heads){
		$headers{$i} = $heads[$i];
	}
}	
