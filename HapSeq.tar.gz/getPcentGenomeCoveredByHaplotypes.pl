use warnings;
use strict;

my $outfile = "LengthsOfGapsbetweenScaffolds..txt";

open(OUT, ">$outfile") || die "$outfile $!\n";
print(OUT "Chr\tGap\tLength Of Chr\tProp Chr Not Covered By Scaffolds\n");
close(OUT);
my %hist;
my $histfile = "ScaffoldHistogram.txt";
foreach my $i (1..29){
        my $chr = "Chr$i";
        getGap($chr);
}
printHist();

###########################
sub getGap{
my $chr = shift;	
my $target = $chr . "reduced.phase";
my @files = `ls $target`;
my %scaffs;
my @ends;
foreach my $file (@files){
	open(IN, "<$file") || die "$file $!\n";
	while(<IN>){
		unless(m/^BLOCK/){next}
		my @data = split(/\s+/);
		#print "$data[2] $_ ";
		#if($scaffs{$data[2]}){
			$scaffs{$data[2]} = $data[4];
		#}
		
		$hist{int(log($data[4]))}++;
	}
}
my @starts = sort {$a<=>$b} keys %scaffs;
my $maxend = $scaffs{$starts[0]} + $starts[0];
my $gap = $starts[0];
#print "Number of starts = $#starts\n";
foreach my $i (1..$#starts){
	if($maxend < $starts[$i]){
		$gap += $starts[$i] - $maxend;
	}
	if($maxend < $starts[$i] + $scaffs{$starts[$i]}){
		$maxend = $scaffs{$starts[$i]} + $starts[$i];
	}
}
my $propNotCovered = $gap/$maxend;
open(OUT, ">>$outfile") || die "$outfile $!\n";
print "$chr\t$gap\t$maxend\t$propNotCovered\n";
print (OUT "$chr\t$gap\t$maxend\t$propNotCovered\n");
close(OUT);
	
}
####################################                                                                                                 
sub printHist{                                                                                                                       
        open(OUT, ">$histfile") || die "$histfile $!\n";                                                                             
        my @lengths = sort {$a<=> $b} keys %hist;                                                                                    
        foreach my $len (@lengths){                                                                                                  
                print(OUT "$len\t$hist{$len}\n");                                                                                    
        }                                                                                                                            
        close(OUT);                                                                                                                  
                                                                                                                                     
}   
