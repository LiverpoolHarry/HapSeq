#!/usr/bin/perl
use strict;
use warnings;
use IO::Handle;

#Redirect error messages to log file
open ERROR,  '>', "PerlErrorLog.txt"  or die $!;
STDERR->fdopen( \*ERROR,  'w' ) or die $!;


=pod
Merge output from one or more lanes / plates and remove duplicates. I may adapt this to split BAM files by readgroup 

The first section contains all user modified variables, it should not be necessary to change any of the functions

It has not been extensively tested so almost certainly has bugs.
=cut
my $config = "configMergeAndDedup.txt";
if($ARGV[0]){
        $config = $ARGV[0];
}
my $params ="user_refGenomePath_BWAindex_path_refGenomeFasta_bamFiles_scratchDir_gatkPath_machines_picardPath_";
my @missingParams = split(/_/,$params);
open(IN, "<$config") || die "$config $!\n The following parameters are expected in $config and are missing " . join("\n", @missingParams) ."\n";
my %params;
while(<IN>){
        if(m/^#/){next}
        if(m/ =/){
                chomp();
        #       s/\s+//g;
                my $p = substr($_, 0, index($_,"="));
                $p =~ s/\s+//g;
                my $v = substr($_, index($_,"=") +1);
                if($params =~ m/$p/){
                        my $pu = $p . "_";
                        $params =~ s/$pu//;
                }
                else{
                        die "Parameter $p not recognised\n";
                }
                $params{$p} = $v;
        }
}
close(IN);
if($#missingParams > 0){
        die  "The following parameters are expected in config.txt and are missing " . join("\n", @missingParams) . "\n";
}
print "Parameters for run\n";
foreach my $k (keys %params){
        print"$k\t$params{$k}\n";
}
my (%ids, %samples, @forwardReads, @reverseReads);
open(IN, "<$params{'bamFiles'}") || die "$params{'bamFiles'} $!\n";
my %files;
my $i = 0;
while(<IN>){
        chomp();
        my @data = split(/\s+/);
        $ids{$data[0]} = $1;
        $samples{substr($data[0],0,index($data[0],"_")+1)} = $i;
        $files{$data[0]} = $data[1];

}
if(scalar keys (%ids) > 0 && scalar keys (%samples) > 0){
        print "Found " . scalar values (%ids) . " bam files and " . scalar values (%samples) . "  samples\n";
}else{
        die "No data in list of fastq files\n";
}
foreach my $file (keys %files){
        if($file =~ m/R1/){
                push(@forwardReads, $file);
                $file =~ s/R1/R2/;
                if($files{$file}){
                        push(@reverseReads, $file);
                }
        }
}

#locations and names of readfiles
#use full path from root. Do not use ~/ for home directory
#user name used for monitoring job progress. must be set to your username
my $user = $params{'user'};
#reference indexed genome and reference fasta file the first must have been built from the second
my $path = $params{'path'};
my $refGenomePath = $params{'refGenomePath'};
my $refGenomeFasta = $params{'refGenomeFasta'};

my $gatkJobsPerMachine = 1;
#read group parameters. Required by GATK. Additional parameters are available. see sam file format specification http://samtools.sourceforge.net/SAM1.pdf
#@ids and @samples will be cleared and populated by getIlluminaReads or get5500reads unless the functions are commented out
my $platform = $params{'platform'};

#The jobs will be divided by lane  and distributed over these machines 
my @machines = split(/,/,$params{'machines'});
my @freeMachines = @machines; #will be reset by countScreens;

#Job scheduling parameter
my $sleeptime = 100; #Frequency in seconds between checks on whether mapping run has finished if mapping is expected to take several hours then set this to say 1800 or 3600 

#Picard tools
my $picardPath = $params{'picardPath'};
my $gatkPath = $params{'gatkPath'};
my $scratchDir = $params{'scratchDir'};
$scratchDir =~ s/\s//g;
my $samMergelist;

my @rootNames;
my $alignerName;

my $fileCount = $#forwardReads + 1;

#Build set of chromosomes to break job up into for GATK
#Chromosome names must be exactly as they appear in reference fasta file
my @chr;
foreach my $i (1..29){
	my $chr = "Chr" . $i;
	push (@chr,$chr);
}
push (@chr,"ChrX");
#@chr = ("Chr19");

merge();
###############################################
# Once BWA has finished merge bam files and remove duplicates
sub merge{
	
	my $MergeSamFiles  = $picardPath . "MergeSamFiles.jar";
	my $MarkDuplicates  = $picardPath . "MarkDuplicates.jar";
	my $ValidateSamFile  = $picardPath . "ValidateSamFile.jar";
	my $SortSam  = $picardPath . 'SortSam.jar';
	
	#Get list of unique sample names to iterate over	
	my @uniqueSamples = keys (%samples);
	print"sample list: " . join("; ", keys %samples) . "\n";
	my $sampleCount = 0;
	my $sampleChrCount = 0;
	my $i = 0;	
	foreach my $sample (@uniqueSamples){
				
		#my $dedupped = $sample . "dedup.bam";
		my $realignedBam = $sample . "realigned.bam";
		$sampleCount++;
	
		foreach my $chr (@chr){
			$sampleChrCount++;
			my $samFile = "$path/$sample$chr.bam";
			#print "Samples $samFile\n";
			if(-e $samFile){
				print "Skipping $samFile\n";
				next
			}

			my $mergedFile = $sample  . $chr . ".bam";
			my $dedupped = $sample . $chr . ".dedupped";
			my $picardMergeList = " ";
			my $logfile = $path . "/" . $sample . $chr . "_log.txt";
			my $deduplogfile=  $sample . $chr . "_dedup_log.txt";
			unlink $logfile;
			my $chrBamFiles;
			my $countFilesToMerge = 0;
			my $samtoolViewJobs;
			#Split each bam file into file for each chromosome 
			foreach my $id (keys %ids){
				my @elements = split(/_/,$id);
				my $read = $elements[0]; #substr($elements[1],1). "_F";
			#	print "Sample $sample Read $read\n";
				if(substr($sample,0,-1) eq $read){
					my $outbam = "$scratchDir$id.$chr.bam";
					$samtoolViewJobs .= "cp  $files{$id}  $scratchDir$id.bam\n                                ";
					$samtoolViewJobs .= "cp  $files{$id}.bai  $scratchDir$id.bam.bai\n                                ";
					$samtoolViewJobs .= "samtools view -buh -o $outbam  $scratchDir$id.bam  $chr \n                                ";
					$samtoolViewJobs .= "rm $scratchDir$id.bam\n                                ";
					$samtoolViewJobs .= "rm $scratchDir$id.bam.bai\n                                ";
					$picardMergeList .= " INPUT=$outbam ";
					$chrBamFiles .= " $outbam";
					$countFilesToMerge++;
				}			
			}
			print "Sample Count $sampleCount Sample Chr Count $sampleChrCount\n"; 
			# build shell script
			my $gatkcommand=
				"
				mkdir -p $scratchDir
				cd $scratchDir \n 
				#Split Bam files
				$samtoolViewJobs
				#Merge lane files
				# Could merge all bam files first and then split by chromosomes but merging is memory intensive so best to split first\n
				       
				\n
				#Change location of temporary files from /tmp which is RAM to /scratch which is disk based
				export TMPDIR=/scratch \n
				
				echo 'STARTED Picard merge  at ' `date`| tee -a  $logfile
				 
				# picard mergeSamFiles sorts as it goes \n
				java  -jar $MergeSamFiles $picardMergeList  O=$mergedFile  MERGE_SEQUENCE_DICTIONARIES=true USE_THREADING=true  2>> $logfile\n
				echo 'Finshed Picard merge  at ' `date`| tee  -a $logfile
				
				#remove input files split by chromosome
				rm $chrBamFiles
				
				
				java  -jar $SortSam INPUT=$mergedFile OUTPUT=sorted$mergedFile SORT_ORDER=coordinate 2>> $logfile
				rm $mergedFile
				mv sorted$mergedFile $mergedFile
				echo 'Sorted BAM files ' `date`| tee  -a $logfile
				\n
				#remove duplicates \n
				java  -jar $MarkDuplicates INPUT=$mergedFile  OUTPUT=$dedupped.bam METRICS_FILE=$deduplogfile REMOVE_DUPLICATES=true ASSUME_SORTED=true MAX_FILE_HANDLES_FOR_READ_ENDS_MAP=1000 2>> $logfile\n
				\n
				mv $deduplogfile $path/$deduplogfile 
				echo 'Finished Picard MarkDuplicates  at ' `date`| tee  -a $logfile
				
				#Create index for fast random access \n
				samtools index $dedupped.bam 2>> $logfile\n
		
				echo Created index \n
			
				#Build GATK command for this chromosme
				echo 'STARTED GATK at ' `date`| tee -a  $logfile
					
				#GATK realigner arround indels and resort, index  and then do it again
				java -Xmx2g   -jar $gatkPath -T RealignerTargetCreator  -L $chr -R $refGenomeFasta   -o $sample$chr.intervals  -I $dedupped.bam 2>> $logfile\n
				java -Xmx4g   -jar $gatkPath -T IndelRealigner -I $dedupped.bam -L $chr -R $refGenomeFasta   -targetIntervals $sample$chr.intervals -o $sample$chr.2.bam 2>> $logfile \n
				
				rm $sample$chr.intervals
				rm $dedupped.bam
				rm $dedupped.bam.bai
##### ERROR MESSAGE: Couldn't read file /scratch/path/62_Chr1.bam because file is not present or user does not have appropriate permissions.  Please check that the file is present and readable and try again.
				
				
				
			
				java  -jar $SortSam I=$sample$chr.2.bam O=$sample$chr$realignedBam  SO=coordinate \n
				rm $sample$chr.2.bam
				rm $sample$chr.2.bam.bai
	
				
				mv $sample$chr$realignedBam $sample$chr.bam
				
				samtools index $sample$chr.bam
				
				java -Xmx2g   -jar $gatkPath -T RealignerTargetCreator  -L $chr -R $refGenomeFasta   -o $sample$chr.intervals  -I $sample$chr.bam 2>> $logfile\n
				java -Xmx4g   -jar $gatkPath -I $sample$chr.bam  -L $chr -R $refGenomeFasta  -T IndelRealigner -targetIntervals $sample$chr.intervals -o $sample$chr.2.bam 2>> $logfile \n
				
				rm $sample$chr.intervals 
				rm $sample$chr.bam
				
				
				java   -jar $SortSam I=$sample$chr.2.bam O=$sample$chr$realignedBam  SO=coordinate  2>> $logfile \n
				
				rm $sample$chr.2.bam
				rm $sample$chr.2.bai
				
				mv $sample$chr$realignedBam $sample$chr.bam
				
				samtools index $sample$chr.bam  2>> $logfile
				
				echo 'Finished GATK Realigner  at ' `date`| tee  -a $logfile
				
			
				mv $logfile $path/$logfile
				mv $sample$chr.bam $path/$sample$chr.bam
				mv $sample$chr.bam.bai $path/$sample$chr.bam.bai
				
		
			";
		
			#Write shell script to file and start a seperate screen for each chromosome
				my $shellfile = "run_" . $sample . $chr . "GATK.sh";
				my $machine =shift(@freeMachines);
				my $com =  "screen -dm -S $sample$chr ssh $machine nice bash $path/$shellfile ";
				print "$com\n";
				
				open (SH, ">$shellfile") || die "$shellfile  $!\n";
				print (SH "#$com\n\n");			
				print (SH $gatkcommand );
				close(SH);
				system "echo $com | tee $logfile";
				system "chmod 755 $shellfile";				
				system $com;
				$i++;

				@freeMachines = @{countScreens(\@machines, $gatkJobsPerMachine)};
				sleep(10);
				last;
		}
		last;
	}
	
}

#################################################
#Started shell scripts in independent screens now monitor them until they finish before running merge
sub waitForScreens{
	
	my $names = shift;
	my @names =@{$names};
	my $flag = "false";
	my $start = time;
	my $teststring = "XXXXX";
	while(length($teststring) > 1){
			
		 
			#get list of jobs in screens for user and 
			#add those that match files in @rootNames to list of running jobs
			#keep iterating until list of running jobs is empty
			system "ps -ef | grep SCREEN | grep $user  > screenLog.txt";
			$teststring = " ";
			open (LOG, '<screenLog.txt') || die "screenLog.txt $!\n";
			my $l = 0;
			my $completeProcesses = " ";
			while(<LOG>){
				 
				 my $line = $_;
				 foreach my $name (@names){
					if($line =~ m/$name/){	
						$teststring .= $name;
						$completeProcesses .=  "$name; ";
						$l++;
					}
				}
				
			 }
			close(LOG);
			my $elapsed = time - $start;
			#print " Waiting for $alignerName, $l processes still running: $completeProcesses time so far $elapsed s\n"; #for debugging
			if(length($teststring) > 2){
				sleep($sleeptime);
			}
	 }
 
}
#################################################
#Started shell scripts in independent screens now monitor them until they finish before running merge
sub countScreens{
	my $names = shift;
	my $jobsPerMachine = shift;
	my @names =@{$names};
	my $flag = "false";
	my $start = time;
	my $l = 0;
	my @fMachines;#free machines
	#an earlier version checked for the presence of file names because machines might have other SCREENS running
	#that are not generated by this script. However it seems better to take that risk and increase confidence
	#of assigning jobs to the correct machine
	while($flag eq "false"){
			#get list of jobs in screens for user and 
			#add those that match files in @rootNames to list of running jobs
			#keep iterating until list of running jobs is empty
			system "ps -ef | grep SCREEN | grep $user | grep watt > screenLog.txt";
			my $teststring = " ";
			open (LOG, '<screenLog.txt') || die "screenLog.txt $!\n";
			my $l = 0;
			my @runningProcesses;
			while(<LOG>){
				 my $line = $_;
				
				 foreach my $mac (@machines){
					if($line =~ m/$mac/){	
						$teststring .= $mac;
						push (@runningProcesses, $mac);
						$l++;
					}
				}
			 }
			close(LOG);
			my $elapsed = time - $start;
			#print " Waiting for  $l machines still running: $teststring  time so far $elapsed s\n"; #for debugging
			if($#runningProcesses >= $#machines * $jobsPerMachine){
				sleep(60);				
			}
			else{
				$flag = "true";
			}
			#get next free machine
			foreach my $mac (@machines){
				my $countProcessesOnMachine = $teststring =~ s/$mac/$mac/g;
				if($countProcessesOnMachine < $jobsPerMachine){
					foreach ($countProcessesOnMachine ..$jobsPerMachine - 1){
						push(@fMachines, $mac);
					}
				}
			}
	}
	return(\@fMachines);
}
