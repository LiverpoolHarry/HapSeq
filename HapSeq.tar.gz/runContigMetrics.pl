use strict;
use warnings;
use Cwd;
#get all bam files in a directory tree
my $contigMetrics = "path/picard/trunk/dist/ContigMetrics.jar";
my @chros = (15..29);
#push (@chros, "X");
map ($_ = "Chr" . $_,  @chros) ;
#@chros = ("Chr25");
print "Chros: " . join(", ", @chros) . "\n";
my $logfile = "ScaffoldLog.txt";
unlink($logfile);
foreach my $chr (@chros){
  my @files = `find path -name '*Chr*.bam' | grep $chr.bam 2>&1`;
 #a bed file listing the coordinates of repeats this is available form repeat masker for commonlu used  genomes 
  my $repeatsFile = "path/" . $chr . ".mergedRepeats.bed";
  my $i = 0;
	#multiple gap lengths for joining contigs into scaffodls can be tested by uncommenting this line and the corresponding foreach statement
  #my @gaps = (500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000);
  foreach my $file (@files){
	$i++;
	chomp($file);
	#print "$file\n";
	#foreach my $gap (@gaps){
		my $gap = 1000;
		my $root = substr($file,rindex($file,"/")+1,-4);
		print "$file\n";
		unlink("$root.interval_list");
		unlink("$root.percentiles.txt");
		unlink("$root.contig_gaps");
		unlink("$root.contig_counts_in_scaffolds");
		my $com = "java -jar $contigMetrics  INPUT=$file  MIN_MAP_QUAL=20 LENGTH_OF_GAP=1000 MAX_ABS_GAP=$gap PROP_SCAFFOLD_COVERED=1.0  REFERENCE_SEQUENCE=path/index/umd31all.fasta MAX_Z_GAP=3 OUTPUT=$root.percentiles.txt  CONTIGS_FILE=$root.contigs CONTIG_LENGTHS_FILE=$root.contig_lengths COUNT_CONTIGS_IN_SCAFFOLDS_FILE=$root.contig_counts_in_scaffolds CONTIG_GAPS_FILE=$root.contig_gaps INTERVAL_LIST_ZSCORE=$root.zscore.interval_list INTERVAL_LIST_PROPORTION=$root.prop.interval_list COVERAGE_FILE=$root.prop.coverage MIN_CONTIG_LENGTH=50 MIN_SCAFFOLD=1000 REPEATS_FILE=$repeatsFile  2>> $logfile ";
		print "$com\n\n";
		system $com;
	#}
	}
}

