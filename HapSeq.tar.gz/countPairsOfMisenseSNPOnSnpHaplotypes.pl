use strict;
use warnings;
use lib 'path/lib/ensembl/ensembl/modules/';
use lib 'path/lib/ensembl/ensembl-variation/modules/';
use lib 'path/gatk/vcftools_0.1.7/lib/';
use Vcf;
use Bio::EnsEMBL::Registry;
use Bio::EnsEMBL::Variation::VariationFeature;

open(GENES, ">EnsemblGenes.txt") || die "EnsemblGenes.txt $! \n";
print(GENES "Chr\tStart\tEnd\tEnsemblId\tDescription\tMissenseCount\tSynonymousCount\n");
open(LOG, ">MissenseCountsFosmidsSNPhaplotypes.txt") || die "MissenseCounts.txt $! \n";
print (LOG "EAZ Fosmids\n"); 
print (LOG "File\tTotal Missense SNP in Haplotypes\tLinked Missense SNP in Haplotypes\n");
# get registry
my $reg = 'Bio::EnsEMBL::Registry';
$reg->load_registry_from_db(-host => 'ensembldb.ensembl.org',-user => 'anonymous');
my $vfa = $reg->get_adaptor('cow', 'variation', 'variationfeature');
my $sa = $reg->get_adaptor('cow', 'core', 'slice');
my $transcript_adaptor =$reg->get_adaptor('cow', 'core','Transcript');
foreach my $chr (1..29){
	if($chr == 8 || $chr ==10) {next}
	my $slice = $sa->fetch_by_region('chromosome', $chr);
	my @genes = @{ $slice->get_all_Genes() };
	my $i = 0;
	my %MissenseSnp; 
	my $interStart = 0;
	my $totalCount = 0;
	my $linkedMissense = 0;
	foreach my $gene (@genes){
		$i++;
        	my $start = $gene->start();
        	my $region = "Chr" . $chr . ":" . $start . "-" . $gene->end();;
		my $com = " ~/gatk/bcftools/bcftools/bcftools view --regions $region ../sih/vcfFiles/Chr$chr.ann.sort.vcf.gz | ~/gatk/bcftools/bcftools/bcftools query --format '" . "%CHROM\t%POS\t%INFO/Cons\t%INFO/EnsId\t%INFO/Desc\n" ."'";
		my @output = `$com`;
		my $count =0;
		my $prePos = 0;
		my @res;
		$res[4] = " ";
		my $missenseCount = 0;
		my $synonymousCount = 0;
		foreach my $out(@output){
			chomp($out);
			
			@res = split(/\t/,$out);
			if($out =~ m/synonymous/){
				$synonymousCount++;
			}
			if($out =~ m/missense/){
				$missenseCount++;
				if($prePos == 0){
					$prePos = $res[1];
					next;
				}	
				$MissenseSnp{"$prePos-$res[1]"} = 1;
				$count++;
				$prePos = $res[1];
			}
		}
		print(GENES "Chr$chr\t$start\t" . $gene->end() . "\t$res[3]\t$res[4]\t$missenseCount\t$synonymousCount\n"); 
		$totalCount += $count;
		if($count > 1){
			$linkedMissense += $count;
		}
	}
	print (LOG "Count Genes\t$i\n");		
	print (LOG "Genes\t$totalCount\t$linkedMissense\n");

	#Chr3.reduced.reduced.Fosmids.phase
	my $file = "../targetcut/Chr$chr" . '.reduced.reduced.Fosmids.phase';
	#my @gff3files = `find $search`;
	#foreach my $file (@gff3files){
	#	chomp($file);
	#	my $lib = substr($file,index($file,"Scaffolds")+10, rindex($file,"_") - index($file,"Scaffolds") - 10);
	#	if($lib =~ m/^[0-9]/){next}
		open(IN, "<$file") || die "$file $!\n";
		$totalCount = 0;
		$linkedMissense = 0;
		while(<IN>){
			unless(m/^BLOCK/){next}
			
			my @data = split(/\s+/);
			my $end = $data[2] + $data[4];
			my $position = "Chr$chr" . ":" . $data[2] . "-" . $end;

			my $com = " ~/gatk/bcftools/bcftools/bcftools view --regions $position ../sih/vcfFiles/Chr$chr.ann.sort.vcf.gz | ~/gatk/bcftools/bcftools/bcftools query --format '" . "%CHROM %POS %INFO/Cons\n" . "'  | grep  missense";
			my @output = `$com`;
			my $count =0;
			my $prePos = 0;
 			foreach my $out(@output){
				chomp($out);
				if($out =~ m/missense/){
					my @res = split(/\s+/,$out);
					if($prePos == 0){
						$prePos = $res[1];
						next;
					}
					if($MissenseSnp{"$prePos-$res[1]"}){	
						$MissenseSnp{"$prePos-$res[1]"}++;
						$count++;
					}
					$prePos = $res[1];
				}
			}
			$totalCount += $count;
			if($count > 1){
				$linkedMissense += $count;
			}
		}
		close(IN);
		print "$file $totalCount, $linkedMissense\n";
		print (LOG "$file\t$totalCount\t$linkedMissense\n");
		#last;
	#}
	my %hapCounts;
	my %seperations;
	foreach my $key (sort  keys %MissenseSnp){
                $hapCounts{$MissenseSnp{$key}}++;
                my ($first, $second) = split(/-/,$key);
                my $sep = $second - $first;
                $seperations{$MissenseSnp{$key}} += $sep;
                #print(LOG "Chr$chr\t$key\t$MissenseSnp{$key}\n");
        }
        print(LOG "Number Of Times Haplotype Observed\tNumber of two SNP haplotypes\n");
        foreach my $key (sort {$a<=>$b}  keys %hapCounts){
                my $count = $key -1;
                print(LOG "$count\t$hapCounts{$key}\t$seperations{$key}\n");
        }

}			
	

close(LOG);
close(GENES);
