use strict;
use warnings;

my @files = `ls path/*L00*.bam`;
open (OUT, ">bamfiles.txt") || die "bamfiles.txt $!\n";

foreach my $file (@files){
	chomp($file);
	print(OUT substr($file,rindex($file,"/")+ 1 ,-4) . "\t$file\n");
}
close(OUT); 

