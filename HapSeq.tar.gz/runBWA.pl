#!/usr/bin/perl
use strict;
use warnings;
use IO::Handle;

#Redirect error messages to log file
open ERROR,  '>', "PerlErrorLog.txt"  or die $!;
STDERR->fdopen( \*ERROR,  'w' ) or die $!;


=pod
1) Run BWA including csfasta2fastq if desired each fastq file is sent off to run on a seperate machine 

The first section contains all user modified variables, it should not be necessary to change any of the functions

It has not been extensively tested so almost certainly has bugs.
=cut
my $config = "BWAconfig.txt";
if($ARGV[0]){
	$config = $ARGV[0];
}
my $params ="user_refGenomePath_BWAindex_path_refGenomeFasta_fastqFiles_bwaParams_bwaSwitches_platform_machines_picardPath_";
open(IN, "<$config") || die "$config $1\n";
my %params;
while(<IN>){
	if(m/^#/){next}
	if(m/ =/){
		chomp();
	#	s/\s+//g;
		my $p = substr($_, 0, index($_,"="));
		$p =~ s/\s+//g;
		my $v = substr($_, index($_,"=") +1);
		if($params =~ m/$p/){
			my $pu = $p . "_";
			$params =~ s/$pu//;
		}
		else{
			die "Parameter $p not recognised\n";
		}
		$params{$p} = $v;
	}
}
close(IN);
my @missingParams = split(/_/,$params);
if($#missingParams > 0){
	die  "The following parameters are expected in config.txt and are missing " . join("\n", @missingParams);
}	
print "Parameters for run\n";
foreach my $k (keys %params){
	print"$k\t$params{$k}\n";
}
my (%ids, %samples, @forwardReads, @reverseReads);
open(IN, "<$params{'fastqFiles'}") || die "$params{'fastqFiles'} $!\n";
my %files;
while(<IN>){
	chomp();
	my @data = split(/\s+/);
	$ids{$data[1]} = $data[0];	
	$samples{$data[1]} = substr($data[0],0,index($data[0],"_"));
	$files{$data[1]} = $data[1];
}
if(scalar keys (%ids) > 0 && scalar keys (%samples) > 0){
	print "Found " . scalar keys (%ids) . " ids and " . scalar keys (%samples) . "  fastq files\n";
}else{
	die "No data in list of fastq files\n";
}
foreach my $file (keys %files){
	if($file =~ m/R1/){
		push(@forwardReads, $file);
		$file =~ s/R1/R2/;
		if($files{$file}){
			push(@reverseReads, $file);
		}
	}
}

#locations and names of readfiles
#use full path from root. Do not use ~/ for home directory
#user name used for monitoring job progress. must be set to your username
my $user = $params{'user'};

#reference indexed genome and reference fasta file the first must have been built from the second
my $path = $params{'path'};
my $refGenomePath = $params{'refGenomePath'};
my $BWAindex = $params{'BWAindex'};
my $refGenomeFasta = $params{'refGenomeFasta'};

#BWA parameters. Set any legal BWA params as key => value pairs in hash 
# and add switches which take no values such as -c to array use " " if no switches used
#-N=> 0 do not output dicordant read pairs
#-n=>2 only output alignments if it has two or less alignemnts
my $bwaParams = $params{'bwaParams'};
my $bwaSwitches = $params{'bwaSwitches'};
unless($bwaSwitches){
	$bwaSwitches = " ";
}
unless($bwaParams){
	$bwaParams = " ";
}

#read group parameters. Required by GATK. Additional parameters are available. see sam file format specification http://samtools.sourceforge.net/SAM1.pdf
#@ids and @samples will be cleared and populated by getIlluminaReads or get5500reads unless the functions are commented out
my $platform = $params{'platform'}; 

#The jobs will be divided by lane  and distributed over these machines 
my @machines = split(/,/,$params{'machines'});
my @freeMachines = @machines; #will be reset by countScreens;

#I usually set the BWA mapping to use the same number of threads as there are processors on the machine 
#so it is only appropriate to run one job at a time.
my $mappingJobsPerMachine = 1;

#Job scheduling parameter
my $sleeptime = 100; #Frequency in seconds between checks on whether mapping run has finished if mapping is expected to take several hours then set this to say 1800 or 3600 

#Picard tools
my $picardPath = $params{'picardPath'};

my $samMergelist;

my @rootNames;
my $alignerName;
my $scratch = "/scratch/$user/";

my $fileCount = $#forwardReads + 1;
runBWA();
####################################################################################
#Build BWA script for each fastq file
sub runBWA{
	my $SortSam  = $picardPath . 'SortSam.jar';
	foreach my $i (0..$#forwardReads){
		
		#Build parameters for each file. Filename may contain path
		my $fastqF = $forwardReads[$i];
		my $fastqR = " ";
		if($reverseReads[$i]){
                        $fastqR = $reverseReads[$i];
		}
		my $rootName = substr($forwardReads[$i],rindex($forwardReads[$i],"\/") + 1);
		$rootName = substr($rootName, 0, index($rootName, ".fastq"));
		push(@rootNames,$rootName);
		my $fSai = $ids{$fastqF} . ".sai";
		my $rSai = $ids{$fastqF}  . "R.sai";
		my $sam = $ids{$fastqF}  . ".sam";
		my $bam = $ids{$fastqF}  . ".bam";
		my $bai = $ids{$fastqF}  . ".bam.bai";
		my $sortedBam = $ids{$fastqF}  . ".sorted.bam";

		
		my $rgs = ("\'\@RG\\tID:" . $ids{$fastqF} . "\\tPL:" . $platform . "\\tSM:" . $samples{$fastqF} . "\'");
		my $logfile = $ids{$fastqF}  . "_log.txt"; 	
		
		#build list of parameters for BWA
		my $bwaParamList = " ";
		#build BWA query depending on whether paired ed or not
		my $bwaAlign;
		if($reverseReads[$i]){
			$bwaAlign = "bwa aln $bwaParams $bwaSwitches $BWAindex $fastqF > $scratch$fSai 2>> $logfile  \n
		     		     bwa aln $bwaParams $bwaSwitches $BWAindex $fastqR > $scratch$rSai 2>> $logfile  \n
				     bwa sampe -r $rgs $BWAindex $scratch$fSai $scratch$rSai $fastqF $fastqR > $scratch$sam 2>>  $logfile \n
				     rm -f $scratch$fSai \n
				     rm -f $scratch$rSai \n";
		}
		else{
			$bwaAlign = "bwa aln $bwaParamList $BWAindex $fastqF > $scratch$fSai 2>> $logfile  \n
			
			bwa samse -r $rgs $BWAindex $scratch$fSai $fastqF > $scratch$sam 2>> $logfile \n
						
			rm -f $scratch$fSai \n";
		}
		
		#Build shell script for BWA
		my $shellscript = "
		mkdir -p $scratch
		cd $path \n
		echo 'STARTED BWA  at ' `date`| tee   $logfile
		echo 'STARTED BWA for $fastqF at ' `date`
		$bwaAlign \n

		echo 'aligned ' $forwardReads[$i]  `date` | tee -a  $logfile \n\n
		
		#Count matching lines
		grep -c Chr $scratch$sam >> MappedLines.txt
		
		#Convert sam :to bam (binary) -F 4 removes unmapped lines (Flag contains 4)\n
		#-bSuh is bam output; sam input, uncompreesed output, headers carried over
		
		samtools view -bSuh -F 4 -o $scratch$bam $scratch$sam \n
		
		echo 'Converted sam to bam' `date` | tee -a  $logfile \n
	
		rm $scratch$sam \n
	
		#Sort and index bam file so that individual chromosomes can be extracted
		java -jar $SortSam INPUT=$scratch$bam OUTPUT=$scratch$sortedBam SORT_ORDER=coordinate 2>> $logfile  \n
		mv $scratch$sortedBam $scratch$bam 
		samtools index $scratch$bam
		echo 'Sorted bam' `date` | tee -a  $logfile \n
		mv $scratch$bam $bam \n
		mv $scratch$bai $bai \n
		echo 'Finished BWA for $fastqF at ' `date`
		";
		
		#Write shell script to file change permissions and launch in an anonymous screen	
		my $shellfile = "run_" . $rootName  . ".sh"; 

		open (SH, ">$shellfile") || die "$shellfile  $!\n";
		print (SH $shellscript);
		close(SH);
		system "chmod 755 $shellfile";

		my $machine = pop(@freeMachines);
		
		my $com =  "screen -dm  -S $ids{$fastqF}  ssh $machine nice bash $path/$shellfile ";
		open(OUT, ">$logfile") || die "$logfile $!\n";
		print (OUT "$com\n\n");
		close(OUT);
		
		print "$com\n";
		if($machine){
			system $com;
		}

		@freeMachines = @{countScreens(\@rootNames, $mappingJobsPerMachine)};
		last;
	}
	
	waitForScreens(\@rootNames);
	#Get list of numbers of mapped lines and remove sam files
}

#################################################
#Started shell scripts in independent screens now monitor them until they finish before running merge
sub waitForScreens{
	
	my $names = shift;
	my @names =@{$names};
	my $flag = "false";
	my $start = time;
	my $teststring = "XXXXX";
	while(length($teststring) > 1){
			
		 
			#get list of jobs in screens for user and 
			#add those that match files in @rootNames to list of running jobs
			#keep iterating until list of running jobs is empty
			system "ps -ef | grep SCREEN | grep $user  > screenLog.txt";
			$teststring = " ";
			open (LOG, '<screenLog.txt') || die "screenLog.txt $!\n";
			my $l = 0;
			my $completeProcesses = " ";
			while(<LOG>){
				 
				 my $line = $_;
				 foreach my $name (@names){
					if($line =~ m/$name/){	
						$teststring .= $name;
						$completeProcesses .=  "$name; ";
						$l++;
					}
				}
				
			 }
			close(LOG);
			my $elapsed = time - $start;
			#print " Waiting for $alignerName, $l processes still running: $completeProcesses time so far $elapsed s\n"; #for debugging
			if(length($teststring) > 2){
				sleep($sleeptime);
			}
	 }
 
}
#################################################
#Started shell scripts in independent screens now monitor them until they finish before running merge
sub countScreens{
	my $names = shift;
	my $jobsPerMachine = shift;
	my @names =@{$names};
	my $flag = "false";
	my $start = time;
	my $l = 0;
	my @fMachines;#free machines
	#an earlier version checked for the presence of file names because machines might have other SCREENS running
	#that are not generated by this script. However it seems better to take that risk and increase confidence
	#of assigning jobs to the correct machine
	while($flag eq "false"){
			#get list of jobs in screens for user and 
			#add those that match files in @rootNames to list of running jobs
			#keep iterating until list of running jobs is empty
			system "ps -ef | grep SCREEN | grep $user | grep watt > screenLog.txt";
			my $teststring = " ";
			open (LOG, '<screenLog.txt') || die "screenLog.txt $!\n";
			my $l = 0;
			my @runningProcesses;
			while(<LOG>){
				 my $line = $_;
				
				 foreach my $mac (@machines){
					if($line =~ m/$mac/){	
						$teststring .= $mac;
						push (@runningProcesses, $mac);
						$l++;
					}
				}
			 }
			close(LOG);
			my $elapsed = time - $start;
			#print " Waiting for  $l machines still running: $teststring  time so far $elapsed s\n"; #for debugging
			if($#runningProcesses >= $#machines * $jobsPerMachine){
				sleep(60);				
			}
			else{
				$flag = "true";
			}
			#get next free machine
			foreach my $mac (@machines){
				my $countProcessesOnMachine = $teststring =~ s/$mac/$mac/g;
				if($countProcessesOnMachine < $jobsPerMachine){
					foreach ($countProcessesOnMachine ..$jobsPerMachine - 1){
						push(@fMachines, $mac);
					}
				}
			}
	}
	return(\@fMachines);
}
