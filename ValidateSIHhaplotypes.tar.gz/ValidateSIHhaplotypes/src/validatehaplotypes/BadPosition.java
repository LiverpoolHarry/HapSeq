/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package validatehaplotypes;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author harry
 */
public class BadPosition {

   private HashMap<String, Short> seqGenotypes;//Library; genotype
   private Short originalBeagleGenotype;
   private Short correctedBeagleGenotype;
   private Integer position;
   private String seqRef;
   private String seqAlt;
   private String hdRef;
   private String hdAlt;
   private String hdStrand;
   private int countBad;
   private final Short mOne = -1;
   private String status;

   public BadPosition(String status, Integer position, String lib, Short gen, Short bg, Short cbg, String sr, String sa, String hr, String ha, String hs) {
      this.position = position;
      seqGenotypes = new HashMap<String, Short>();
      seqGenotypes.put(lib, gen);
      this.originalBeagleGenotype = bg;
      this.correctedBeagleGenotype = cbg;
      this.seqRef = sr;
      this.seqAlt = sa;
      this.hdRef = hr;
      this.hdAlt = ha;
      this.hdStrand = hs;
      this.status = status;

      countBad = 1;
   }

   public void addLibrary(String lib, Short gen) {
      seqGenotypes.put(lib, gen);
      countBad++;
   }

   public int getCountBad() {
      return countBad;
   }

   public void setCorrectedBeagleGenotype(Short correctedBeagleGenotype) {
      this.correctedBeagleGenotype = correctedBeagleGenotype;
   }

   public Short getCorrectedBeagleGenotype() {
      if (correctedBeagleGenotype != null) {
         return correctedBeagleGenotype;
      }
      else {
         return mOne;
      }
   }

   public void setStatus(String status) {
      this.status = status;
   }

   public String getOutputLine() {
      StringBuilder out = new StringBuilder();
      out.append(status + ", " + position + ", " + seqRef + ", " + seqAlt + ", " + hdRef + ", " + hdAlt + ", " + hdStrand + ", " + originalBeagleGenotype + ", " + getCorrectedBeagleGenotype());
       for (String lib : seqGenotypes.keySet()) {
         out.append(", " + lib + ", " + seqGenotypes.get(lib));
      }
      return out.toString();
   }

   public String getheaderLine() {
      return ("Position,Sequence Ref Allele, Sequence Alt Allele, HD chip Ref Allele, HD chip Alt Allele, HD Chip Strand, Uncorrected Beagle Genotype, Corrected beagle Genotype, 1st Library, 1st Library genotype, 2nd Library, Second Library Genotype");
   }
}
