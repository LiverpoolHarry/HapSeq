/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package validatehaplotypes;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author harry
 */
public class Params {

   private String chr;
   private String gff3path = "";
   private String vcfFile;
   private String beagleFile;
   private String input012file = null; //if present this file will be used instead of generating one from vcf file
   private String illuminaHdFile;
   private String sihFile;
   private Short matchLength = 2;
   private HashMap<String, Short> shortAlleles;
   public static final Short mOne = -1;
   public static final Short zero = 0;
   public static final Short one = 1;
   public static final Short two = 2;
   public static final Short three = 3;
   public static final Short four = 4;
   private ArrayList<String> sampleNames;
   private ArrayList<Integer> allelePositions;
   private TreeMap<Integer, Short> beagleAlleles;
   private TreeMap<Integer, RefAndAltAlleles> hdRefAndAltAlleles;//key position; refAndAlt Alleles from IlluminaHdFile
   private final String vcftools = "/pub7/harry/gatk/vcftools_0.1.7/bin/";

   public Params(HashMap<String, String> comLineVars) {
      if (comLineVars.containsKey("gff3path")) {
         this.gff3path = comLineVars.get("gff3path");
         if (!gff3path.endsWith("/")) {
            gff3path = gff3path + "/";
         }
      }
      if (comLineVars.containsKey("012file")) {
         input012file = comLineVars.get("012file");
      }
      if (comLineVars.containsKey("matchLength")) {
         matchLength = Short.parseShort(comLineVars.get("matchLength"));
         if (matchLength < 2) {
            matchLength = 2;
         }
      }
      sihFile = comLineVars.get("sihFile");
      vcfFile = comLineVars.get("vcfFile");
      beagleFile = comLineVars.get("beagleFile");
      illuminaHdFile = comLineVars.get("illuminaHdFile");
      sampleNames = new ArrayList<String>();
      chr = comLineVars.get("chr");
      shortAlleles = new HashMap<String, Short>(6);
      shortAlleles.put("-1", mOne);
      shortAlleles.put("0", zero);
      shortAlleles.put("1", one);
      shortAlleles.put("2", two);
      shortAlleles.put("3", three);
      shortAlleles.put("4", four);


   }

   public String getChr() {
      return chr;
   }

   public String getGff3path() {
      return gff3path;
   }

   public String getVcfFile() {
      return vcfFile;
   }

   public String getSihFile() {
      return sihFile;
   }

   public String getVcftools() {
      return vcftools;
   }

   public HashMap<String, Short> getShortAlleles() {
      return shortAlleles;
   }

   public ArrayList<String> getSampleNames() {
      return sampleNames;
   }

   public TreeMap<Integer, RefAndAltAlleles> getHdRefAndAltAlleles() {
      return hdRefAndAltAlleles;
   }

   public String getInput012file() {
      return input012file;
   }

   public Short getMatchLength() {
      return matchLength;
   }

   //build treemap of alleles keyed by position for each subcell
   protected ArrayList<Integer> getAllelePositions(String filename) {
      allelePositions = new ArrayList<Integer>();
      String path = System.getProperty("user.dir");
      File file = new File(filename);
      //Build array of allele positions
      allelePositions.clear();

      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;
         while ((strLine = br.readLine()) != null) {
            String[] posit = strLine.split("\t");
            allelePositions.add(Integer.parseInt(posit[1]));
         }
         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
      }


      System.out.println("Got " + allelePositions.size() + " snp positions from " + filename + ".012.pos");
      return allelePositions;
   }

   protected HashMap<String, TreeMap<Integer, Short>> getAlleles(HashMap<String, TreeMap<Integer, Short>> chroAllelePos, String filename) {
      String path = System.getProperty("user.dir");
      File file = new File(filename);
      System.out.println("Getting alleles from " + filename);
      //Build array of allele positions
      int lineCount = 0;
      int allCount = 0;


      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;
         while ((strLine = br.readLine()) != null) {
            lineCount++;
            String[] alleles = strLine.split(";");
            TreeMap<Integer, Short> posAlleles = new TreeMap<Integer, Short>();
            String lib = sampleNames.get(Integer.parseInt(alleles[0]));
            // sampleNames.add(lib);
            for (int d = 1; d < alleles.length; d++) {

               if (!alleles[d].contentEquals("-1")) {
                  posAlleles.put(allelePositions.get(d), shortAlleles.get(alleles[d]));
               }
            }
            chroAllelePos.put(lib, posAlleles);
         }

         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
      }
      System.out.println("Lines in 012 file" + lineCount + " Allele Count = " + allCount);

      return chroAllelePos;
   }

   public ArrayList<TreeMap<Integer, Short>> getSIHhaplotypes() {
      int blockCount = -1;
      int lineCount = 0;
      int posCount = 0;
      HashMap<String,Short> phaseAlleles = new HashMap<String,Short>();
      phaseAlleles.put("0", zero);
      phaseAlleles.put("1", two);
      Pattern digits = Pattern.compile("^\\d{5}");
      ArrayList<TreeMap<Integer, Short>> sihHaps = new ArrayList<TreeMap<Integer, Short>>();
      try {
         FileInputStream fstream = new FileInputStream(sihFile);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;
         while ((strLine = br.readLine()) != null) {
            lineCount++;
            Matcher m = digits.matcher(strLine);
            if(m.find()){
               String[] alleles = strLine.split("\\t");
               sihHaps.get(blockCount).put(Integer.parseInt(alleles[0]), phaseAlleles.get(alleles[1]));
               posCount++;
            }
            else if(strLine.startsWith("BLOCK")){
               sihHaps.add(new TreeMap<Integer, Short>());
               blockCount++;
            }
          }
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error: " + e.getMessage());
         e.printStackTrace();
      }
      System.out.println("Got " + blockCount + " phase haplotypes from " + sihFile);
      System.out.println("Read " + lineCount + " lines and " + posCount + " positions from " + sihFile);

      return sihHaps;
   }

   public void deleteFile(String filename) {
      try {
         File file = new File(filename);
         if (file.delete()) {
            System.out.println(file.getName() + " is deleted!");
         }
         else {
            System.out.println("Delete of " + filename + " failed.");
         }
      }
      catch (Exception e) {
         e.printStackTrace();
      }
   }

   public TreeMap<Integer, Short> readBeagleFile() {
      beagleAlleles = new TreeMap<Integer, Short>();// Position, RefAndAltAlleles
      TreeMap<Integer, Integer> beaglePositions = new TreeMap<Integer, Integer>();//snp_id, position
      int lineCount = 0;
      String chrDigit = chr.substring(3);
      System.out.println("Getting beagle data for BTA" + chrDigit);
      //int headerCount = 0;
      File file = new File(beagleFile);
      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream:

         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));
         String strLine;
         String[] data;
         while ((strLine = br.readLine()) != null) {
            lineCount++;
            data = strLine.split("\t");
            if (lineCount == 1 || !data[1].contentEquals(chrDigit)) {
               continue;
            }

            Integer position = Integer.parseInt(data[2]);
            beagleAlleles.put(position, shortAlleles.get(data[3]));
            beaglePositions.put(Integer.parseInt(data[0]), position);

         }
         in.close();
      }
      catch (Exception e) {
         System.err.println("File Open Error: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
      }
      readIlluminaHdFile(beaglePositions);
      return beagleAlleles;
   }

   //Read Beagle genotypes first, then for each Illumina HD SNP check if SNP_ID is in beagle genotypes set;
   //if true then use position from beagle file to set co-ordinate of HD alleles
   public void readIlluminaHdFile(TreeMap<Integer, Integer> beaglePositions) {
      hdRefAndAltAlleles = new TreeMap<Integer, RefAndAltAlleles>();// Position, RefAndAltAlleles

      int matchesCount = 0;

      try {
         FileInputStream fstream = new FileInputStream(illuminaHdFile);
         // Get the object of DataInputStream:

         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));
         String strLine;
         String[] data;
         while ((strLine = br.readLine()) != null) {
            if (strLine.startsWith("snp_number")) {
               continue;
            }
            data = strLine.split(",");
            Integer snp_id = Integer.parseInt(data[0]);
            if (beaglePositions.containsKey(snp_id)) {
               Integer position = beaglePositions.get(snp_id);
               RefAndAltAlleles raa = new RefAndAltAlleles(chr, position, position, data[5], data[6], data[3], beagleAlleles.get(position).shortValue());
               hdRefAndAltAlleles.put(position, raa);
               matchesCount++;
            }
         }
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error: " + e.getMessage());
         System.out.println("Failed to open Filename:" + illuminaHdFile);
         e.printStackTrace();
      }
      System.out.println(matchesCount + " entries in " + illuminaHdFile + " matched entries in " + beagleFile);
   }

   public TreeMap<Integer, RefAndAltAlleles> readVCFFile(File file) {
      TreeMap<Integer, RefAndAltAlleles> allRefAndAltAlleles = new TreeMap<Integer, RefAndAltAlleles>();// Position, RefAndAltAlleles
      int lineCount = 0;
      int headerCount = 0;

      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream:

         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));
         String strLine;
         String[] data;
         while ((strLine = br.readLine()) != null) {
            if (!strLine.startsWith(chr)) {
               headerCount++;
               continue;
            }
            data = strLine.split("\t");
            Integer position = Integer.parseInt(data[1]);

            RefAndAltAlleles raa = new RefAndAltAlleles(data[0], position, position, data[3], data[4], "SNP", null);
            allRefAndAltAlleles.put(position, raa);
         }
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.out.println("Caught error at Params line 415 after processing " + lineCount + " lines and " + headerCount + " header lines from " + file.getAbsolutePath());
         e.printStackTrace();
      }
      return allRefAndAltAlleles;
   }

   protected void getSampleNamesFrom012(String filename) {

      String path = System.getProperty("user.dir");
      File file = new File(filename);


      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;
         while ((strLine = br.readLine()) != null) {

               String[] lib = strLine.split(";");
               sampleNames.add(lib[0]);

         }
         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
      }
   }
}
