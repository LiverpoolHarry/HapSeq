/*
 * Haplotypes predicted by Beagle are in 0 (ref) 1 (alt allele) format based on Illumina HDgenotyping chip alleles
which are not necessarily in the same order as the alleles in the vcf frile from the reference genome.
 * So the program first obtains the beagle alleles from file:
TreeMap<Integer, Short> beagleAlleles = p.readBeagleFile()
//Ref and alt alleles in ACGT format by position from vcf file
getRefAndAltAlleles(positionsFile);
//Get Ref and alt alleles in ACGT format by position from HD chip file
hdRefAndAltAlleles = p.getHdRefAndAltAlleles();
//Compare vcf and HD chip alleles and change Beagle call if vcf and HD chip inconsistent
convertBeagleAllelesToSeqAlleles();

 *
 */
package validatehaplotypes;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
//import mysql.mysql;

/**
 *
 * @author harry
 */
public class RunAnalysis {

   private String chr;
   private Params p;
   private ArrayList<Integer> allelePositions;
   private HashMap<String, TreeMap<Integer, Short>> chroAllelePos;//key library;  treemap position allele
   private HashMap<String, String> comLineVars;
   public static final Short mOne = -1;
   public static final Short zero = 0;
   public static final Short one = 1;
   public static final Short two = 2;
   public static final Short three = 3;
   public static final Short four = 4;
   private String hapsFile;
   private int totalMatchingPairs = 0;
   private int totalPairs = 0;
   private final DecimalFormat floatFormat = new DecimalFormat("###,###.###");
   private HashMap<String, Short> shortAlleles;
   private TreeMap<Integer, Short> beagleAlleles;
   private ArrayList<TreeMap<Integer, Short>> sihHaps;//array of sihHaps for chromosome. Only first haplotype is used second is assumed to be complement
   private HashMap<Short, Short> beagleRefCodes;//used to translate beagle 1,2,3,4 to 012 0,2
   private HashMap<Short, Short> beagleAltCodes;//used to translate beagle 1,2,3,4 to 012 0,2
   private TreeMap<Integer, RefAndAltAlleles> seqRefAndAltAlleles;//ref and alt alleles from sequencing vcf file
   private TreeMap<Integer, BadPosition> badPos;//position, BadPosition
   private TreeMap<Integer, RefAndAltAlleles> hdRefAndAltAlleles;
   private TreeMap<Integer, String> haplotypes;
   private Double switchDist = 0.0;
   private int switchCount = 0;
   private String switchString;
   private TreeMap<Integer, ArrayList<Integer>> hapPositions;//key first position in haplotype , list of all positions in haplotype

   public RunAnalysis(HashMap<String, String> comLineVars) {
      this.chr = comLineVars.get("chr");
      this.comLineVars = comLineVars;
      p = new Params(comLineVars);
  
      beagleRefCodes = new HashMap<Short, Short>();
      beagleRefCodes.put(one, zero);
      beagleRefCodes.put(two, two);
      beagleRefCodes.put(three, zero);
      beagleRefCodes.put(four, two);

      beagleAltCodes = new HashMap<Short, Short>();
      beagleAltCodes.put(one, zero);
      beagleAltCodes.put(two, two);
      beagleAltCodes.put(three, two);
      beagleAltCodes.put(four, zero);

      shortAlleles = p.getShortAlleles();


      hapsFile = chr + ".haps.txt";
      badPos = new TreeMap<Integer, BadPosition>();
      haplotypes = new TreeMap<Integer, String>();
      hapPositions = new TreeMap<Integer, ArrayList<Integer>>();

      p.deleteFile(hapsFile);
      validateScaffs();
   }

   private void validateScaffs() {
      //beagle alleles in 1,2,3,4 format by position
      //Assumed interpretation 1=ref/ref, 2 = alt/alt; 3 = ref/alt; 4 = alt/ref
      beagleAlleles = p.readBeagleFile();//calls p.readIlluminaHdFile after reading Beagle alleles
      String positionsFile = chr + ".beaglePositions.txt";
      p.deleteFile(positionsFile);
      writeVcfPosition(positionsFile);//write a list of positions in beagle file to use to filter vcf output

 
      //Ref and alt alleles in ACGT format by position from vcf file
      getRefAndAltAlleles(positionsFile);
      //Get Ref and alt alleles in ACGT format by position from HD chip file
      hdRefAndAltAlleles = p.getHdRefAndAltAlleles();
      //Compare vcf and HD chip alleles and change Beagle call if vcf and HD chip inconsistent
      convertBeagleAllelesToSeqAlleles();
      //get sih haplotypes from .phase file
      sihHaps = p.getSIHhaplotypes();

      //compare sequence and beagle haplotypes
      testHaps();


      printComparisons();
      Double frac = (1.0 * totalMatchingPairs) / totalPairs;
      System.out.println(totalMatchingPairs + " out of " + totalPairs + " (" + floatFormat.format(frac) + ") matched between sequence and Beagle haplotypes");
      frac = (switchDist) / switchCount;
      System.out.println("Switch error distance between pairs of beagle alleles and pairs of sequence alleles = " + floatFormat.format(frac) + " from " + totalPairs + " pairs of loci");

   }

   private void testHaps() {
      String lib = "XX";
      TreeMap<Integer, Short> hdAlls = new TreeMap<Integer, Short>();

      Integer firstBeaglePos = beagleAlleles.firstKey();
      Integer lastBeaglePos = beagleAlleles.lastKey();

       int countSNPpairs = 0;
      int countMatchingSNPpairs = 0;
      int oneLength = 0;
      int countScaffoldsWithNoSNP = 0;
      TreeMap<Integer, Integer> hist = new TreeMap<Integer, Integer>();

      for (TreeMap<Integer, Short> seqAlls : sihHaps) {
 
         //If this scaffold has at least two alleles then get alleles for this position from database
         if (seqAlls.size() > 1 && firstBeaglePos < seqAlls.firstKey() && seqAlls.lastKey() <= lastBeaglePos) {
            Integer hdStart = beagleAlleles.ceilingKey(seqAlls.firstKey());
            Integer hdEnd = beagleAlleles.floorKey(seqAlls.lastKey());
            //get hd alleles for this scaffold
            try {
               if (hdEnd > hdStart) {
                  hdAlls = new TreeMap<Integer, Short>(beagleAlleles.subMap(hdStart, hdEnd));
               }
            }
            catch (NullPointerException npe) {
               continue;
            }
         }
         else {
            continue;
         }
         Short ml = p.getMatchLength();

         if (hdAlls.size() > ml - 1) {
            String meta = "\nPositions: " + seqAlls.firstKey() + "-" + seqAlls.lastKey();
            StringBuilder seqHap = new StringBuilder();
            StringBuilder hdRefHap = new StringBuilder();
            StringBuilder hdAltHap = new StringBuilder();
            StringBuilder hdHap = new StringBuilder();
            StringBuilder hdHapUn = new StringBuilder();
            StringBuilder data = new StringBuilder();
            StringBuilder switchDistRef = new StringBuilder();
            StringBuilder switchDistAlt = new StringBuilder();

            ArrayList<Integer> positions = new ArrayList<Integer>();
            for (Integer pos : seqAlls.keySet()) {
               if (hdAlls.containsKey(pos)) {
                  seqHap.append(seqAlls.get(pos));
                  hdRefHap.append(beagleRefCodes.get(hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype().shortValue()));
                  hdAltHap.append(beagleAltCodes.get(hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype().shortValue()));
                  hdHap.append(hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype().shortValue());
                  hdHapUn.append(hdRefAndAltAlleles.get(pos).getUncorrectedBeagleGenotype().shortValue());
                  data.append(hdRefAndAltAlleles.get(pos).toString() + " " + seqRefAndAltAlleles.get(pos).getRefAllele() + " " + seqRefAndAltAlleles.get(pos).getAltAllele() + "\n");
                  positions.add(pos);
                  int refDist = Math.abs(seqAlls.get(pos) - beagleRefCodes.get(hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype()));
                  int altDist = Math.abs(seqAlls.get(pos) - beagleAltCodes.get(hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype()));
                  switchDistRef.append(refDist);
                  switchDistAlt.append(altDist);

               }
            }
            hist.put(seqHap.length(), (hist.get(seqHap.length()) == null) ? 1 : hist.get(seqHap.length()) + 1);
            //Calculate error rate as per Kaper PNAS 2013
            if (seqHap.length() > 1) {
               StringBuilder ss = new StringBuilder();
               Double switDist = Math.max(getSwitchErrorDist(switchDistRef.toString(), ss), getSwitchErrorDist(switchDistAlt.toString(), ss));
               switchCount += switchDistRef.length();
               switchDist += switDist * switchDistRef.length();
               String sh = seqHap.toString();
               String hrh = hdRefHap.toString();
               String hah = hdAltHap.toString();
               hapPositions.put(positions.get(0), positions);
               countSNPpairs += sh.length();
               char[] sha = sh.toCharArray();
               char[] hrha = hrh.toCharArray();
               char[] haha = hah.toCharArray();
               int refMatches = 0;
               int altMatches = 0;
               for (int j = 0; j < sha.length; j++) {
                  if (sha[j] == hrha[j]) {
                     refMatches++;
                     Integer pos = positions.get(j);
                  }
                  else if (sha[j] == haha[j]) {
                     altMatches++;
                     Integer pos = positions.get(j);
                  }
                  else {
                     String status = "Bad";
                     Integer pos = positions.get(j);
                  }
               }
               Integer max = Math.max(refMatches, altMatches);
               countMatchingSNPpairs += max;
               Double frac = (1.0 * max) / (sh.length());
               String log = (meta + "\nSeqHap:\t" + sh + "\nHDRefHap:\t" + hrh + "\nHDAltHap:\t" + hah + "\nHDhap:\t" + hdHap.toString() + "\nRawHDhap:\t" + hdHapUn.toString() + "\nSwitRef:\t"  + "\nFracCons:\t" + frac + "\nSwitchD:\t" + switDist + "\nSwitStr:\t" + switchString + "\n");
               haplotypes.put(positions.get(0), log);

            }

         }
         else {
            continue;
         }
      }
      Double frac = (1.0 * countMatchingSNPpairs) / countSNPpairs;
      totalMatchingPairs += countMatchingSNPpairs;
      totalPairs += countSNPpairs;
      System.out.println("Histogram of phase haplotype lengths");
      for (Integer i : hist.keySet()) {
         System.out.println(i + "\t" + hist.get(i));

      }

   }

   private void setBadPositions(Integer pos, String lib, char[] sha, int j, String status) {
      if (badPos.containsKey(pos)) {
         badPos.get(pos).addLibrary(lib, shortAlleles.get(String.valueOf(sha[j])));
         if (status.contains("Bad")) {
            badPos.get(pos).setStatus(status);
         }
      }
      else {
         if (hdRefAndAltAlleles.containsKey(pos) && seqRefAndAltAlleles.containsKey(pos)) {
            badPos.put(pos, new BadPosition(status, pos, lib, shortAlleles.get(String.valueOf(sha[j])), hdRefAndAltAlleles.get(pos).getUncorrectedBeagleGenotype(), hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype(), seqRefAndAltAlleles.get(pos).getRefAllele(), seqRefAndAltAlleles.get(pos).getAltAllele(), hdRefAndAltAlleles.get(pos).getRefAllele(), hdRefAndAltAlleles.get(pos).getAltAllele(), hdRefAndAltAlleles.get(pos).getStrand()));
         }
      }

   }

   private void printComparisons() {
      BufferedWriter out = getOutputFile(hapsFile);
      try {
         for (Integer pos1 : haplotypes.keySet()) {
            out.write(haplotypes.get(pos1));

            for (Integer pos : hapPositions.get(pos1)) {
               if (badPos.containsKey(pos)) {
                  out.write(badPos.get(pos).getOutputLine());
                  out.newLine();
               }
            }
         }
         out.flush();
         out.close();
      }
      catch (IOException ex) {
         ex.printStackTrace();
      }
   }

   //Illumina HDchip AB alleles seem to be randomly equal to the reference sequence alleles,
   //the complement of them or the reverse  of them or the reverse compelement of them.
   private void convertBeagleAllelesToSeqAlleles() {
      HashMap<Short, Short> rev = new HashMap<Short, Short>();
      rev.put(one, two);
      rev.put(two, one);
      rev.put(three, four);
      rev.put(four, three);
      HashMap<String, String> comp = new HashMap<String, String>();
      comp.put("A", "T");
      comp.put("C", "G");
      comp.put("G", "C");
      comp.put("T", "A");

      int countRemoved = 0;
      int totalPositions = beagleAlleles.size();
      int seqAllsCount = 0;
      int hdAllsCount = 0;
      int correctedAlleles = 0;
      Iterator it = beagleAlleles.keySet().iterator();
      while (it.hasNext()) {
         Integer beaglePos = (Integer) it.next();
         if (seqRefAndAltAlleles.containsKey(beaglePos)) {
            seqAllsCount++;
         }
         if (hdRefAndAltAlleles.containsKey(beaglePos)) {
            hdAllsCount++;
         }

         if (seqRefAndAltAlleles.containsKey(beaglePos) && hdRefAndAltAlleles.containsKey(beaglePos)) {
            RefAndAltAlleles seqAlls = seqRefAndAltAlleles.get(beaglePos);
            RefAndAltAlleles hdAlls = hdRefAndAltAlleles.get(beaglePos);
            String seqR = "";
            String seqA = "";
            String hdR = "";
            String hdA = "";

            if (!seqAlls.equals(hdAlls)) {
               seqR = seqAlls.getRefAllele();
               seqA = seqAlls.getAltAllele();
               hdR = hdAlls.getRefAllele();
               hdA = hdAlls.getAltAllele();

               if (seqR.contentEquals(hdA) && seqA.contentEquals(hdR) ||
                     seqR.contentEquals(comp.get(hdA)) && seqA.contentEquals(comp.get(hdR))) {
                  //beagleAlleles.put(beaglePos, rev.get(beagleAlleles.get(beaglePos)));
                  hdRefAndAltAlleles.get(beaglePos).setCorrectedBeagleGenotype(rev.get(hdRefAndAltAlleles.get(beaglePos).getUncorrectedBeagleGenotype()).shortValue());
                  //writeLog("Inside: " + hdRefAndAltAlleles.get(beaglePos).toString() + " " + seqR + " " + seqA + " " + hdR + " " + hdA);
                  correctedAlleles++;
               }
               else {
                  //These all seem to be loci where HD chip is complement but not reverse complement of VCF so Beagle genotype does not need modifying
                  hdRefAndAltAlleles.get(beaglePos).setCorrectedBeagleGenotype(beagleAlleles.get(beaglePos).shortValue());

               }
            }
            else {
               hdRefAndAltAlleles.get(beaglePos).setCorrectedBeagleGenotype(beagleAlleles.get(beaglePos).shortValue());
            }
         }
         else {
            it.remove();
            countRemoved++;
         }
      }
      System.out.println("Removed " + countRemoved + " out of " + totalPositions + " positions from Beagle genotypes file because could not find corresponding SNP in HDalles and vcf files");
      System.out.println("Seq alleles matching beagle Pos " + seqAllsCount);
      System.out.println("HD alleles matching beagle Pos " + hdAllsCount);
      System.out.println("Count loci where Beagle genotype reversed to match VCF genotypes " + correctedAlleles);
   }

   private void runVcfTools(String command) {
      //System.out.println(command);
      try {
         long startTime = System.currentTimeMillis();
         final Process process = Runtime.getRuntime().exec(command);
         int returnCode = process.waitFor();
         long endTime = System.currentTimeMillis();
         long elapsedTime = (System.currentTimeMillis() - startTime) / 1000;
         System.out.println(command + " ; Return code " + returnCode + "; Elapsed Time " + elapsedTime + " secs");
      }
      catch (Exception e) {
         e.printStackTrace();
      }

   }

   private void getRefAndAltAlleles(String positionsFile) {
      String outfile = chr + "vcf";
      String command = p.getVcftools() + "vcftools --gzvcf " + p.getVcfFile() + " --positions " + positionsFile + " --chr " + chr + " --out " + outfile + " --recode";
      runVcfTools(command);
      String filename = outfile + ".recode.vcf";
      File file = new File(filename);
      seqRefAndAltAlleles = p.readVCFFile(file);
      p.deleteFile(outfile + ".recode.vcf");
   }

   private void delete012files(String file012) {
      p.deleteFile(file012 + ".012");
      p.deleteFile(file012 + ".012.pos");
      p.deleteFile(file012 + ".012.indv");
      p.deleteFile(file012 + "vcf.log");
   }

   private void writeLog(String outString) {
      BufferedWriter out = getOutputFile(hapsFile);
      try {
         out.write(outString);
         out.newLine();
         out.flush();
         out.close();
      }
      catch (IOException ex) {
         ex.printStackTrace();
      }
   }

   private BufferedWriter getOutputFile(String filename) {
      BufferedWriter analysisFile = null;
      File file = new File(filename);
      try {
         FileWriter fstream = new FileWriter(file, true);
         analysisFile = new BufferedWriter(fstream);
      }
      catch (IOException e) {
         System.out.println("IOException : " + e);
      }
      return analysisFile;
   }

   private void writeVcfPosition(String filename) {
      BufferedWriter out = getOutputFile(filename);

      try {
         for (Integer pos : beagleAlleles.keySet()) {
            out.write(chr + "\t" + pos);
            out.newLine();
         }
         out.flush();
         out.close();

      }
      catch (IOException ex) {
         ex.printStackTrace();
      }

   }

   private Double getSwitchErrorDist(String snpDiff, StringBuilder ss) {
      Integer count = snpDiff.length();

      int length = snpDiff.length();
      for (int i = 0; i < length - 1; i+=2) {
         int j = 1;
         if (snpDiff.charAt(i) != snpDiff.charAt(i + 1)) {
            if (i == 0) {
                  count--;
                  j--;
            }
            else if (i < length - 2) {
               if ((snpDiff.charAt(i + 1) != snpDiff.charAt(i + 2) ||
                     snpDiff.charAt(i) != snpDiff.charAt(i - 1))) {
                  count--;
                  j--;
               }

            }
            else if (i == length - 2) {
                  count--;
                  j--;
            }
         }
         ss.append(j);
      }
      ss.append("-");
      switchString = ss.toString();
      return (1.0 * count) / length;

   }
}
