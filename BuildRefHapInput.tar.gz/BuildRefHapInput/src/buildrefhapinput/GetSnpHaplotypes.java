/*
 * Scaffolds know which other scaffolds they overlap (set by ProcessFiles.scaffoldsOverlap).
 * This class iterates over all scaffolds from each cell or chromosome and gets distance to every overlapping scaffold
 * Then iterates over scaffolds in merged cell or chromosome and gets distance metric for each scaffold
 * It also loads alleles and positions of every SNP into vcfAlleles and vcfPositions in Params
 *

 */
package buildrefhapinput;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.TreeMap;

/**
 *
 * @author harry
 */
public class GetSnpHaplotypes {

   private TreeMap<Integer, Short> refAlleles;
   private TreeMap<Integer, Short> testAlleles;
   private ArrayList<Chromosome> chros;
   private File logfile;
   private boolean logging = false;
   private Params p;
   private String chr;
   private Double globalMeanCov = 0.0;
   private Integer hetTotal = 0;
   int countProcessed = 0;
   int informativeSNP = 0;
   long overlapLength = 0;
   long informativeOverlapLength = 0;
   int negativeLengths = 0;
   int overlapsAbove = 0;
   int overlapsBelow = 0;
   private int skippedBelow = 0;
   private int skippedAbove = 0;
   private double meanBelow = 0.0;
   private double meanAbove = 0.0;
   private String file012 = "temp";
   private ArrayList<Chromosome> allChro;
   private ArrayList<Integer> allelePositions;
   private HashMap<String, TreeMap<Integer, Short>> chroAllelePos;//key subcell;  arrayList allele
   private TreeMap<Integer, Scaffold> scaffolds;
   private TreeMap<Integer, Scaffold> refScaffs;
   private TreeMap<Integer, Scaffold> testScaffs;
   private HashMap<String, String> allelesStrings;//Key subcell array, value string of 012 alleles from vcf tools
   private TreeMap<String, Chromosome> snpHapDists;
   private TreeMap<Integer, Integer> badPos;//Position count haplotype switches at position
   private HashMap<String, ArrayList<String>> pairsPerLib;//Libray; list of pairs of libraries in which index library participates. Pairs are in snpHapDists
   private ArrayList<String> sampleNames;
   public static final Short mOne = -1;
   public static final Short zero = 0;
   public static final Short one = 1;
   public static final Short two = 2;
   private HashMap<String, Short> shortAlleles;
   private TreeMap<Double, String> allAllelePosNames;//names so that haplotypes can be printed in order

   public GetSnpHaplotypes(Params p, File logfile, String chr) {
      this.logfile = logfile;
      this.p = p;
      this.chr = chr;
      allAllelePosNames = new TreeMap<Double, String>();
      chroAllelePos = new HashMap<String, TreeMap<Integer, Short>>();//Individual libraries
      scaffolds = new TreeMap<Integer, Scaffold>();//overlapping scaffolds
      p.resetVcfData();
      allelesStrings = new HashMap<String, String>();
      badPos = new TreeMap<Integer, Integer>();
      snpHapDists = new TreeMap<String, Chromosome>();
      pairsPerLib = new HashMap<String, ArrayList<String>>();
      allelePositions = new ArrayList<Integer>();
      shortAlleles = new HashMap<String, Short>(4);
      shortAlleles.put("-1", mOne);
      shortAlleles.put("0", zero);
      shortAlleles.put("1", one);
      shortAlleles.put("2", two);
   }

   public void initialise() {
      //get overlapping scaffolds into a HashMap indexed by chromosome and a treemap of overlapping scaffolds indexed by start of overlap
      allAllelePosNames.clear();
      chroAllelePos.clear();//Individual libraries
      scaffolds.clear();
      p.resetVcfData();
      allelesStrings.clear();
      snpHapDists.clear();
      allChro = (ArrayList<Chromosome>) p.getRawScaffolds(chr);
      initialisePairsPerLib();
      int count = 0;
      p.getSnpDistScaffolds().clear();
      Chromosome refChr = allChro.get(0);
      refScaffs = refChr.getScaffolds();
      runVcfTools();
      getSampleNamesFromVcf();
      getAllelePositions();
      getAlleles();
      removeHetScaffolds();
      removeUninformativePositions();
      getSnpHaplotypes();
      printBadPos();
      if (p.getMinDist() > 0) {
         removeLowQualityScaffolds();
         getSnpHaplotypes();
      }
      if (p.isWriteTables()) {
         write012();
         writeGff3();
      }

   }

   public void getSnpHaplotypes() {
      int totalScaffs = 0;
      globalMeanCov = 0.0;
      overlapsBelow = 0;
      overlapsAbove = 0;
      informativeOverlapLength = 0;
      countProcessed = 0;
      informativeSNP = 0;
      overlapLength = 0;
      negativeLengths = 0;

      for (int i = 0; i < allChro.size() - 1; i++) {
         refScaffs = allChro.get(i).getScaffolds();

         totalScaffs += refScaffs.size();
         ArrayList<Integer> refKeys = new ArrayList(refScaffs.keySet());
         Boolean firstLoop = true;
         for (int j = i + 1; j < allChro.size(); j++) {
            hetTotal = 0;
            testScaffs = allChro.get(j).getScaffolds();
            TreeMap<Integer, Integer> allelePos = buildDifferenceString();
            if (allelePos.isEmpty()) {
               System.out.println("No informative SNP for " + refScaffs.get(refScaffs.firstKey()).getSubcell() + " and " + testScaffs.get(testScaffs.firstKey()).getSubcell());
               continue;
            }

            String name = chr + "_" + refScaffs.get(refScaffs.firstKey()).getSubcell() + "_" + testScaffs.get(testScaffs.firstKey()).getSubcell();

            for (Integer start : refKeys) {
               int end = refScaffs.get(start).getEnd();

               if (start < end) {
                  int belowEnd = getOverlapsBelow(start, end, name, chr, allelePos);
                  Integer currentStart = start;
                  if (belowEnd < end) {
                     while (end > currentStart && currentStart >= start) {
                        currentStart = getOverlapsAbove(start, end, currentStart, name, chr, allelePos) + 1;
                     }
                  }
               }
            }
            if (scaffolds.size() > 0) {
               snpHapDists.put(name, new Chromosome(chr, (TreeMap<Integer, Scaffold>) scaffolds.clone()));
               pairsPerLib.get(refScaffs.get(refScaffs.firstKey()).getSubcell()).add(name);

            }
            scaffolds.clear();
            String type = "HetCount:" + refScaffs.get(refScaffs.firstKey()).getSubcell() + ";" +
                  testScaffs.get(testScaffs.firstKey()).getSubcell();

         }
      }
      p.setSnpDistScaffolds(chr, snpHapDists);
      if (countProcessed > 0) {
         System.out.println("Number of reference scaffolds processed = " + totalScaffs);
         Double mean = 1.0 * (informativeSNP / countProcessed);

         System.out.println("Number of overlaps: " + countProcessed + " Number of informative loci in overlaps = " + informativeSNP);
         System.out.println("Mean number of informative SNP per overlap = " + mean);
         Double length = 1.0 * (overlapLength / countProcessed);
         System.out.println("Total length of  overlap = " + overlapLength);
         System.out.println("Total length of  overlap with > 1 SNP = " + informativeOverlapLength);
         System.out.println("Mean length of  overlap = " + length);
         System.out.println("Number of overlaps below with > 1 informative SNP : " + overlapsAbove);
         System.out.println("Number of overlaps above with > 1 informative SNP : " + overlapsBelow);
         globalMeanCov = globalMeanCov / (overlapsBelow + overlapsAbove);
         System.out.println("Mean coverage of scaffolds = " + globalMeanCov);
      }
      else {
         System.out.println("No overlaps detected");
      }

      setAllelePositions();
   }

   private Integer getOverlapsBelow(Integer start, int end, String name, String chr, TreeMap<Integer, Integer> allelePos) {
      int overlapStart = 0;
      int overlapEnd = 0;
      int belowEnd = -1;
      try {
         int belowStart = testScaffs.floorKey(start);
         belowEnd = testScaffs.get(belowStart).getEnd();
         if (belowEnd > start) {
            overlapStart = start;
            overlapEnd = Math.min(end, belowEnd);
            if (overlapEnd > overlapStart) {
               overlapLength += ((overlapEnd - overlapStart) + 1);
            }
            else {
               negativeLengths++;
            }
            SnpDist snpStats = getDistance(overlapStart, overlapEnd, allelePos);
            hetTotal += snpStats.getHetCount();
            if (snpStats.getSnpCount() > 1) {
               overlapsBelow++;
               informativeOverlapLength += ((overlapEnd - overlapStart) + 1);
               int meanCov = (refScaffs.get(start).getCoverage() + testScaffs.get(belowStart).getCoverage()) / 2;
               globalMeanCov += meanCov;
               scaffolds.put(overlapStart, new Scaffold(chr, overlapStart, overlapEnd, name, snpStats.getSnpDist(), snpStats.getSwitchDist(), refScaffs.get(start).getSubcell(), testScaffs.get(belowStart).getSubcell(), snpStats.getSnpDiffs(), snpStats.getSnpPos(), meanCov));

               refScaffs.get(start).setSnpDistValues(testScaffs.get(belowStart).getName(), snpStats.getSnpDiffs().length(), snpStats.getSnpDist() * snpStats.getSnpDiffs().length());
               testScaffs.get(belowStart).setSnpDistValues(refScaffs.get(start).getName(), snpStats.getSnpDiffs().length(), snpStats.getSnpDist() * snpStats.getSnpDiffs().length());
               //add list of overlapping scaffs to scaffold
               refScaffs.get(start).setOverlappingScaff(testScaffs.get(belowStart));
               testScaffs.get(belowStart).setOverlappingScaff(refScaffs.get(start));
            }
         }

      }
      catch (NullPointerException npe) {
      }
      return belowEnd;
   }

   private Integer getOverlapsAbove(Integer start, int end, Integer currentStart, String name, String chr, TreeMap<Integer, Integer> allelePos) {
      int overlapStart = 0;
      int overlapEnd = 0;
      Integer aboveEnd = -1;
      int aboveStart = 0;
      try {
         aboveStart = testScaffs.ceilingKey(currentStart);
         aboveEnd = testScaffs.get(testScaffs.ceilingKey(currentStart)).getEnd();
         if (aboveStart < end && aboveStart > start) {
            overlapStart = aboveStart;
            overlapEnd = Math.min(end, aboveEnd);
            if (overlapStart > 0 && overlapEnd > 0 && overlapEnd > overlapStart) {
               if (overlapEnd > overlapStart) {
                  overlapLength += ((overlapEnd - overlapStart) + 1);

               }
               else {
                  negativeLengths++;
               }

               SnpDist snpStats = getDistance(overlapStart, overlapEnd, allelePos);
               hetTotal += snpStats.getHetCount();
               if (snpStats.getSnpCount() > 1) {
                  overlapsAbove++;
                  informativeOverlapLength += ((overlapEnd - overlapStart) + 1);
                  int meanCov = (refScaffs.get(start).getCoverage() + testScaffs.get(aboveStart).getCoverage()) / 2;
                  globalMeanCov += meanCov;

                  scaffolds.put(overlapStart, new Scaffold(chr, overlapStart, overlapEnd, name, snpStats.getSnpDist(), snpStats.getSwitchDist(), refScaffs.get(start).getSubcell(), testScaffs.get(testScaffs.firstKey()).getSubcell(), snpStats.getSnpDiffs(), snpStats.getSnpPos(), meanCov));

                  refScaffs.get(currentStart).setSnpDistValues(testScaffs.get(aboveStart).getName(), snpStats.getSnpDiffs().length(), snpStats.getSnpDist() * snpStats.getSnpDiffs().length());
                  testScaffs.get(aboveStart).setSnpDistValues(refScaffs.get(currentStart).getName(), snpStats.getSnpDiffs().length(), snpStats.getSnpDist() * snpStats.getSnpDiffs().length());
                  //add list of overlapping scaffs to scaffold
                  refScaffs.get(start).setOverlappingScaff(testScaffs.get(aboveStart));
                  testScaffs.get(aboveStart).setOverlappingScaff(refScaffs.get(start));
               }
            }
         }
      }
      catch (NullPointerException npe) {

      }
      return aboveEnd;
   }

   private void runVcfTools() {

      file012 = chr;
      String command = p.getVcftools() + "vcftools --gzvcf " + p.getVcfFile() + " --chr " + chr + " --from-bp " + p.getMinStart() + " --to-bp " + p.getMaxEnd() + p.getVcfExclusions() + " --out " + file012 + " --012";
      try {
         long startTime = System.currentTimeMillis();
         final Process process = Runtime.getRuntime().exec(command);
         int returnCode = process.waitFor();
         long endTime = System.currentTimeMillis();
         long elapsedTime = (System.currentTimeMillis() - startTime) / 1000;
         System.out.println(command + " ; Return code " + returnCode + "; Elapsed Time " + elapsedTime + " secs");
      }
      catch (Exception e) {
         e.printStackTrace();
      }

   }

   //returns comparison between refAlleles and testAlleles
   private TreeMap<Integer, Integer> buildDifferenceString() {
      Double hapDist = 0.0;
      TreeMap<Integer, Integer> allelePos = new TreeMap<Integer, Integer>();//Position, allele

      refAlleles = chroAllelePos.get(refScaffs.get(refScaffs.firstKey()).getSubcell());
      testAlleles = chroAllelePos.get(testScaffs.get(testScaffs.firstKey()).getSubcell());
      String hapName = "";

      if (testAlleles != null && refAlleles != null) {
         //alleles are 0 for ref 2 for alt. This loop generates an array of 0s where two alleles are equal and 2s where they are different
         //and 1 for heterozygotes on one sample two heterozygotes would generate a false equality
         for (int d = 1; d < allelePositions.size(); d++) {
            Short d1 = refAlleles.get(allelePositions.get(d));
            Short d2 = testAlleles.get(allelePositions.get(d));
            if (d1 != null && d2 != null) {
               if (Math.abs(d1) != 1 && Math.abs(d2) != 1) {
                  int snpDiff = Math.abs(d1 - d2);
                  allelePos.put(allelePositions.get(d), snpDiff);
               }
            }
         }
         String type = refScaffs.get(refScaffs.firstKey()).getSubcell() + ":" +
               testScaffs.get(testScaffs.firstKey()).getSubcell();
      }

      //badPos contains counts of inconsistent transitions  at each position
      //this will remove positions with > 5 inconsistent calls
      if (!badPos.isEmpty()) {
         for (Integer pos : badPos.keySet()) {
            if (badPos.get(pos) > 5) {
               allelePos.remove(pos);
            }
         }
      }
      return allelePos;
   }

   private SnpDist getDistance(Integer start, Integer end, TreeMap<Integer, Integer> allelePos) {
      Double dist = -1.0;
      Double switchErrorDist = 0.0;
      String snpDiffs = "";
      Integer hetCount = 0;
      Integer snpCount = 0;
      ArrayList<Integer> snpPos = new ArrayList<Integer>();
      HashMap<String, String> sourceAlleles = new HashMap<String, String>(2);
      SnpDist snpStats = new SnpDist(dist, switchErrorDist, snpDiffs, hetCount, snpPos, sourceAlleles, snpCount);

      int current;
      int listEnd;
      try {
         current = allelePos.ceilingKey(start);
         listEnd = allelePos.floorKey(end);
      }
      catch (NullPointerException npe) {
         return snpStats;
      }
      int count = 0;
      int lastKey = allelePos.lastKey();
      while (current <= listEnd && current + 1 <= lastKey) {
         dist += allelePos.get(current);
         snpDiffs += allelePos.get(current).toString();
         snpPos.add(current);
         current = allelePos.ceilingKey(current + 1);
         count++;
         if (allelePos.get(current) == 1) {
            hetCount++;
         }
      }

      //multiply by two to get value between 0 and 1
      if (count > 0) {
         dist++;//to compensate for -1.0 initial value
         countProcessed++;
         informativeSNP += count;
         //Distance measure used by Kaper et al PNAS 2013 110:5552–5557
         Double dis = Math.max((dist / (count)) / 2, (2 - (dist / (count))) / 2);
         switchErrorDist = getSwitchErrorDist(snpDiffs, snpPos);
         snpStats.setSnpDiffs(snpDiffs);
         snpStats.setSnpDist(dis);
         snpStats.setSwitchDist(switchErrorDist);
         snpStats.setHetCount(hetCount);
         snpStats.setSnpPos(snpPos);
         snpStats.setSnpCount(count - hetCount);
      }
      return snpStats;
   }

   private Double getSwitchErrorDist(String snpDiffs, ArrayList<Integer> snpPos) {
      Double switchDist = 0.0;
      Integer count = snpDiffs.length();
      char c1 = snpDiffs.charAt(0);
      for (int i = 1; i < snpDiffs.length() - 1; i++) {
         char c2 = snpDiffs.charAt(i);
         if (c1 != c2) {
            if (c2 != snpDiffs.charAt(i + 1)) {
               count--;
            }
            if (c1 == snpDiffs.charAt(i + 1) || i == 1) {
               badPos.put(snpPos.get(i), (badPos.get(snpPos.get(i)) == null) ? 1 : badPos.get(snpPos.get(i)) + 1);
            }
         }
         c1 = c2;
      }
      switchDist = (1.0 * count) / snpDiffs.length();
      return switchDist;
   }

   private void getAlleleStats(ArrayList<Integer> alleles, String type) {
      TreeMap<Integer, Integer> alleleCounts2 = new TreeMap<Integer, Integer>();
      for (Integer allele : alleles) {
         alleleCounts2.put(allele, (alleleCounts2.containsKey(allele) == false) ? 1 : alleleCounts2.get(allele) + 1);
      }
      StringBuilder output = new StringBuilder(type + ";");
      for (Integer allele : alleleCounts2.keySet()) {
         output.append("Count Allele " + allele + " : " + alleleCounts2.get(allele) + "; ");
      }
   }

   public TreeMap<Double, String> getAllAllelePosNames() {
      return allAllelePosNames;
   }

   private void writeLog(String outString) {
      if (logging) {
         BufferedWriter out = getOutputFile(logfile.getAbsoluteFile(), true);
         try {
            out.write(outString);
            out.newLine();
            out.flush();
            out.close();
         }
         catch (IOException ex) {
            ex.printStackTrace();
         }
      }
   }

   private void write012() {
      //write positions
      File file = new File(chr + ".filtered.012.pos");
      BufferedWriter out = getOutputFile(file, false);

      try {
         for (Integer pos : allelePositions) {
            out.write(chr + "\t" + pos);
            out.newLine();
         }
         out.flush();
         out.close();
      }
      catch (IOException ex) {
         ex.printStackTrace();
      }

      //write alleles
      file = new File(chr + ".filtered.012");
      out = getOutputFile(file, false);
      try {
         for (String lib : chroAllelePos.keySet()) {
            out.write(lib + ";");
            for (Integer pos : chroAllelePos.get(lib).keySet()) {
               out.write(pos + "," + chroAllelePos.get(lib).get(pos) + ";");
            }
            out.newLine();
         }
         out.flush();
         out.close();
      }
      catch (IOException ex) {
         ex.printStackTrace();
      }
   }

   private void writeGff3() {
      for (Chromosome chro : allChro) {
         String lib = chro.getScaffold(chro.getScaffolds().firstKey()).getSubcell();
         if(lib.endsWith("_")){
            lib = lib.substring(0, lib.length() - 1);
         }
         File file = new File(lib + "_" + chr + ".filtered.gff3");
         System.out.println("Printing " + file.getAbsolutePath());
         BufferedWriter out = getOutputFile(file, false);
         TreeMap<Integer, Scaffold> scaffs = chro.getScaffolds();
         try {
            for (Integer pos : scaffs.keySet()) {
               out.write(scaffs.get(pos).getScaffoldGff3());
               out.newLine();
            }
            out.flush();
            out.close();
         }
         catch (IOException ex) {
            ex.printStackTrace();
         }
      }

   }

   private BufferedWriter getOutputFile(File file, boolean append) {
      BufferedWriter analysisFile = null;
      try {
         FileWriter fstream = new FileWriter(file, append);
         analysisFile = new BufferedWriter(fstream);
      }
      catch (IOException e) {
         System.out.println("IOException : " + e);
      }
      return analysisFile;
   }

   private void printLowQualityScaffolds(ArrayList<Scaffold> badScaffolds, String fileSuffix) {
      if (!badScaffolds.isEmpty()) {
         String filename = p.getChr() + fileSuffix;
         BufferedWriter out = p.getOutputFile(filename, false);
         for (Scaffold scaff : badScaffolds) {

            try {
               String outString = scaff.getIntervalAndOverlappingScaffs();
               out.write(outString);
               out.newLine();
            }
            catch (IOException ex) {
               ex.printStackTrace();
            }
         }
         try {
            out.flush();
            out.close();
         }
         catch (IOException ex) {
            ex.printStackTrace();
         }
      }

   }

   private void getSampleNamesFromVcf() {
      sampleNames = new ArrayList<String>();
      String path = System.getProperty("user.dir");
      File file = new File(path + "/" + file012 + ".012.indv");


      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;
         while ((strLine = br.readLine()) != null) {
            String lib = strLine.replaceAll("(\\r|\\n)", "");
            sampleNames.add(lib);
         }
         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error at GetSnpHaplotypes line 606: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
      }
   }

   //build treemap of alleles keyed by position for each subcell
   private void getAllelePositions() {
      String path = System.getProperty("user.dir");
      File file = new File(path + "/" + file012 + ".012.pos");
      //Build array of allele positions
      allelePositions.clear();

      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;
         while ((strLine = br.readLine()) != null) {
            String[] posit = strLine.split("\t");
            allelePositions.add(Integer.parseInt(posit[1]));
         }
         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error  at GetSnpHaplotypes line 634: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
      }


      System.out.println("Got " + allelePositions.size() + " snp positions");
   }

   private void getAlleles() {
      ArrayList<String> exceptions = p.getExclusions();
      String path = System.getProperty("user.dir");
      File file = new File(path + "/" + file012 + ".012");
      //Build array of allele positions


      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;
         int sampleNo = 0;
         while ((strLine = br.readLine()) != null) {
            String[] alleles = strLine.split("\t");
            TreeMap<Integer, Short> posAlleles = new TreeMap<Integer, Short>();
            String subcell = sampleNames.get(sampleNo);
            sampleNo++;
            for (int d = 1; d < alleles.length; d++) {
               if (!alleles[d].contentEquals("-1")) {
                  posAlleles.put(allelePositions.get(d - 1), shortAlleles.get(alleles[d]));
               }
            }
            chroAllelePos.put(subcell, posAlleles);
         }

         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error  at GetSnpHaplotypes line 682: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
      }

   }

   private void removeUninformativePositions() {
      ArrayList<String> libs = new ArrayList<String>(chroAllelePos.keySet());
      HashMap<Short, Integer> counts = new HashMap<Short, Integer>();
      int fixedPos = 0;
      int startLength = allelePositions.size();
      ListIterator it = allelePositions.listIterator();
      int index = 0;
      while (it.hasNext()) {
         //  index--;
         Integer pos = (Integer) it.next();
         counts.put(mOne, 0);
         counts.put(zero, 0);
         counts.put(one, 0);
         counts.put(two, 0);

         for (String lib : libs) {
            try {
               if (chroAllelePos.get(lib).containsKey(pos)) {
                  counts.put(chroAllelePos.get(lib).get(pos), counts.get(chroAllelePos.get(lib).get(pos)) + 1);
               }
            }
            catch (NullPointerException npe) {
            }

         }
         if (counts.get(zero) == 0 || counts.get(two) == 0) {
            for (String lib : libs) {
               if (chroAllelePos.get(lib).containsKey(pos)) {
                  chroAllelePos.get(lib).remove(pos);
               }
            }

            it.remove();
            fixedPos++;
         }
         index++;
      }

      int endLength = allelePositions.size();
      System.out.println("Number of positions with heterozygotes before heterozygote removal                = " + startLength);
      System.out.println("Number of positions with heterozygotes after heterozygote removal                 =  " + endLength);
      System.out.println("Number of heterozygous positions removed                                          =  " + fixedPos);
   }

//iterates over all scaffolds and remove those with excess hets
   private void removeHetScaffolds() {
      int maxHets = p.getMaxHets();
      double maxHetProp = p.getMaxHetProp();
      int countDeletedScaffs = 0;
      int totalScaffs = 0;
      int totalHets = 0;
      int deletedHets = 0;
      HashMap<Short, Integer> counts = new HashMap<Short, Integer>();
      for (int i = 0; i < allChro.size() - 1; i++) {
         TreeMap<Integer, Scaffold> scaffs = allChro.get(i).getScaffolds();
         TreeMap<Integer, Short> posAlleles;
         ArrayList<Integer> starts;
         String subcell;
         try {
            posAlleles = chroAllelePos.get(scaffs.get(scaffs.firstKey()).getSubcell());
            subcell = scaffs.get(scaffs.firstKey()).getSubcell();
            starts = new ArrayList<Integer>(scaffs.keySet());
            if (posAlleles.isEmpty() || subcell.isEmpty() || starts.isEmpty()) {
               continue;
            }
         }
         catch (NullPointerException npe) {
            continue;
         }
         for (Integer start : starts) {
            totalScaffs++;
            Scaffold sca = scaffs.get(start);
            Integer end = sca.getEnd();
            counts.put(mOne, 0);
            counts.put(zero, 0);
            counts.put(one, 0);
            counts.put(two, 0);
            Integer currentStart = start;

            while (posAlleles.ceilingKey(currentStart) != null && currentStart <= end) {
               try {
                  Integer key = posAlleles.ceilingKey(currentStart);
                  if (key != null) {
                     counts.put(posAlleles.get(key), counts.get(posAlleles.get(key)) + 1);
                     currentStart = key + 1;
                  }
               }
               catch (NullPointerException npe) {
                  System.out.println("Current start: " + currentStart);
                  System.out.println("Current end: " + end);
                  System.out.println("Ceiling key: " + posAlleles.ceilingKey(currentStart));
                  System.exit(0);
               }
            }

            totalHets += counts.get(one);
            Double hetProp = (1.0 * counts.get(one)) / (counts.get(zero) + counts.get(one) + counts.get(two));
            if (hetProp > maxHetProp || counts.get(one) > maxHets) {
               scaffs.remove(start);
               countDeletedScaffs++;
               deletedHets += counts.get(one);
            }
         }
      }
      int percent = (100 * countDeletedScaffs) / totalScaffs;
      System.out.println(countDeletedScaffs + " scaffolds out of " + totalScaffs + "(" + percent + ")% were deleted because they had more than " + maxHets + " hets or a heterozygote frequency > " + maxHetProp);
     if(totalHets > 0){
      percent = (100 * deletedHets) / totalHets;
     }
     else{
         percent = 0;
     }
      System.out.println(deletedHets + " out of a total of " + totalHets + " (" + percent + "%) heterozygous SNP were in the deleted scaffolds");
   }

//removes lines from output gff file where mean distance between this scaffold and
//all other overlapping scaffolds is less than p.getMinDist()
// scaffolds without overlaps have dist -1 but are retained
//called by RunAnalysis line 197
   private void removeLowQualityScaffolds() {
      if (!allChro.isEmpty()) {
         int countRemoved = 0;
         int totalScaff = 0;
         int lengthScaffoldsWIthNoOverlaps = 0;
         double minDist = p.getMinDist();
         double dist = 0.0;

         ArrayList<Scaffold> badScaffolds = new ArrayList<Scaffold>();
         for (int i = 0; i < allChro.size(); i++) {
            TreeMap<Integer, Scaffold> scaffs = allChro.get(i).getScaffolds();
            Iterator it = scaffs.keySet().iterator();
            String name = scaffs.get(scaffs.firstKey()).getName();
            while (it.hasNext()) {
               totalScaff++;
               Integer key = (Integer) it.next();
               dist = scaffs.get(key).getMeanSnpDist();
               if (dist > -0.1 && dist < minDist * 10) {
                  badScaffolds.add(scaffs.get(key));
                  it.remove();
                  countRemoved++;
               }
               else {
                  scaffs.get(key).clearSnpDistVals();
               }

               if (dist < 0) {
                  lengthScaffoldsWIthNoOverlaps += scaffs.get(key).getEnd() - scaffs.get(key).getStart() + 1;
               }
            }
            if (scaffs.size() < 1) {
               System.out.println("No good scaffolds for " + name);
               //This will probably generate a concurrent modification error
               allChro.remove(i);
            }
         }
         Double prop = 1.0 * countRemoved / totalScaff;
         System.out.println("Removed " + countRemoved + " scaffolds " + prop + " of total " + totalScaff);
         System.out.println("Total length of scaffolds which do not have informative overlaps with other scaffolds = " + lengthScaffoldsWIthNoOverlaps);
         printLowQualityScaffolds(badScaffolds, ".BadScaffolds.gff3");
      }
      else {
         System.out.println("No chromosome data found");
      }
   }

   private void printBadPos() {
      TreeMap<Integer, Integer> counts = new TreeMap<Integer, Integer>();
      for (Integer pos : badPos.keySet()) {
         counts.put(badPos.get(pos), (counts.get(badPos.get(pos)) == null) ? 1 : counts.get(badPos.get(pos)) + 1);
      }
      System.out.println("Count: The number of libraries in which a particular position has been inconsistent with its neighbours");
      System.out.println("Value: The number of times that count has been observed");
      System.out.println("Count        Value");
      for (Integer count : counts.keySet()) {
         System.out.println(count + "; " + counts.get(count));
      }
   }

   private void delete012files() {
      p.deleteFile(file012 + ".012");
      p.deleteFile(file012 + ".012.pos");
      p.deleteFile(file012 + ".012.indv");
      p.deleteFile(file012 + ".log");
   }

   private void initialisePairsPerLib() {
      for (Chromosome chro : allChro) {
         pairsPerLib.put(chro.getScaffolds().firstEntry().getValue().getSubcell(), new ArrayList<String>());
      }
   }

   private void setAllelePositions() {
      p.setAllelePositions(allelePositions);
      p.setChroAllelePos(chroAllelePos);
   }

   public class SnpDist {

      private Double snpDist;
      private Double switchDist;//distance ignoring haplotype switches defined as two or more consecutive snp
      private String snpDiffs;
      private Integer hetCount;
      private ArrayList<Integer> snpPos;
      private HashMap<String, String> sourceAlleles;//key subcell /value source alleles.
      private Integer snpCount;//Only homozygous ref and alt alleles no hets
      //These are real alleles unlike snpDiffs which are derivatives

      public SnpDist() {
      }

      public SnpDist(Double snpDist, Double switchDist, String snpDiffs, Integer hetCount, ArrayList<Integer> snpPos, HashMap<String, String> sourceAlleles, Integer snpCount) {
         this.snpDiffs = snpDiffs;
         this.switchDist = switchDist;
         this.snpDist = snpDist;
         this.hetCount = hetCount;
         this.snpPos = snpPos;
         this.sourceAlleles = sourceAlleles;
         this.snpCount = snpCount;
      }

      public String getSnpDiffs() {
         return snpDiffs;
      }

      public void setSnpDiffs(String snpDiffs) {
         this.snpDiffs = snpDiffs;
      }

      public Double getSnpDist() {
         return snpDist;
      }

      public void setSnpDist(Double snpDist) {
         this.snpDist = snpDist;
      }

      public ArrayList<Integer> getSnpPos() {
         return snpPos;
      }

      public void setSnpPos(ArrayList<Integer> snpPos) {
         this.snpPos = snpPos;
      }

      public Double getSwitchDist() {
         return switchDist;
      }

      public void setSwitchDist(Double switchDist) {
         this.switchDist = switchDist;
      }

      public Integer getHetCount() {
         return hetCount;
      }

      public void setHetCount(Integer hetCount) {
         this.hetCount = hetCount;
      }

      public Integer getSnpCount() {
         return snpCount;
      }

      public void setSnpCount(Integer snpCount) {
         this.snpCount = snpCount;
      }
   }
}


