 /**
 *
 * @author harry
 */
package buildrefhapinput;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.TreeSet;

public class RunAnalysis {

   private HashMap<String, Integer> chroEnds;
   private HashMap<String, TreeMap<Integer, Scaffold>> allScaffolds;
   private ArrayList<String> exceptions;
   private Integer minScaffLength = 1000;//minimum length of scaffold used for testing distance metric
   private Params params;
   private GetFiles fileLister;
   private String testChr;
   private HashMap<String, String> comLineVars;
   private TreeSet<String> physicalChr; //Non redundant List of chromosomes processed

   public RunAnalysis(HashMap<String, String> comLineVars, ArrayList<String> exceptions) {


      this.testChr = comLineVars.get("chr");
      this.comLineVars = comLineVars;
      String chr = comLineVars.get("chr");

      chroEnds = new HashMap<String, Integer>();
      allScaffolds = new HashMap<String, TreeMap<Integer, Scaffold>>();
      this.exceptions = exceptions;
      params = new Params(comLineVars, minScaffLength);
      params.setExclusions(exceptions);
      if (exceptions.isEmpty()) {
         exceptions.add("zxy% ");// leave this in to avoid null pointer exceptions
      }
      fileLister = new GetFiles(params);
      physicalChr = new TreeSet<String>();

   }

   public void analyseCells() {

      File[] files = fileLister.readFile(new File(comLineVars.get("fileList")));
      System.out.println("Got " + files.length + " gff3 files in " + params.getGff3Path());

      ProcessFiles processor = new ProcessFiles(new File("CellLog.txt"), params);
      processor.processFiles(files, exceptions);
      physicalChr.add(params.getChr());
      System.out.println("VCFAbsolute Path = " + params.getVcfFile().getAbsolutePath().toString());
   }

   public void analyseScaffolds() {
      System.out.println("Starting analyse Scaffolds");
      for (String chr : physicalChr) {
         System.out.println("Chr " + chr + "; testChr: " + testChr);
         if (!chr.contentEquals(testChr)) {
            continue;
         }
         GetSnpHaplotypes getSnp = new GetSnpHaplotypes(params, new File("SnpHaplotypesLog." + chr + ".txt"), chr);
         getSnp.initialise();

         printScaffoldMeanDistanceHist();

         TreeMap<String, TreeMap<String, Chromosome>> snpHaps = params.getSnpDistScaffolds();
         String snpHap = chr;
         for (String subCellPair : snpHaps.get(snpHap).keySet()) {
            if (!snpHaps.get(snpHap).get(subCellPair).getScaffolds().isEmpty()) {
               printGffFiles(snpHaps.get(snpHap).get(subCellPair).getScaffolds());
            }
            else {
               System.out.println("Sub cell pair " + subCellPair + " is empty");
            }
         }

         BuildRefhapInput bri = new BuildRefhapInput(params, chr);

      }
   }

   private void printGoodScaffolds() {
      ArrayList<Chromosome> allChro = params.getRawScaffolds(testChr);
      if (!allChro.isEmpty()) {
         for (int i = 0; i < allChro.size(); i++) {

            TreeMap<Integer, Scaffold> scaffs = allChro.get(i).getScaffolds();

            String name = scaffs.get(scaffs.firstKey()).getName();
            String filename = name + "_" + testChr + "_GoodScaffolds.gff3";
            BufferedWriter out = params.getOutputFile(filename, false);
            for(Integer j : scaffs.keySet()) {
               Scaffold scaff = scaffs.get(j);
               try {

                  out.write(scaff.getScaffoldGff3());
                  out.newLine();
               }
               catch (IOException ex) {
                  ex.printStackTrace();
               }
            }
            try {
               out.flush();
               out.close();
            }
            catch (IOException ex) {
               ex.printStackTrace();
            }
         }
      }
   }

   private void printScaffoldMeanDistanceHist() {

      ArrayList<Chromosome> allChro = params.getRawScaffolds(testChr);
      if (!allChro.isEmpty()) {
         TreeMap<Integer, Integer> hist = new TreeMap<Integer, Integer>();
         TreeMap<Integer, Double> covHist = new TreeMap<Integer, Double>();
         for (int i = -1; i <= 10; i++) {
            hist.put(i, 0);
            covHist.put(i, 0.0);
         }
         Integer snpDistCount = 0;
         for (Chromosome chr : allChro) {

            TreeMap<Integer, Scaffold> scaffs = chr.getScaffolds();
            String scaffName = scaffs.firstEntry().getValue().getName();
            //System.out.println("Original chr: " + testChr + "; Observed Chromsome " + chr.getChrName() + "; Scaffold Count: " + scaffs.size() + "; Library " + scaffName);
            for (Integer i : scaffs.keySet()) {
               hist.put(scaffs.get(i).getMeanSnpDist(), hist.get(scaffs.get(i).getMeanSnpDist()) + 1);
               covHist.put(scaffs.get(i).getMeanSnpDist(), covHist.get(scaffs.get(i).getMeanSnpDist()) + Double.parseDouble(scaffs.get(i).getMeanCoverageOverlappingScaffs()));
               snpDistCount += scaffs.get(i).getPhysicalSnpDistCount();
            }
         }
         for (Integer i : covHist.keySet()) {
            covHist.put(i, covHist.get(i) / hist.get(i));
         }
         for (int i = -1; i <= 10; i++) {
            System.out.println("Dist " + i + "; Count " + hist.get(i) + "; Coverage " + covHist.get(i));
         }
         System.out.println("Count overlaps used for histogram = " + snpDistCount);
      }
      else {
         System.out.println("No chromosome data found for " + testChr);
      }
   }

   private void printGffFiles(TreeMap<Integer, Scaffold> scaffs) {
      String filename = scaffs.get(scaffs.firstKey()).getSnpDistName() + params.getGff3Suffix();
      BufferedWriter out = params.getOutputFile(filename, false);
      for (Integer pos : scaffs.keySet()) {

         try {
            String outString = scaffs.get(pos).getSnpHapGffList() + params.getColor(scaffs.get(pos).getSnpDist());
            out.write(outString);
            out.newLine();
         }
         catch (IOException ex) {
            ex.printStackTrace();
         }
      }
      try {
         out.flush();
         out.close();
      }
      catch (IOException ex) {
         ex.printStackTrace();
      }
   }
}
