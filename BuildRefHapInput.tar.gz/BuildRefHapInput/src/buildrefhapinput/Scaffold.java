/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package buildrefhapinput;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

/**
 *
 * @author harry
 */
public class Scaffold implements Cloneable {

   private String chr;
   private int start;
   private int end;
   private int coverage;
   private Integer countInformativeLoci;//Count of SNP loci heterozygous in 78118 reference
   private String cell; //eg 29 the cell number from which aliquots taken
   private String subcell; // eg 29.2 the aliquot name
   private String filename;
   private RefhapLine refHapLine;//haplotype data for this scaffold
   private TreeMap<Integer, Integer> positionsAndAlleles;//Key Position; value allele as 0 reference 1 alt allele;
   private String snpDistName;
   private String overlappingSubcell;
   private String snpDiff; //String representing the difference bettween two overlapping scaffolds at each position
   private Double snpDist;//0.5 - 1.0. fraction of calls that are consistent with majority haplotype
   private Double switchDist;//Distance ignoring haplotypes switches cf Kaper 2013 PNAS
   private Integer snpCount;//Number of SNP in snpDiff
   private HashMap<String, Double> snpDistCumulative;//key overlapping scaffold name, value distance to overlapping scaffolds
   private HashMap<String, Integer> snpDistCount;//key other scaffold name value dist * length with other scaffolds
   private Integer physicalSnpDistCount = 0; //count of overlaps
   private Integer totalOverlapLength;//length of all overlaps overlapping this scaffold
   private File thisfile;//name of file that this scaffold is in
   private HashMap<File, Integer> sourceScaffs;//list of overlapping scaffolds.
   private ArrayList<Scaffold> overlappingScaffs;//list of overlapping scaffolds.
   //This is used by primary scaffolds that are represented on merged cells or chromosomes
   private HashMap<String, Double> hapDist;//distances to scaffolds that actually overlap this one.
   //String index is compased of gff3 file name and start position
   //This is used by primary scaffolds that are collected from gff3 files
   private ArrayList<Integer> snpPos;//Positions of SNP in snpDiff string.

   public Scaffold(String chr, int start, int end, int coverage, String cell, String subcell) {
      this.chr = chr;
      this.start = start;
      this.end = end;
      this.coverage = coverage;
      this.cell = cell;
      this.subcell = subcell;
      sourceScaffs = new HashMap<File, Integer>();
      hapDist = new HashMap<String, Double>();
      this.snpDist = 0.0;
      this.switchDist = 0.0;
      totalOverlapLength = 0;
      snpDistCumulative = new HashMap<String, Double>();
      snpDistCount = new HashMap<String, Integer>();
      overlappingScaffs = new ArrayList();
   }

  

   public Scaffold(String chr, int start, int end, String name, Double snpDist, Double switchDist, String subcell, String overlappingSubcell, String snpDiff, ArrayList<Integer> snpPos, int coverage) {
      this.chr = chr;
      this.start = start;
      this.end = end;
      this.snpDistName = name;
      this.snpDist = snpDist;
      this.switchDist = switchDist;
      this.subcell = subcell;
      this.overlappingSubcell = overlappingSubcell;
      this.snpDiff = snpDiff;
      this.snpPos = snpPos;
      this.coverage =  coverage;
      totalOverlapLength = 0;
      snpDistCumulative = new HashMap<String, Double>();
      snpDistCount = new HashMap<String, Integer>();
      sourceScaffs = new HashMap<File, Integer>();
      overlappingScaffs = new ArrayList();
   }

   public String getFilename() {
      return filename;
   }

   public String getSnpHapGffList() {
      return chr + "\tBuildRefHapInput.jar\tSubcell=" + subcell + ";Subcell2=" + overlappingSubcell + "\t" + start + "\t" + end + "\t.\t.\t.\tSNPdist=" + snpDist + ";NoSwitchErrorDist=" + switchDist + ";SnpCount=" + snpDiff.length() + ";SnpDiff=" + snpDiff + ";MeanCoverageOverlappingScaffs=0" + getMeanCoverageOverlappingScaffs() + ";";
   }

      public String getScaffoldGff3() {
      return chr + "\tBuildRefHapInput.jar\tLibrary=" + subcell + "\t" + start + "\t" + end + "\t.\t.\t.\tMeanSnpDist=" + getMeanSnpDist() +  ";Coverage=" + coverage + ";";
   }

   public Double getSwitchDist() {
      return switchDist;
   }

   public void setSwitchDist(Double switchDist) {
      this.switchDist += switchDist;
   }

   public Integer getTotalOverlapLength() {
      return totalOverlapLength;
   }

   public void setTotalOverlapLength(Integer totalOverlapLength) {
      this.totalOverlapLength += totalOverlapLength;
   }

   public void setOverlappingSubcell(String overlappingSubcell) {
      this.overlappingSubcell = overlappingSubcell;
   }

   public String getOverlappingSubcell() {
      return overlappingSubcell;
   }

   public void setFilename(String filename) {
      this.filename = filename;
   }

   public String getSnpDistName() {
      return snpDistName;
   }

   public void setHapDist(HashMap<String, Double> hapDist) {
      this.hapDist = hapDist;
   }

   public Double getSnpDist() {
      return snpDist;
   }

   public String getSnpDiff() {
      return snpDiff;
   }

   public ArrayList<Integer> getSnpPos() {
      return snpPos;
   }

   public void setSnpPos(ArrayList<Integer> snpPos) {
      this.snpPos = snpPos;
   }

   public void setSourceScaffs(HashMap<File, Integer> sourceScaffs) {
      this.sourceScaffs = sourceScaffs;
   }

   public void setOverlappingScaff(Scaffold scaff){
      overlappingScaffs.add(scaff);
   }

   public File getThisfile() {
      return thisfile;
   }

   public void setThisfile(File thisfile) {
      this.thisfile = thisfile;
   }

   public String getChr() {
      return chr;
   }

   public HashMap<File, Integer> OverlappingScaffolds() {
      return sourceScaffs;
   }

   public Integer getOverlappingScaffold(File file) {
      return sourceScaffs.get(file);
   }

   public void addSourceFile(File file, Integer start) {
      sourceScaffs.put(file, start);
   }

   public int getCoverage() {
      return coverage;
   }

   public String getCell() {
      return cell.substring(cell.indexOf("-") + 1);
   }

   public String getSubcell() {
      return subcell;
   }

   public void setSubcell(String subcell) {
      this.subcell = subcell;
   }

   public void setCoverage(int coverage) {
      this.coverage = coverage;
   }

   public int getEnd() {
      return end;
   }

   public void setEnd(int end) {
      this.end = end;
   }

   public int getStart() {
      return start;
   }

   public void setStart(int start) {
      this.start = start;
   }

   public void incrementCoverage() {
      coverage++;
   }

   public Integer getCountInformativeLoci() {
      return countInformativeLoci;
   }

   public void setCountInformativeLoci(Integer countInformativeLoci) {
      this.countInformativeLoci = countInformativeLoci;
   }

   public TreeMap<Integer, Integer> getPositionsAndAlleles() {
      return positionsAndAlleles;
   }

   public void setPositionsAndAlleles(TreeMap<Integer, Integer> positionsAndAlleles) {
      this.positionsAndAlleles = positionsAndAlleles;
   }

   public RefhapLine getRefHapLine() {
      return refHapLine;
   }

   public void setRefHapLine(RefhapLine refHapLine) {
      this.refHapLine = refHapLine;
   }

   public String getInterval() {
      return chr + "\t" + start + "\t" + end + "\t" + coverage;
   }

   public String getIntervalGff3() {
      return chr + "\tBuildRefHapInput.jar\tnull\t" + start + "\t" + end + "\t\t.\t.\t.\t.\tcoverage=" + coverage;
   }

   public String getIntervalAndOverlappingScaffs(){
      StringBuilder out = new StringBuilder(getInterval() + "\t" + cell + "\t" + getMeanSnpDist());
      for(Scaffold scaff: overlappingScaffs){
         out.append(";" + scaff.getCell() + ":" + scaff.getStart() + "-" + scaff.getEnd());
      }

      return out.toString();
   }

   public String getMeanCoverageOverlappingScaffs(){
      Double meanCov = 0.0;
      Integer count = 0;
      for(Scaffold scaff: overlappingScaffs){
         meanCov += scaff.getCoverage() * (scaff.getStart() - scaff.getEnd() +1);
         count += (scaff.getStart() - scaff.getEnd() +1);
      }
      meanCov =  meanCov/count;
      return meanCov.toString();
   }

   public Double getHapDist(String scaName) {
      return hapDist.get(scaName);
   }

   public HashMap<String, Double> getAllHapDists() {
      return hapDist;
   }

   public void setHapDist(String name, Double dist) {
      hapDist.put(name, dist);
   }

   public void setSnpDistValues(String name, Integer overlapLength, Double snpDistCumulative) {
      this.snpDistCount.put(name, overlapLength);
      this.snpDistCumulative.put(name, snpDistCumulative);
      this.physicalSnpDistCount++;
   }

   public void removeSnpDistValues(String name) {
      if (snpDistCount.containsKey(name)) {
         this.snpDistCount.remove(name);
         this.snpDistCumulative.remove(name);
         this.physicalSnpDistCount--;
      }
   }
   public void clearSnpDistValues(String name) {
      if (snpDistCount.containsKey(name)) {
         this.snpDistCount.clear();
         this.snpDistCumulative.clear();
         this.physicalSnpDistCount =0;
      }
   }

   public Integer getPhysicalSnpDistCount() {
      return physicalSnpDistCount;
   }

   public Double getSNpDist(String name) {
      if (snpDistCumulative.containsKey(name)) {
         return snpDistCumulative.get(name);
      }
      else {
         return 0.0;
      }
   }

   public Integer getMeanSnpDist() {
      Double cumulative = 0.0;
      Integer length = 0;

      if (snpDistCount.size() > 0) {

         for (String name : snpDistCount.keySet()) {
            cumulative += (snpDistCumulative.get(name));
            length += snpDistCount.get(name);
         }
      }
      if (length > 0) {
         Double returnVal = (10 * (cumulative / length));
         return returnVal.intValue();
      }
      else {
         return -1;
      }
   }

   public void clearSnpDistVals() {
      snpDistCumulative.clear();
      snpDistCount.clear();
      physicalSnpDistCount = 0;

   }

   public String getName() {
      String returnVal = "Chr";
      if (cell.startsWith("Chr")) {
         returnVal = cell;
      }
      else {
         returnVal = chr + "-" + cell;
      }

      return returnVal;
   }

   public String getNameStart() {
      String returnVal = getName() + "_" + start;
      return returnVal;
   }

   @Override
   public Scaffold clone() throws CloneNotSupportedException {

      Scaffold scaffClone = new Scaffold(chr, start, end, coverage, cell, subcell);
      scaffClone.setSourceScaffs((HashMap<File, Integer>) sourceScaffs.clone());
      scaffClone.setHapDist((HashMap<String, Double>) hapDist.clone());
      scaffClone.setFilename(filename);
      return scaffClone;

   }
}
