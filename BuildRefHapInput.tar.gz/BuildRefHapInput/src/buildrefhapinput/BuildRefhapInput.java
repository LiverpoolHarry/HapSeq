/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package buildrefhapinput;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author harry
 */
public class BuildRefhapInput {

   private Params p;
   private Random rn;
   private HashMap<String, TreeMap<Integer, RefAndAltAlleles>> allRefAndAltAlleles;//Chr, Position, RefAndAltAlleles
   //Chr, Subcell, Position, 012 alleles  modified to 0 for ref and 1 for alt
   //Populated by getBadPositions
   private HashMap<String, TreeMap<Integer, Short>> chroAllelePos;// Subcell; Position; allele
   private ArrayList<Integer> allPositions;//all good positions on a chromosome
   private HashMap<Integer, String> sampleNames; // sample name; column number in vcf file
   private String sampleList;
   private String chr;
   public Short one = null;
   public Short zero = 0;
   public Short two = 1;//this is used for converting 2 in 012 output to 1 in sih input
   private HashMap<String, Short> shortAlleles;

   public BuildRefhapInput(Params p, String chr) {
      this.p = p;
      this.chr = chr;
      rn = new Random();
      allRefAndAltAlleles = new HashMap<String, TreeMap<Integer, RefAndAltAlleles>>();
      allRefAndAltAlleles.put(chr, new TreeMap<Integer, RefAndAltAlleles>());
      // does not contain lines with heterozygotes but does contain lines with > 2 biallelic alleles at a locus.
      chroAllelePos = p.getChroAllelePos();
      shortAlleles = new HashMap<String, Short>(4);
      shortAlleles.put("0", zero);
      shortAlleles.put("1", one);
      shortAlleles.put("2", two);
      allPositions = p.getAllelePositions();

      run(chr);
   }

   private void run(String physicalChr) {

      ArrayList<Chromosome> rawChros = p.getRawScaffolds(physicalChr);
      getRefAndAltAlleles(physicalChr);//extract alleles from vcf output
      String fragsFile = physicalChr + ".frags";
      ArrayList<RefhapLine> refhaps = buildRefHapInput(rawChros);
      p.deleteFile(fragsFile);
      writeRefhapFiles(fragsFile, refhaps);
      String allvarsFile = physicalChr + ".allvars";
      p.deleteFile(allvarsFile);
      writeRefAndAltAlleles(allvarsFile, physicalChr);
      getSnpIntervalStats();
 
   }

   //Iterate over each scaffold for each subcell on chromosomes and build a refhap entry line for each scaffold
   private ArrayList<RefhapLine> buildRefHapInput(ArrayList<Chromosome> scaffs) {

      ArrayList<RefhapLine> refhap = new ArrayList<RefhapLine>();
      Integer lengthScaffOver1InformativeLoci = 0;
      Integer countInformativeLoci = 0;
      Short One = 1;
      StringBuilder subcellNames = new StringBuilder("Subcells: ");
      for (Chromosome chrom : scaffs) {

         String subcell = chrom.getScaffold(chrom.getScaffolds().ceilingKey(0)).getSubcell();
         subcellNames.append(subcell + "; ");
         TreeSet<Integer> goodPos = new TreeSet<Integer>();
         goodPos.addAll(allPositions);

         int exceptionCheckCount = 0;
         int totalhapGroupCount = 0;
         TreeMap<Integer, Scaffold> scaffList = chrom.getScaffolds();
         exceptionCheck:
         for (Integer pos : scaffList.keySet()) {
            Integer scaffStart = scaffList.get(pos).getStart();
            Integer scaffEnd = scaffList.get(pos).getEnd();
            Integer snpPos = goodPos.ceiling(scaffStart);
            Integer snpEnd = goodPos.floor(scaffEnd);
            Integer prePos = 0;
            countInformativeLoci = 0;
            Integer alleleStringStart = 0;
            StringBuilder refhapAlleles = new StringBuilder();
            StringBuilder refhapLine = new StringBuilder(chr + "_" + subcell + "_" + snpPos);
            int hapGroupCount = 0;
            if (!chroAllelePos.containsKey(subcell)) {
               exceptionCheckCount++;
               continue exceptionCheck;
            }
            int posCount = 0;
            while (snpPos != null && snpEnd != null && snpPos <= snpEnd) {

               //if no allele for this subcell at this position create break in refhap entry and write data up to this point
               //If position is not in this subcell comparison then write refhap string or if position is hetetrozygous
               // added "|| snpPos - prePos > 1" because clusters should only be written if they are in a numberical sequence
               if (!chroAllelePos.get(subcell).containsKey(snpPos) || chroAllelePos.get(subcell).get(snpPos).equals(One) ) {
                  if (alleleStringStart > 0) {
                     refhapLine.append( refhapAlleles.toString());
                     refhapAlleles.delete(0, refhapAlleles.length());
                  }
                  alleleStringStart = 0;
                  posCount++;
               }
               if(chroAllelePos.get(subcell).containsKey(snpPos)) {
                  if (alleleStringStart == 0) {
                     alleleStringStart = snpPos;
                  }
                  if(snpPos - prePos == 1){
                     refhapAlleles.append(chroAllelePos.get(subcell).get(snpPos));
                     countInformativeLoci++;
                  }
                  else{
                  refhapAlleles.append(" " + snpPos + " " + chroAllelePos.get(subcell).get(snpPos));
                  countInformativeLoci++;
                  hapGroupCount++;
                  }
               }
               prePos = snpPos;
               snpPos = goodPos.ceiling(snpPos + 1);
               if (snpPos == null) {
                  snpPos = snpEnd + 1;
               }

            }
            if (alleleStringStart > 0) {
               refhapLine.append( refhapAlleles.toString());
            }
            if (countInformativeLoci > 1) {
               refhapLine.insert(0, hapGroupCount + " ");
               RefhapLine rhl = new RefhapLine(goodPos.ceiling(scaffStart), refhapLine.toString());
               refhap.add(rhl);
               scaffList.get(pos).setRefHapLine(rhl);
            }
            scaffList.get(pos).setCountInformativeLoci(countInformativeLoci);
            if (countInformativeLoci > 1) {
               lengthScaffOver1InformativeLoci += scaffList.get(pos).getEnd() - scaffList.get(pos).getStart() + 1;
            }
            totalhapGroupCount += hapGroupCount;
         }
      }
      StringBuilder alleleSubcells = new StringBuilder();
      for (String all : chroAllelePos.keySet()) {
         alleleSubcells.append(all + "; ");
      }
      Collections.sort(refhap);
      return refhap;
   }

   private void writeRefhapFiles(String filename, ArrayList<RefhapLine> refhaps) {
      BufferedWriter out = getOutputFile(filename);
      for (RefhapLine line : refhaps) {
         try {
            out.write(line.getLine());
            out.newLine();
         }
         catch (IOException ex) {
            ex.printStackTrace();
         }
      }
      try {
         out.close();
      }
      catch (IOException ex) {
         Logger.getLogger(BuildRefhapInput.class.getName()).log(Level.SEVERE, null, ex);
      }

   }

   private void writeRefAndAltAlleles(String filename, String chr) {
      BufferedWriter out = getOutputFile(filename);
      TreeMap<Integer, RefAndAltAlleles> alleles = allRefAndAltAlleles.get(chr);
      for (Integer pos : alleles.keySet()) {
         try {
            out.write(alleles.get(pos).toString());
            out.newLine();
         }
         catch (IOException ex) {
            ex.printStackTrace();
         }
      }
      try {
         out.close();
      }
      catch (IOException ex) {
         Logger.getLogger(BuildRefhapInput.class.getName()).log(Level.SEVERE, null, ex);
      }
   }

   private void getRefAndAltAlleles(String chr) {
      String firstSubcell = p.getAllRawScaffolds().get(0).getScaffolds().firstEntry().getValue().getSubcell();
      String outfile = chr + "vcf";
      String command = p.getVcftools() + "vcftools --gzvcf " + p.getVcfFile() + " --indv " + firstSubcell + " --chr " + chr + " --from-bp " + p.getMinStart() + " --to-bp " + p.getMaxEnd() + " --out " + outfile + " --recode";
      runVcfCommand(command);
      String filename = outfile + ".recode.vcf";
      File file = new File(filename);


      readVCFFile(file);
   }

   //remove lines with heterozygotes or more than two transitions at a locus
   private void cleanChroAllelePos() {
      allPositions = p.getAllelePositions();

      //Clean up all012Alleles. Change 2 to 1 for refhap and remove positions with alleles -1 or > 2
      //heterozygote positions need to be removed from all samples 
      //whereas -1 or > 2 only need ot be removed from specific samples.
      for (int po = 0; po < allPositions.size(); po++) {
         Boolean flag = true;
         Integer pos = allPositions.get(po);
         for (String sample : sampleNames.values()) {
            //check to see if sample is on exclusion list
            if (p.checkSample(sample)) {
               if (chroAllelePos.get(sample).containsKey(pos)) {
                  if (chroAllelePos.get(sample).get(pos).equals(1)) {
                     chroAllelePos.get(sample).remove(pos);
                  }

               }
            }
         }
      }

   }

   private void runVcfCommand(String com) {
      System.out.println(com);
      try {
         final Process process = Runtime.getRuntime().exec(com);
         int returnCode = process.waitFor();
         System.out.println("Return code from command: " + returnCode);
      }
      catch (Exception e) {
         e.printStackTrace();
      }
   }

   public void readVCFFile(File file) {
      int lineCount = 0;
      int headerCount = 0;

      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream:

         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));
         int start = p.getMinStart();

         int end = p.getMaxEnd();
         String strLine;
         String[] data;
         boolean flag = false;
         while ((strLine = br.readLine()) != null) {
            if (strLine.startsWith("#")) {
               headerCount++;
               if (strLine.startsWith("#CHROM")) {
                  getSampleNames(strLine);
               }
               continue;
            }
            if (strLine.startsWith("Chr")) {
               data = strLine.split("\t");
               Integer position = Integer.parseInt(data[1]);

               if (position >= start && position <= end) {
                  lineCount++;
                  RefAndAltAlleles raa = new RefAndAltAlleles(data[0], position, position, data[3], data[4], "SNP");
                  allRefAndAltAlleles.get(data[0]).put(position, raa);
               }
            }
         }
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.out.println("Caught error at BuildRefHapInput line 315 after processing " + lineCount + " lines and " + headerCount + " header lines");
         System.err.println("File Open Error: " + e.getMessage());
         e.printStackTrace();
      }
   }

   //create new Treemap for each sample
   private void getSampleNames(String line) {
      sampleNames = new HashMap<Integer, String>();
      StringBuilder samples = new StringBuilder();
      String[] names = line.split("\t");
      int i = 0;
      for (int j = 9; j < names.length; j++) {
         //Check for reference sample
         if (p.checkSample(names[j])) {
            sampleNames.put(i, names[j]);

            samples.append(" --indv " + names[j]);
            i++;
         }
      }

      sampleList = samples.toString();
   }

   private void getSnpIntervalStats(){
      int gapLength = 0;
      int gapCount=0;
      ArrayList<Integer> gaps = new ArrayList<Integer>();

      for(String ch: allRefAndAltAlleles.keySet()){
         Integer prepos = allRefAndAltAlleles.get(ch).firstKey();
         for(Integer pos :allRefAndAltAlleles.get(ch).keySet() ){
            //if(pos == prepos){continue;}
            int gap = pos - prepos;
            gapLength += gap;
            gaps.add(gap);
            gapCount++;
            prepos = pos;
         }
      }
      int meanGap = gapLength / gapCount;
      int halfLength = gapLength/2;
      int sum =0;
      Collections.sort(gaps);
      int i = 0;
      while(sum < halfLength){
         sum += gaps.get(i);
         i++;
      }
      Integer N50 = (gaps.get(i) +  gaps.get(i -1)) /2;
      System.out.println("Mean interval between SNP = " + meanGap);
      System.out.println("N50 interval between SNP = " + N50);
      System.out.println("Max interval between SNP = " + gaps.get(gaps.size() -1));
   }

   private BufferedWriter getOutputFile(String filename) {
      BufferedWriter analysisFile = null;
      try {
         FileWriter fstream = new FileWriter(filename, true);
         analysisFile =
               new BufferedWriter(fstream);
      }
      catch (IOException e) {
         System.out.println("IOException : " + e);
      }

      return analysisFile;
   }
}
