/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package buildrefhapinput;

/*
 * Assumes that gff3 files are in subdirectories of the current directory.
 * Each directory holds data for just one chromosome
 * The directory names are prefixed by the chromosome name and an underscore
 * eg Chr10_
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/**
 *
 * @author harry
 */
public class Main {

   private static HashMap<String, String> comLineVars;

   /**
    * @param args the command line arguments
    */
   public static void main(String[] args) {

      Date startTime = new Date();

      getArgs(args);
      System.out.println("Finished " + comLineVars.get("chr") + " at " + getDateTime());
      Date finishTime = new Date();
      Long elapsedTimeMin = ((finishTime.getTime() - startTime.getTime()) / 60000);
      Long elapsedTimeSec = ((finishTime.getTime() - startTime.getTime()) / 1000) % 60;
      System.out.println("Finished run at " + getDateTime());
      System.out.println("Elapsed time = " + elapsedTimeMin + "m:" + elapsedTimeSec + "s");
      //beep to indicate end of programme
      System.out.println((char) 7);
      System.out.println((char) 7);
      System.out.println((char) 7);
      System.out.println((char) 7);


   }

   private static void getArgs(String[] args) {
      String vars = "vcftoolschrgff3pathvcfpathbreakAtHetsexcludewriteTablesminConsistencymaxHetsmaxHetPropgff3SuffixfileList";
      comLineVars = new HashMap<String, String>();
      String path = System.getProperty("user.dir");

      ArrayList<String> excludedSamples = new ArrayList<String>();
      if (args.length > 0) {
         for (String var : args) {
            if (var.contains(">") || !var.contains("=")) {//so that output redirection can be put in command line
               break;
            }
            String[] arg = var.split("=");
            if (arg[0].contentEquals("exclude")) {
               excludedSamples.add(arg[1]);
            }
            else if (vars.contains(arg[0])) {
               comLineVars.put(arg[0], arg[1]);
            }
            else {
               printhelp("Argument " + arg[0] + " is not a valid parameter");
            }

         }
         System.out.println("Path " + path);
      }
      else {
         printhelp("No arguments supplied.");
      }

      if (checkRequiredArgs()) {
         RunAnalysis ra = new RunAnalysis(comLineVars, excludedSamples);
         ra.analyseCells();
         //ra.analyseChromosomes();
         ra.analyseScaffolds();

      }
      else {
         printhelp("");
      }


      //return checkRequiredArgs();
   }

   private static boolean checkRequiredArgs() {
      HashSet<String> requiredArgs = new HashSet<String>();
      requiredArgs.add("chr");
      requiredArgs.add("fileList");
      requiredArgs.add("vcfpath");
      requiredArgs.add("vcftools");
      for (String arg : comLineVars.keySet()) {
         if (requiredArgs.contains(arg)) {
            requiredArgs.remove(arg);
         }
      }
      if (requiredArgs.isEmpty()) {
         return true;
      }
      else {
         Iterator it = requiredArgs.iterator();
         while (it.hasNext()) {
            System.out.println("Required argument " + it.next() + " is missing");
         }
         return false;
      }

   }

   private static String getDateTime() {
      DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss z");
      Date date = new Date();
      return dateFormat.format(date);
   }

   private static void printhelp(String message) {
      if (!message.isEmpty()) {
         System.out.println(message);
      }

      System.out.println("To run the programme: \n java -Xmn4g -jar path/BuildRefHapInput.jar <options>");
      System.out.println("Options should be entered as key value pairs seperated by = and no spaces");
      System.out.println("Eg: java -Xmn4g -jar path/CountScaffoldCoverage.jar chr=Chr5 vcfpath=path/to/file/ fileList=path/to/file exclude=ref1 exclude=ref2\n");

      HashMap<String, String> help = new HashMap<String, String>();
      help.put("chr:            ", "Required; chromosome number in format used in vcf file eg chr=Chr5");
      help.put("gff3path:       ", "Optional; path to directory containing gff3 files to be processed. Default current directory. eg gff3path=/path/to/file/");
      help.put("fileList:       ", "Required; File containing list of gff3 files to be processed, one per line.");
      help.put("vcfpath:        ", "Required; path to directory containing vcf file corresponding to gff3 file. vcfpath=/path/to/file/ChrX.vcf.gz");
      help.put("vcftools:       ", "Required; path to bin directory with vcftools commands. vcftools=/path/vcftools/bin/");
      help.put("gff3Suffix:     ", "Optional; Suffix for gff3 output files. Default .gff3");
      help.put("minConsistency: ", "Optional; minimum mean consistency of scaffolds that overlap index scaffold for index scaffold to be retained in analysis. Default 0; Range 0-1");
      help.put("maxHets:        ", "Optional; maximum number of heterozygotous positions allowed in a scaffold. Integer >= 0. Default 3");
      help.put("maxHetProp:     ", "Optional; max proportion of heterozygotous positions allowed in a scaffold. Double 0.0-1.0. Default 0.2");
      help.put("exclude:        ", "Optional; samples in vcf file to be excluded from the analysis. Eg reference bulk sequence; EG exclude=ref1 exclude=ref2");
      help.put("writeTables:    ", "Optional; boolean, default false; write filtered genotypes (012 format) and scaffolds to files");
      String vars = "chrgff3pathvcfpathbreakAtHetsexcludewriteTablesminConsistencyfileList";
      for (String param : help.keySet()) {
         System.out.println("    " + param + "\t\t" + help.get(param));
      }

      System.exit(-1);

   }
}
