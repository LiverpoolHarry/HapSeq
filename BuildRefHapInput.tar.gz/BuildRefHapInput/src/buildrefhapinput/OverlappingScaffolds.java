/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package buildrefhapinput;

/**
 *
 * @author harry
 */
public class OverlappingScaffolds {

   private String chr;
   private Integer overlapStart;
   private Scaffold scaff1;
   private Scaffold scaff2;
   private int overlapLength;

   public OverlappingScaffolds(String chr, Integer overlapStart, int overlapLength, Scaffold scaff1, Scaffold scaff2) {
      this.chr = chr;
      this.overlapStart = overlapStart;
      this.scaff1 = scaff1;
      this.scaff2 = scaff2;
      this.overlapLength = overlapLength;
   }

   public String getChr() {
      return chr;
   }

   public Integer getOverlapStart() {
      return overlapStart;
   }

   public Scaffold getScaff1() {
      return scaff1;
   }

   public Scaffold getScaff2() {
      return scaff2;
   }
   public String getId(){
      return chr + "_" + overlapStart;
   }

   public int getOverlapLength() {
      return overlapLength;
   }

   public void setOverlapLength(int overlapLength) {
      this.overlapLength = overlapLength;
   }

}
