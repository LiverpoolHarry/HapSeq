/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package buildrefhapinput;

import java.io.File;
import java.util.TreeMap;

/**
 *
 * @author harry
 * A Chromosome is a set of scaffolds derived from a single library
 */
public class Chromosome implements Cloneable {

   private TreeMap<Integer, Scaffold> scaffolds;
   private String name;
   private File file;

   public Chromosome(String name, TreeMap<Integer, Scaffold> scaffolds) {
      this.name = name;
      this.scaffolds = scaffolds;
   }

   public Chromosome(File file, TreeMap<Integer, Scaffold> scaffolds) {
      this.file = file;
      this.scaffolds = scaffolds;
      this.name = file.getName();
   }

   public Chromosome(String name) {
      scaffolds = new TreeMap<Integer, Scaffold>();
   }

   // returns name of file
   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public File getFile() {
      return file;
   }

   public String getChrName() {
      return scaffolds.get(scaffolds.firstKey()).getChr();
   }

   public TreeMap<Integer, Scaffold> getScaffolds() {
      return scaffolds;
   }

   public void setScaffolds(TreeMap<Integer, Scaffold> scaffolds) {
      this.scaffolds = scaffolds;
   }

   public void addScaffold(Scaffold scaff) {
      this.scaffolds.put(scaff.getStart(), scaff);
   }

   public Scaffold getScaffold(Integer i) {
      return scaffolds.get(i);
   }

   @Override
   protected Object clone() throws CloneNotSupportedException {
      Chromosome cloned = (Chromosome) super.clone();
      cloned.setScaffolds((TreeMap<Integer, Scaffold>) cloned.getScaffolds().clone());
      TreeMap<Integer, Scaffold> temp = cloned.getScaffolds();
      for(Integer key: temp.keySet()){
         temp.put(key, temp.get(key).clone());
      }
      return cloned;
   }
}
