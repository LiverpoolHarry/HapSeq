/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package buildrefhapinput;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

/**
 *
 * @author harry
 */
public class Params {

   private HashMap<String, File> vcffiles;
   private Integer minScaffoldLength;
   private Double minDist = 0.0;//minimum average distance for between pairs of overlapping scaffolds below which they get deleted
   private int maxHets = 3;
   private double maxHetProp = 0.2;
   private String vcftools;
   private boolean writeSO = false;
   private boolean SnpHapsGotOnce = false;
   private boolean writeTables = false;
   private ArrayList<String> libraries;
   private ArrayList<OverlappingScaffolds> OverlapList;
   private HashMap<File, Chromosome> primaryChros;//File, Chromosome
   private ArrayList<Chromosome> rawScaffolds;
   private TreeMap<Double, String> colors;
   private TreeMap<String, TreeMap<String, Chromosome>> snpDistScaffolds;
   private HashMap<String, ArrayList<Chromosome>> chrRawScaffolds;//chromosome eg "Chr21"; Array of Chromosome Objects
   private String vcfFile;
    private String gff3path;//path to files
   private String gff3Suffix = ".gff3";
   private File logfile;
   private int minStart = 1000000000;//min and max scaffold positions in scaffolds
   private int maxEnd = 0;
   private ArrayList<String> exclusions;//samples that should be excluded from ahplotype analysis eg reference samples
   private HashMap<String, ArrayList<Integer>> vcfPositions;//key chromosome; value: List of positions
   private HashMap<String, ArrayList<Integer>> cleanedVcfPositions;//key chromosome; value: List of positions
   private HashMap<String, HashMap<String, TreeMap<Integer, Integer>>> cleanedVcfAlleles;//key: chr; key: subcell; value: Hashmap Position , allele (-1,0,1,2);
   private String chr;
   private ArrayList<Integer> allelePositions;
   private HashMap<String, TreeMap<Integer, Short>> chroAllelePos;//key subcell;  arrayList allele

   public Params(HashMap<String, String> comLineVars, Integer minScaffoldLength) {


      if (comLineVars.containsKey("gff3path")) {
         this.gff3path = comLineVars.get("gff3path");
         if (!gff3path.endsWith("/")) {
            gff3path = gff3path + "/";
         }
      }
      this.minScaffoldLength = minScaffoldLength;

      vcfFile = comLineVars.get("vcfpath");
      vcftools = comLineVars.get("vcftools");

      if (comLineVars.containsKey("writeTables")) {
         writeTables = Boolean.parseBoolean(comLineVars.get("writeTables"));
      }
      if (comLineVars.containsKey("minConsistency")) {
         minDist = Double.parseDouble(comLineVars.get("minConsistency"));
      }
      if (comLineVars.containsKey("maxHets")) {
         maxHets = Integer.parseInt(comLineVars.get("maxHets"));
      }
      if (comLineVars.containsKey("maxHetProp")) {
         maxHetProp = Double.parseDouble(comLineVars.get("maxHetProp"));
      }
      if (comLineVars.containsKey("gff3Suffix")) {
         gff3Suffix = comLineVars.get("gff3Suffix");
      }
      writeTables=true;
      chr = comLineVars.get("chr");

      libraries = new ArrayList<String>();
      snpDistScaffolds = new TreeMap<String, TreeMap<String, Chromosome>>();
      vcfPositions = new HashMap<String, ArrayList<Integer>>();
      cleanedVcfAlleles = new HashMap<String, HashMap<String, TreeMap<Integer, Integer>>>();
      cleanedVcfPositions = new HashMap<String, ArrayList<Integer>>();
      chrRawScaffolds = new HashMap<String, ArrayList<Chromosome>>();
      primaryChros = new HashMap<File, Chromosome>();

      colors = new TreeMap<Double, String>();
      colors.put(-1.0, "#CCCCCC");
      colors.put(0.0, "#F9F524");
      colors.put(0.1, "#B9F31F");
      colors.put(0.2, "#77ED1B");
      colors.put(0.3, "#36E717");
      colors.put(0.4, "#13E130");
      colors.put(0.5, "#0FDC67");
      colors.put(0.6, "#0CD69D");
      colors.put(0.7, "#09CED0");
      colors.put(0.8, "#0590CA");
      colors.put(0.9, "#0253C4");
      colors.put(1.0, "#0018BF");
   }

   public void resetVcfData() {
      vcfPositions.clear();
   }

   public String getColor(Double i) {
      return "color=" + colors.get(colors.floorKey(i));
   }

   public File getVcfFile() {
      return new File(vcfFile);
   }

   public TreeMap<String, TreeMap<String, Chromosome>> getSnpDistScaffolds() {
      return snpDistScaffolds;
   }

   public void setSnpDistScaffolds(String chr, TreeMap<String, Chromosome> snpDistScaffolds) {
      this.snpDistScaffolds.put(chr, snpDistScaffolds);
   }

   public void setOverlapList(ArrayList<OverlappingScaffolds> OverlapList) {
      this.OverlapList = OverlapList;
   }

 
  
   public ArrayList<String> getExclusions() {
      return exclusions;
   }

   public String getVcfExclusions() {
      StringBuilder sb = new StringBuilder();
      for(String ex : exclusions){
         sb.append(" --remove-indv " + ex );
      }
      return sb.toString();
   }

   public double getMaxHetProp() {
      return maxHetProp;
   }

   public int getMaxHets() {
      return maxHets;
   }

   public File getLogfile() {
      return logfile;
   }

   public String getVcftools() {
      return vcftools;
   }

   public String getGff3Path() {
      return gff3path;
   }

   public String getChr() {
      return chr;
   }

   public void setExclusions(ArrayList<String> exclusions) {
      this.exclusions = exclusions;
      System.out.println("Set " + exclusions.size() + " exclusions");
   }

   public void addPrimaryChros(File file, Chromosome chro) {
      primaryChros.put(file, chro);
   }

   public Double getMinDist() {
      return minDist;
   }

   public int getMaxEnd() {
      return maxEnd;
   }

   public void setMaxEnd(int maxEnd) {
      this.maxEnd = maxEnd;
   }

   public int getMinStart() {
      return minStart;
   }

   public void setMinStart(int minStart) {
      this.minStart = minStart;
   }

   public void setMinDist(Double minDist) {
      this.minDist = minDist;
   }

   public boolean isWriteTables() {
      return writeTables;
   }

   public String getGff3Suffix() {
      return gff3Suffix;
   }

   public HashMap<String, ArrayList<Integer>> getVcfPositions() {
      return vcfPositions;
   }

   public ArrayList<Integer> getVcfPositions(String chr) {
      return vcfPositions.get(chr);
   }

   public Boolean vcfPositionsContainsKey(String chr) {
      return vcfPositions.containsKey(chr);
   }

   public void setVcfPositions(String chr, ArrayList<Integer> vcfPositions) {
      this.vcfPositions.put(chr, vcfPositions);
   }

   public ArrayList<Integer> getAllelePositions() {
      return allelePositions;
   }

   public void setAllelePositions(ArrayList<Integer> allelePositions) {
      this.allelePositions = allelePositions;
   }

   public HashMap<String, TreeMap<Integer, Short>> getChroAllelePos() {
      return chroAllelePos;
   }

   public void setChroAllelePos(HashMap<String, TreeMap<Integer, Short>> chroAllelePos) {
      this.chroAllelePos = chroAllelePos;
   }

   public HashMap<String, ArrayList<Integer>> getCleanedVcfPositions() {
      if (cleanedVcfPositions.isEmpty()) {
         return null;
      }
      else {
         return cleanedVcfPositions;
      }
   }

   public boolean checkSample(String sam) {
      boolean check = true;
      for (String exc : exclusions) {
         if (exc.contains(sam)) {
            check = false;
         }
      }
      return check;
   }

   public boolean isSnpHapsGotOnce() {
      return SnpHapsGotOnce;
   }

   public void setSnpHapsGotOnce(boolean SnpHapsGotOnce) {
      this.SnpHapsGotOnce = SnpHapsGotOnce;
   }

   public ArrayList<Chromosome> getAllRawScaffolds() {
      return rawScaffolds;
   }

   public ArrayList<Chromosome> getRawScaffolds(String chr) {
      if (chrRawScaffolds.containsKey(chr)) {
         return chrRawScaffolds.get(chr);
      }
      else {
         return new ArrayList<Chromosome>();
      }
   }

   public void setRawScaffolds(ArrayList<Chromosome> rawScaffolds) {
      this.rawScaffolds = rawScaffolds;
      for (Chromosome ch : rawScaffolds) {
         String chName = ch.getChrName();
         if (chrRawScaffolds.containsKey(chName)) {
            chrRawScaffolds.get(chName).add(ch);
         }
         else {
            chrRawScaffolds.put(chName, new ArrayList<Chromosome>());
            chrRawScaffolds.get(chName).add(ch);
         }
      }
   }

   public void deleteFile(String filename) {
      try {

         File file = new File(filename);

         if (file.delete()) {
            System.out.println(file.getName() + " is deleted!");
         }
         else {
            System.out.println("Delete of " + filename + " failed.");
         }

      }
      catch (Exception e) {
         e.printStackTrace();
      }
   }

   public TreeMap<Integer, Scaffold> readFile(File file) {

      TreeMap<Integer, Scaffold> scaffolds = new TreeMap<Integer, Scaffold>();
      try {
         // Open the file that is the first
         // command line parameter
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));
         String strLine;
         //name should be library name
         String subcell = file.getName().substring(0, file.getName().indexOf("Chr"));
         String cell = subcell;
         if (subcell.contains(".")) {
            cell = subcell.substring(0, subcell.indexOf("."));
         }
         //Read File Line By Line
         while ((strLine = br.readLine()) != null) {
            String[] data = strLine.split("\t");
            data[8] = data[8].replace(",", "");
            Double cov = Double.parseDouble(data[8].replace("coverage=", ""));
            Integer coverage = cov.intValue();
            Scaffold scaff = new Scaffold(data[0], Integer.parseInt(data[3]), Integer.parseInt(data[4]), coverage, cell, subcell);
            if (!libraries.contains(subcell)) {
               libraries.add(subcell);
            }
            scaff.setFilename(file.getName());
            scaff.setThisfile(file);
            scaffolds.put(Integer.parseInt(data[3]), scaff);

         }
         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("Error in params.readFile(): " + e.getMessage());
         e.printStackTrace();
      }
      return scaffolds;
   }

   public ArrayList<String> readSnpFile(File file) {
      ArrayList<String> dataArray = new ArrayList<String>();
      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;
         while ((strLine = br.readLine()) != null) {
            dataArray.add(strLine);
         }
         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error  at Params line 475: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
      }


      return dataArray;

   }

   public BufferedWriter getOutputFile(String filename, Boolean append) {
      BufferedWriter analysisFile = null;
      try {
         FileWriter fstream = new FileWriter(new File(filename), append);
         analysisFile = new BufferedWriter(fstream);
      }
      catch (IOException e) {
         System.out.println("IOException : " + e);
      }
      return analysisFile;
   }
}
