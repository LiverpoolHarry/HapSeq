/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package buildrefhapinput;

  public class RefAndAltAlleles {

      String chr;
      Integer start;
      Integer end;
      String refAllele;
      String altAllele;
      String type;

      public RefAndAltAlleles(String chr, Integer start, Integer end, String refAllele, String altAllele, String type) {
         this.chr = chr;
         this.start = start;
         this.end = end;
         this.refAllele = refAllele;
         this.altAllele = altAllele;
         this.type = type;//seems to be only "SNP" so far
      }

      @Override
      public String toString() {
         return chr + " " + start + " " + end + " " + refAllele + " " + altAllele + " " + type;
      }

      public String getAltAllele() {
         return altAllele;
      }

      public String getChr() {
         return chr;
      }

      public Integer getEnd() {
         return end;
      }

      public String getRefAllele() {
         return refAllele;
      }

      public Integer getStart() {
         return start;
      }

      public String getType() {
         return type;
      }
   }

