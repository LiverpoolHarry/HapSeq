/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package buildrefhapinput;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.TreeMap;

/**
 *
 * @author harry
 */
public class ProcessFiles {

   private int currIndex = 0;
   private int refIndex = 0;
   private TreeMap<Integer, Scaffold> scaffs;
   private TreeMap<Integer, Scaffold> allCells;
   private File logfile;
   private int libraryCount = 0;
   private boolean logging = false;
   private Params p;
   private int minStart = 10000000;//min and max scaffold positions in scaffolds
   private int maxEnd = 0;
   private ArrayList<OverlappingScaffolds> OverlapList;
   private ArrayList<String> libraries;
   private TreeMap<Integer, Scaffold> libraryScaffolds;
   private ArrayList<Chromosome> rawScaffolds;

   public ProcessFiles(File file, Params p) {
      this.logfile = file;
      this.p = p;
   }

   public TreeMap<Integer, Scaffold> processFiles(File[] files, ArrayList<String> exceptions) {
      this.logfile = new File("ScaffoldAnalysisLog.txt");
      libraryCount = 0;
      logfile.delete();
      //combined = new TreeMap<Integer, Scaffold>();
      allCells = new TreeMap<Integer, Scaffold>();
      OverlapList = new ArrayList<OverlappingScaffolds>();
      libraries = new ArrayList<String>();
      rawScaffolds = new ArrayList<Chromosome>();
      int count = 0;
      exceptionCheck:
      for (File file : files) {

         if (file != null) {
            String name = file.getName();
            Boolean flag = true;
            for (String except : exceptions) {
               if (name.startsWith(except)) {
                  flag = false;
                  break;

               }
            }
            if (flag) {
               libraryCount++;
               //scaffs is a list of scaffolds for a given library and chromosome
               TreeMap<Integer, Scaffold> temp = p.readFile(file);

               scaffs = (TreeMap<Integer, Scaffold>) temp.clone();
               checkMinStartMaxEnd();
               if (scaffs.size() > 0) {
                  Chromosome thisChr = new Chromosome(file, (TreeMap<Integer, Scaffold>) p.readFile(file));//scaffs.clone());

                  rawScaffolds.add(count, thisChr); //new Chromosome(file, (TreeMap<Integer, Scaffold>) scaffs.clone()));
                  p.addPrimaryChros(file, new Chromosome(file, scaffs));
               }
               else {
                  continue exceptionCheck;
               }

               count++;
               if (count == 1) {
                  allCells = (TreeMap<Integer, Scaffold>) scaffs.clone();
                  writeLog("New merge: " + file.getName().toString());
               }
               else {
                  writeLog("Adding: " + file.getName().toString());
                  refIndex = allCells.firstKey();
                  currIndex = scaffs.firstKey();
                  while (lastIndex()) {
                     //starting conditions
                     Scaffold below = getBelow();

                     while (scaffoldsOverlap(below, scaffs.get(currIndex), file)) {
                        testCurrentScaffold(below, scaffs.get(currIndex));
                        below = getBelow();
                     }
                     Scaffold above = getAbove();
                     if (above == null) {
                        break;
                     }
                     if (scaffoldsOverlap(above, scaffs.get(currIndex), file)) {
                        testCurrentScaffold(above, scaffs.get(currIndex));
                     }

                     while (scaffoldsDoNotOverlap(above, below, scaffs.get(currIndex))) {

                        allCells.put(scaffs.get(currIndex).getStart(), scaffs.get(currIndex));
                        writeLog("E\t" + scaffs.get(currIndex).getInterval());
                        currIndex = scaffs.higherKey(currIndex);
                        below = getBelow();
                        above = getAbove();
                        if (above == null) {
                           break;
                        }
                     }
                  }
               }
            }
         }
      }
      if (rawScaffolds.size() > 0) {
         p.setOverlapList(OverlapList);
         p.setRawScaffolds(rawScaffolds);

      }
      p.setMaxEnd(maxEnd);
      p.setMinStart(minStart);

      return allCells;
   }

   private Scaffold getAbove() {
      Scaffold above = allCells.get(refIndex);
      if (lastIndex()) {
         if (allCells.containsKey(scaffs.get(currIndex).getStart())) {
            above = allCells.get(scaffs.get(currIndex).getStart());
         }
         else if (allCells.higherKey(scaffs.get(currIndex).getStart()) != null) {
            above = allCells.get(allCells.higherKey(scaffs.get(currIndex).getStart()));
         }
         else {
            above = null;
         }
      }
      return above;
   }

   private Scaffold getBelow() {
      Scaffold below = allCells.get(allCells.firstKey());
      if (allCells.lowerKey(scaffs.get(currIndex).getStart()) != null) {
         if (allCells.containsKey(scaffs.get(currIndex).getStart())) {
            below = allCells.get(scaffs.get(currIndex).getStart());
         }
         else {
            below = allCells.get(allCells.lowerKey(scaffs.get(currIndex).getStart()));
         }
      }
      return below;
   }

   private boolean scaffoldsDoNotOverlap(Scaffold refAbove, Scaffold refBelow, Scaffold curr) {
      boolean overlap = false;
      if (lastIndex()) {
         if (curr.getStart() > refBelow.getEnd() &&
               curr.getEnd() < refAbove.getStart()) {
            overlap = true;
         }
         //this occurs when first scaffold of current is smaller than anything in ref
         else if (curr.getEnd() < refBelow.getStart()) {
            overlap = true;
         }
      }

      return overlap;

   }

   private boolean scaffoldsOverlap(Scaffold ref, Scaffold curr, File file) {
      boolean overlap = false;
      if (lastIndex()) {

         //current start within ref
         if (curr.getStart() >= ref.getStart() && curr.getStart() <= ref.getEnd()) {
            overlap = true;
         }
         //current end within ref
         else if (curr.getEnd() >= ref.getStart() && curr.getEnd() <= ref.getEnd()) {
            overlap = true;
         }
         //ref start within current
         else if (ref.getStart() >= curr.getStart() && ref.getStart() <= curr.getEnd()) {
            overlap = true;
         }
         //ref end within current
         else if (ref.getEnd() >= curr.getStart() && ref.getEnd() <= curr.getEnd()) {
            overlap = true;
         }
      }
      if (overlap) {
         ref.addSourceFile(file, ref.getStart());
      }
      if (overlap) {
         int minEnd = Math.min(curr.getEnd(), ref.getEnd());
         int maxStart = Math.max(curr.getStart(), ref.getStart());
         int overlapLength = minEnd - maxStart;
         if (overlapLength > 0) {
            Integer overlapStart = Math.max(ref.getStart(), curr.getStart());
            try {
               OverlapList.add(new OverlappingScaffolds(ref.getChr(), overlapStart, overlapLength, curr.clone(), ref.clone()));
            }
            catch (CloneNotSupportedException cnse) {
               System.out.println("Cloning not supported ProcessFiles.scaffoldsOverlap; " + cnse.getMessage());

            }
         }
      }

      return overlap;
   }

   private void testCurrentScaffold(Scaffold ref, Scaffold curr) {
      String cell = curr.getName();
      String subcell = curr.getSubcell();
      if (cell.contains(".")) {
         cell = cell.substring(0, cell.indexOf("."));
      }
      if (subcell.contains("-")) {
         subcell = subcell.substring(subcell.indexOf("-") + 1);
      }
      writeLog("REF\t" + ref.getInterval() + " cell: " + ref.getCell() + " subcell: " + ref.getSubcell());
      writeLog("Curr\t" + curr.getInterval() + " cell: " + cell + " subcell: " + subcell);
      if (curr.getStart() <= ref.getStart() &&
            curr.getEnd() >= ref.getStart() &&
            curr.getEnd() <= ref.getEnd()) {

         //new Scaffold for region up to start of reference
         if (ref.getStart() > curr.getStart()) {
            Scaffold temp = new Scaffold(ref.getChr(), curr.getStart(), ref.getStart() - 1, 1, cell, subcell);
            allCells.put(curr.getStart(), temp);
            writeLog("A1\t" + temp.getInterval());
         }

         //new scaffold for region of reference after curr
         if (ref.getEnd() > curr.getEnd()) {
            Scaffold temp = new Scaffold(ref.getChr(), curr.getEnd() + 1, ref.getEnd(), ref.getCoverage(), cell, subcell);
            allCells.put(curr.getEnd() + 1, temp);
            writeLog("A2\t" + temp.getInterval());
         }

         // reduce ref size to region covered by curr
         if (ref.getStart() >= curr.getStart()) {
            ref.setEnd(curr.getEnd());

         }
         ref.incrementCoverage();
         writeLog("A3\t" + ref.getInterval());
         currIndex = scaffs.higherKey(currIndex);
      }
      //current overlaps end of reference
      else if (curr.getStart() <= ref.getEnd() &&
            curr.getEnd() >= ref.getEnd() &&
            curr.getStart() >= ref.getStart()) {

         //new Scaffold for region of ref overlapping current
         if (curr.getStart() > ref.getStart()) {
            Scaffold temp = new Scaffold(ref.getChr(), curr.getStart(), ref.getEnd(), ref.getCoverage() + 1, cell, subcell);
            allCells.put(curr.getStart(), temp);
            writeLog("B1\t" + temp.getInterval());
         }
         else if (curr.getStart() == ref.getStart()) {
            ref.incrementCoverage();
            writeLog("B1a\t" + ref.getInterval());
         }

         //new curr Scaffold for region beyond end of reference
         if (curr.getEnd() > ref.getEnd()) {
            Scaffold temp = new Scaffold(ref.getChr(), ref.getEnd() + 1, curr.getEnd(), 1, cell, subcell);
            scaffs.put(ref.getEnd() + 1, temp);
            writeLog("B2 scaffs\t" + temp.getInterval());
         }

         //truncate existing ref
         if (curr.getStart() > ref.getStart()) {
            ref.setEnd(curr.getStart() - 1);
            writeLog("B3\t" + ref.getInterval());
         }


         //increment curr index
         currIndex = scaffs.higherKey(currIndex);
      }
      //current spans reference
      else if (curr.getStart() <= ref.getStart() &&
            curr.getEnd() >= ref.getEnd()) {

         //new Scaffold for region up to start of reference
         if (ref.getStart() > curr.getStart()) {
            Scaffold temp = new Scaffold(ref.getChr(), curr.getStart(), ref.getStart() - 1, 1, cell, subcell);
            allCells.put(curr.getStart(), temp);
            writeLog("C1\t" + temp.getInterval());
         }

         // increment coverage of ref
         ref.incrementCoverage();
         writeLog("C2\t" + ref.getInterval());

         //new curr Scaffold for region beyond end of reference
         Scaffold temp = new Scaffold(ref.getChr(), ref.getEnd() + 1, curr.getEnd(), 1, cell, subcell);
         scaffs.put(ref.getEnd() + 1, temp);
         writeLog("C3 scaffs\t" + temp.getInterval());

         //increment curr index
         currIndex = scaffs.higherKey(currIndex);
      }
      //reference spans current
      else if (curr.getStart() >= ref.getStart() &&
            curr.getEnd() <= ref.getEnd()) {
         //new Scaffold for region spanned by current
         Integer refCov = ref.getCoverage();
         Scaffold temp = new Scaffold(ref.getChr(), curr.getStart(), curr.getEnd(), refCov + 1, cell, subcell);
         allCells.put(curr.getStart(), temp);
         writeLog("D1\t" + temp.getInterval());

         //new Scaffold for region of reference beyond current
         temp = new Scaffold(ref.getChr(), curr.getEnd() + 1, ref.getEnd(), refCov, cell, subcell);
         allCells.put(curr.getEnd() + 1, temp);
         writeLog("D2\t" + temp.getInterval());

         //truncate current
         ref.setEnd(curr.getStart() - 1);
         writeLog("D3\t" + ref.getInterval());

         //increment curr index
         currIndex = scaffs.higherKey(currIndex);

      }
   }

   private void checkMinStartMaxEnd() {
      for (Integer i : scaffs.keySet()) {
         if (i < minStart) {
            minStart = i;
         }
         if (scaffs.get(i).getEnd() > maxEnd) {
            maxEnd = scaffs.get(i).getEnd();
         }
      }

   }

   private boolean lastIndex() {
      boolean lastIndex = false;
      if (currIndex < scaffs.lastKey() && refIndex < allCells.lastKey()) {
         lastIndex = true;
      }

      return lastIndex;
   }

   private void writeLog(String outString) {
      if (logging) {
         BufferedWriter out = getOutputFile();
         try {
            out.write(outString);
            out.newLine();
            out.flush();
            out.close();
         }
         catch (IOException ex) {
            ex.printStackTrace();
         }
      }

   }

   private BufferedWriter getOutputFile() {
      BufferedWriter analysisFile = null;
      try {
         FileWriter fstream = new FileWriter(logfile.getAbsoluteFile(), true);
         analysisFile = new BufferedWriter(fstream);
      }
      catch (IOException e) {
         System.out.println("IOException : " + e);
      }
      return analysisFile;
   }

   public int getLibraryCount() {
      return libraryCount;
   }
}

