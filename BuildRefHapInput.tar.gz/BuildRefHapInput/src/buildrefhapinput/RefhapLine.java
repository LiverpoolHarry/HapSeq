/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package buildrefhapinput;

/**
 *
 * @author harry
 */
  public class RefhapLine implements Comparable {

      private Integer pos;
      private String line;

      public RefhapLine(Integer pos, String line) {
         this.pos = pos;
         this.line = line;
      }

      public String getLine() {
         return line;
      }

      public Integer getPos() {
         return pos;
      }

      public int compareTo(Object anotherLine) throws ClassCastException {
         if (!(anotherLine instanceof RefhapLine)) {
            throw new ClassCastException("A RefhapLine object expected.");
         }
         int anotherPos = ((RefhapLine) anotherLine).getPos();
         return this.pos - anotherPos;
      }
   }
