/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package validatehaplotypes;

//import mysql.mysql;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/**
 *
 * @author harry
 */

public class Main {
private static HashMap<String, String> comLineVars;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Date startTime = new Date();

      getArgs(args);
      System.out.println("Finished " + comLineVars.get("chr") + " at " + getDateTime());
      Date finishTime = new Date();
      Long elapsedTimeMin = ((finishTime.getTime() - startTime.getTime()) / 60000);
      Long elapsedTimeSec = ((finishTime.getTime() - startTime.getTime()) / 1000) % 60;
      System.out.println("Finished run at " + getDateTime());
      System.out.println("Elapsed time = " + elapsedTimeMin + "m:" + elapsedTimeSec + "s");
      //beep to indicate end of programme
      System.out.println((char) 7);
      System.out.println((char) 7);
      System.out.println((char) 7);
      System.out.println((char) 7);

    }
    private static void getArgs(String[] args) {
      String vars = "chrvcfFilefileListbeagleFileilluminaHdFile012filematchLengthx";
      comLineVars = new HashMap<String, String>();
      String path = System.getProperty("user.dir");

      ArrayList<String> excludedSamples = new ArrayList<String>();
      if (args.length > 0) {
         for (String var : args) {
            if (var.contains(">") || !var.contains("=")) {//so that output redirection can be put in command line
               break;
            }
            String[] arg = var.split("=");
            if (arg[0].contentEquals("exclude")) {
               excludedSamples.add(arg[1]);
            }
            else if (vars.contains(arg[0])) {
               comLineVars.put(arg[0], arg[1]);
            }
            else {
               printhelp("Argument " + arg[0] + " is not a valid parameter");
            }

         }
         System.out.println("Path " + path);
      }
      else {
         printhelp("No arguments supplied.");
      }

      if (checkRequiredArgs()) {
         System.out.println("Starting RunAnalysis");
         RunAnalysis ra = new RunAnalysis(comLineVars);
    
      }
      else {
         printhelp("");
      }


      //return checkRequiredArgs();
   }

   private static boolean checkRequiredArgs() {
      HashSet<String> requiredArgs = new HashSet<String>();
      requiredArgs.add("chr");
      requiredArgs.add("fileList");
      requiredArgs.add("vcfFile");
       for (String arg : comLineVars.keySet()) {
         if (requiredArgs.contains(arg)) {
            requiredArgs.remove(arg);
         }
         if(arg.contentEquals("beagleFile")){
            if(!comLineVars.containsKey("illuminaHdFile")){
               printhelp("Fatal Error: If a beagle file is specified the corresponding Illumina HD file must also be specified to enable mapping onto sequence data");
            }
         }
      }
      if (requiredArgs.isEmpty()) {
         return true;
      }
      else {
         Iterator it = requiredArgs.iterator();
         while (it.hasNext()) {
            System.out.println("Required argument " + it.next() + " is missing");
         }
         return false;
      }

   }

   private static String getDateTime() {
      DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss z");
      Date date = new Date();
      return dateFormat.format(date);
   }

   private static void printhelp(String message) {
      if (!message.isEmpty()) {
         System.out.println(message);
      }

      System.out.println("To run the programme: \n java -Xmn4g -jar path/BuildRefHapInput.jar <options>");
      System.out.println("Options should be entered as key value pairs seperated by = and no spaces");
      System.out.println("Eg: java -Xmn4g -jar path/CountScaffoldCoverage.jar chr=Chr5 vcfFile=path/to/file/ fileList=path/to/file\n");

      HashMap<String, String> help = new HashMap<String, String>();
      help.put("chr:            ", "Required; chromosome number in format used in vcf file eg chr=Chr5");
      help.put("fileList:       ", "Required; text file containing list of gff3 files to be processed, one per line.");
      help.put("012file:        ", "Optional; if present this file will be used instead of generating one from vcf file. an 012.pos file must also be present with the same filename but a .pos extension. Vcf file is still required to obtain AGCT alleles.");
      help.put("vcfFile:        ", "Required; tab seperated vcf file corresponding to gff3 file. vcfpath=/path/to/file/ChrX.vcf.gz");
      help.put("beagleFile:     ", "Optional; tab seperated text file containing beagle genotypes with columns SNP_ID	Chr POSITION GENOTYPE (1,2,3,4). beagleFile=/path/to/file");
      help.put("illuminaHdFile: ", "Optional; comma seperated text file containing ACGT genotypes from HDchip with columns snp_number,snp50_snp_number,marker_name,ilmn_strand,snp_bs,allele_a,allele_b,rs_id. illuminaHdFile=/path/to/file");
      help.put("matchLength:    ", "Optional; default 2, minumum 2, number of bases in haplotypes used to calculate consistency between HD chip alleles and Sequence alleles. With default 2, pairs are compared. matchLength=4 ");

      String vars = "chrvcfFilefileListbeagleFileilluminaHdFile012filematchLength";
      for (String param : help.keySet()) {
         System.out.println("    " + param + "\t\t" + help.get(param));
      }

      System.exit(-1);

   }
}


