/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package validatehaplotypes;

public class RefAndAltAlleles {

   String chr;
   Integer start;
   Integer end;
   String refAllele;
   String altAllele;
   String strand;
   private Short uncorrectedBeagleGenotype;
   private Short correctedBeagleGenotype;
   private final Short mOne = -1;

   public RefAndAltAlleles(String chr, Integer start, Integer end, String refAllele, String altAllele, String strand, Short bg) {
      this.chr = chr;
      this.start = start;
      this.end = end;
      this.refAllele = refAllele;
      this.altAllele = altAllele;
      this.strand = strand;//TOP / BOT
      this.uncorrectedBeagleGenotype = bg;
   }

   @Override
   public String toString() {
      return chr + " " + start + " "  + refAllele + " " + altAllele + " " + strand + " " + uncorrectedBeagleGenotype + " " + getCorrectedBeagleGenotype();
   }

   public String getAltAllele() {
      return altAllele;
   }

   public String getChr() {
      return chr;
   }

   public Integer getEnd() {
      return end;
   }

   public String getRefAllele() {
      return refAllele;
   }

   public Integer getStart() {
      return start;
   }

   public String getStrand() {
      return strand;
   }

   public Short getUncorrectedBeagleGenotype() {
      if (uncorrectedBeagleGenotype != null) {
         return uncorrectedBeagleGenotype;
      }
      else {
         return mOne;
      }
   }

   public Short getCorrectedBeagleGenotype() {
      if (correctedBeagleGenotype != null) {
         return correctedBeagleGenotype;
      }
      else {
         return uncorrectedBeagleGenotype;
      }
   }

   public void setCorrectedBeagleGenotype(Short correctedBeagleGenotype) {
      this.correctedBeagleGenotype = correctedBeagleGenotype;
   }

   public boolean equals(RefAndAltAlleles other) {
      boolean result = false;
      if (other.refAllele.contentEquals(refAllele) && other.altAllele.contentEquals(altAllele)) {
         result = true;
      }

      return result;
   }
}

