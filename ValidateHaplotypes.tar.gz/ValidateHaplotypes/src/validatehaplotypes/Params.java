/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package validatehaplotypes;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

/**
 *
 * @author harry
 */
public class Params {

   private String chr;
   private String gff3path = "";
   private String vcfFile;
   private String beagleFile;
   private String input012file = null; //if present this file will be used instead of generating one from vcf file
   private String illuminaHdFile;
   private String positionsFile;
   private String fileList;
   private boolean beagleComparison = true;
   private Short matchLength = 2;
   private HashMap<String, Short> shortAlleles;
   public static final Short mOne = -1;
   public static final Short zero = 0;
   public static final Short one = 1;
   public static final Short two = 2;
   public static final Short three = 3;
   public static final Short four = 4;
   //private String file012;
   private ArrayList<String> sampleNames;
   private ArrayList<Integer> allelePositions;
   private TreeMap<Integer, Short> beagleAlleles;
   private TreeMap<Integer, RefAndAltAlleles> hdRefAndAltAlleles;//key position; refAndAlt Alleles from IlluminaHdFile
   private final String vcftools = "/pub7/harry/gatk/vcftools_0.1.7/bin/";

   public Params(HashMap<String, String> comLineVars) {
      if (comLineVars.containsKey("gff3path")) {
         this.gff3path = comLineVars.get("gff3path");
         if (!gff3path.endsWith("/")) {
            gff3path = gff3path + "/";
         }
      }
      if (comLineVars.containsKey("matchLength")) {
         matchLength = Short.parseShort(comLineVars.get("matchLength"));
         if (matchLength < 2) {
            matchLength = 2;
         }
      }
      fileList = comLineVars.get("fileList");
      vcfFile = comLineVars.get("vcfFile");
      if (comLineVars.containsKey("beagleFile")) {
         beagleFile = comLineVars.get("beagleFile");
         illuminaHdFile = comLineVars.get("illuminaHdFile");
      }
      else {
         beagleComparison = false;
      }

      chr = comLineVars.get("chr");
      positionsFile = chr + ".beaglePositions.txt";
      sampleNames = new ArrayList<String>();
      //vcfFilePath = (comLineVars.get("vcfpath").substring(0, -9));
      if (comLineVars.containsKey("012file")) {
         input012file = comLineVars.get("012file");
      }
      else {
         input012file = chr + "012";
         get012file();
      }


      shortAlleles = new HashMap<String, Short>(6);
      shortAlleles.put("-1", mOne);
      shortAlleles.put("0", zero);
      shortAlleles.put("1", one);
      shortAlleles.put("2", two);
      shortAlleles.put("3", three);
      shortAlleles.put("4", four);
   }

   public String getChr() {
      return chr;
   }

   public String getGff3path() {
      return gff3path;
   }

   public String getVcfFile() {
      return vcfFile;
   }

   public String getFileList() {
      return fileList;
   }

   public String getPositionsFile() {
      return positionsFile;
   }

    public String getVcftools() {
      return vcftools;
   }

   public boolean isBeagleComparison() {
      return beagleComparison;
   }

   public HashMap<String, Short> getShortAlleles() {
      return shortAlleles;
   }

   public ArrayList<String> getSampleNames() {
      return sampleNames;
   }

   public TreeMap<Integer, RefAndAltAlleles> getHdRefAndAltAlleles() {
      return hdRefAndAltAlleles;
   }

   public String getInput012file() {
      return input012file;
   }

   public Short getMatchLength() {
      return matchLength;
   }

   //build treemap of alleles keyed by position for each subcell
   protected ArrayList<Integer> getAllelePositions() {
      allelePositions = new ArrayList<Integer>();
      String path = System.getProperty("user.dir");
      File file = new File(input012file + ".012.pos");
      //Build array of allele positions
      allelePositions.clear();

      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;
         while ((strLine = br.readLine()) != null) {
            String[] posit = strLine.split("\t");
            allelePositions.add(Integer.parseInt(posit[1]));
         }
         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
      }


      System.out.println("Got " + allelePositions.size() + " snp positions from " + input012file + ".012.pos");
      return allelePositions;
   }

   private void get012file() {
     String command = vcftools + "vcftools --gzvcf " + vcfFile + " --positions " + positionsFile + " --out " + input012file + " --012";
      runVcfTools(command);
    }

   public void runVcfTools(String command) {
      try {
         long startTime = System.currentTimeMillis();
         final Process process = Runtime.getRuntime().exec(command);
         int returnCode = process.waitFor();
         long endTime = System.currentTimeMillis();
         long elapsedTime = (System.currentTimeMillis() - startTime) / 1000;
         System.out.println(command + " ; Return code " + returnCode + "; Elapsed Time " + elapsedTime + " secs");
      }
      catch (Exception e) {
         e.printStackTrace();
      }

   }

   protected HashMap<String, TreeMap<Integer, Short>> getAlleles(HashMap<String, TreeMap<Integer, Short>> chroAllelePos, String filename) {
      String path = System.getProperty("user.dir");
      File file = new File(filename);
      System.out.println("Getting alleles from " + filename);
      //Build array of allele positions
      int lineCount = 0;
      int allCount = 0;


      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;
         while ((strLine = br.readLine()) != null) {
            lineCount++;
            String[] alleles = strLine.split(";");
            TreeMap<Integer, Short> posAlleles = new TreeMap<Integer, Short>();
            String lib = alleles[0];
            // sampleNames.add(lib);
            for (int d = 1; d < alleles.length; d++) {

               if (!alleles[d].contentEquals("-1")) {
                  posAlleles.put(allelePositions.get(d), shortAlleles.get(alleles[d]));
               }
            }
            chroAllelePos.put(lib, posAlleles);
         }

         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
         System.exit(-1);
      }
      System.out.println("Lines in 012 file" + lineCount + " Allele Count = " + allCount);

      return chroAllelePos;
   }

   protected HashMap<String, TreeMap<Integer, Short>> getAllelesFrom012Input(HashMap<String, TreeMap<Integer, Short>> chroAllelePos) {
      String path = System.getProperty("user.dir");

      File file = new File(input012file + ".012");
      //Build array of allele positions
      int lineCount = 0;

      System.out.println("Getting alleles from " + input012file);
      int allCount = 0;
      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;

         while ((strLine = br.readLine()) != null) {
            lineCount++;
            String[] alleles = strLine.split("\t");
            TreeMap<Integer, Short> posAlleles = new TreeMap<Integer, Short>();
            String lib = sampleNames.get(Integer.parseInt(alleles[0]));
  
            for (int d = 1; d < alleles.length; d++) {
               allCount++;
               if (!alleles[d].contentEquals("-1")) {
                  posAlleles.put(allelePositions.get(d - 1), shortAlleles.get(alleles[d]));
               }
            }
            chroAllelePos.put(lib, posAlleles);
         }

         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         e.printStackTrace();
      }
      allCount = allCount / lineCount;
      System.out.println("Lines in 012 file: " + lineCount + "; Allele Count = " + allCount);

      return chroAllelePos;

   }

   protected void getSampleNamesFrom012() {

      String path = System.getProperty("user.dir");
      File file = new File(input012file + ".012.indv");


      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));

         String strLine;
         while ((strLine = br.readLine()) != null) {

            String[] lib = strLine.split(";");
            sampleNames.add(lib[0]);

         }
         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
      }
   }

   public TreeMap<Integer, Integer> readFile(File file) {

      TreeMap<Integer, Integer> scaffolds = new TreeMap<Integer, Integer>();
      try {
         // Open the file that is the first
         // command line parameter
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));
         String strLine;
         //Read File Line By Line
         while ((strLine = br.readLine()) != null) {
            String[] data = strLine.split("\t");
            scaffolds.put(Integer.parseInt(data[3]), Integer.parseInt(data[4]));
         }
         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("Error in params.readFile(): " + e.getMessage());
         e.printStackTrace();
      }
      return scaffolds;
   }

   public void deleteFile(String filename) {
      try {
         File file = new File(filename);
         if (file.delete()) {
            System.out.println(file.getName() + " is deleted!");
         }
         else {
            System.out.println("Delete of " + filename + " failed.");
         }
      }
      catch (Exception e) {
         e.printStackTrace();
      }
   }

   public TreeMap<Integer, Short> readBeagleFile() {
      beagleAlleles = new TreeMap<Integer, Short>();// Position, RefAndAltAlleles
      TreeMap<Integer, Integer> beaglePositions = new TreeMap<Integer, Integer>();//snp_id, position
      int lineCount = 0;
      String chrDigit = chr.substring(3);
      System.out.println("Getting beagle data for BTA" + chrDigit);
      File file = new File(beagleFile);
      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream:

         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));
         String strLine;
         String[] data;
         while ((strLine = br.readLine()) != null) {
            lineCount++;
            data = strLine.split("\t");
            if (lineCount == 1 || !data[1].contentEquals(chrDigit)) {
               continue;
            }

            Integer position = Integer.parseInt(data[2]);
            beagleAlleles.put(position, shortAlleles.get(data[3]));
            beaglePositions.put(Integer.parseInt(data[0]), position);

         }
         in.close();
      }
      catch (Exception e) {
         System.err.println("File Open Error: " + e.getMessage());
         System.out.println("Failed to open Filename:" + file.getAbsolutePath().toString());
         e.printStackTrace();
      }
      readIlluminaHdFile(beaglePositions);
      return beagleAlleles;
   }

   //Read Beagle genotypes first, then for each Illumina HD SNP check if SNP_ID is in beagle genotypes set;
   //if true then use position from beagle file to set co-ordinate of HD alleles
   public void readIlluminaHdFile(TreeMap<Integer, Integer> beaglePositions) {
      hdRefAndAltAlleles = new TreeMap<Integer, RefAndAltAlleles>();// Position, RefAndAltAlleles

      int matchesCount = 0;

      try {
         FileInputStream fstream = new FileInputStream(illuminaHdFile);
         // Get the object of DataInputStream:

         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));
         String strLine;
         String[] data;
         while ((strLine = br.readLine()) != null) {
            if (strLine.startsWith("snp_number")) {
               //headerCount++;
               continue;
            }
            data = strLine.split(",");
            // System.out.println("Length of data: " + data.length + "; Length of line = " + strLine.length());
            Integer snp_id = Integer.parseInt(data[0]);
            if (beaglePositions.containsKey(snp_id)) {
               // System.out.println("Data[0] " + data[0] + "; Position " + position);
               Integer position = beaglePositions.get(snp_id);
               RefAndAltAlleles raa = new RefAndAltAlleles(chr, position, position, data[5], data[6], data[3], beagleAlleles.get(position).shortValue());
               hdRefAndAltAlleles.put(position, raa);
               matchesCount++;
            }
         }
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("File Open Error: " + e.getMessage());
         System.out.println("Failed to open Filename:" + illuminaHdFile);
         e.printStackTrace();
      }
      System.out.println(matchesCount + " entries in " + illuminaHdFile + " matched entries in " + beagleFile);
   }

   public TreeMap<Integer, RefAndAltAlleles> readVCFFile(File file) {
      TreeMap<Integer, RefAndAltAlleles> allRefAndAltAlleles = new TreeMap<Integer, RefAndAltAlleles>();// Position, RefAndAltAlleles

      int lineCount = 0;
      int headerCount = 0;

      try {
         FileInputStream fstream = new FileInputStream(file);
         // Get the object of DataInputStream:

         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));
         String strLine;
         String[] data;
         while ((strLine = br.readLine()) != null) {
            if (!strLine.startsWith(chr)) {
               headerCount++;
               continue;
            }
            data = strLine.split("\t");
            Integer position = Integer.parseInt(data[1]);

            RefAndAltAlleles raa = new RefAndAltAlleles(data[0], position, position, data[3], data[4], "SNP", null);
            allRefAndAltAlleles.put(position, raa);
         }
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.out.println("Caught error at Params line 415 after processing " + lineCount + " lines and " + headerCount + " header lines from " + file.getAbsolutePath());
         e.printStackTrace();
      }
      return allRefAndAltAlleles;
   }

   public void delete012files() {
      String file012 = input012file;
      deleteFile(file012 + ".012");
      deleteFile(file012 + ".012.pos");
      deleteFile(file012 + ".012.indv");
      deleteFile(file012 + "vcf.log");
   }
}
