/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package validatehaplotypes;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
//import mysql.mysql;

/**
 *
 * @author harry
 */
public class RunAnalysis {

   private String chr;
   private Params p;
   private GetFiles fileLister;
   private ArrayList<Integer> allelePositions;
   private HashMap<String, TreeMap<Integer, Short>> chroAllelePos;//key library;  treemap position allele
   private HashMap<String, String> comLineVars;
   public static final Short mOne = -1;
   public static final Short zero = 0;
   public static final Short one = 1;
   public static final Short two = 2;
   public static final Short three = 3;
   public static final Short four = 4;
   private String hapsFile;
   private int totalMatchingPairs = 0;
   private int totalPairs = 0;
   private final DecimalFormat floatFormat = new DecimalFormat("###,###.###");
   private HashMap<String, Short> shortAlleles;
   private TreeMap<Integer, Short> beagleAlleles;
   private HashMap<Short, Short> beagleRefCodes;//used to translate beagle 1,2,3,4 to 012 0,2
   private HashMap<Short, Short> beagleAltCodes;//used to translate beagle 1,2,3,4 to 012 0,2
   private TreeMap<Integer, RefAndAltAlleles> seqRefAndAltAlleles;//ref and alt alleles from sequencing vcf file
   private TreeMap<Integer, BadPosition> badPos;//position, BadPosition
   private TreeMap<Integer, RefAndAltAlleles> hdRefAndAltAlleles;
   private TreeMap<Integer, String> haplotypes;
   private Double switchDist = 0.0;
   private int switchCount = 0;
   private int hapCount = 0;
   private int hapLength = 0;
   private int terminalErrors = 0;
   private TreeMap<Integer, ArrayList<Integer>> hapPositions;//key first position in haplotype , list of all positions in haplotype

   public RunAnalysis(HashMap<String, String> comLineVars) {
      this.chr = comLineVars.get("chr");
      this.comLineVars = comLineVars;
      p = new Params(comLineVars);
      //beagle codes are assumed to be 1=ref/ref, 2 = alt/alt; 3 = ref/alt; 4 = alt/ref

      beagleRefCodes = new HashMap<Short, Short>();
      beagleRefCodes.put(one, zero);
      beagleRefCodes.put(two, two);
      beagleRefCodes.put(three, zero);
      beagleRefCodes.put(four, two);

      beagleAltCodes = new HashMap<Short, Short>();
      beagleAltCodes.put(one, zero);
      beagleAltCodes.put(two, two);
      beagleAltCodes.put(three, two);
      beagleAltCodes.put(four, zero);

      shortAlleles = p.getShortAlleles();


      hapsFile = chr + ".haps.txt";
      badPos = new TreeMap<Integer, BadPosition>();
      haplotypes = new TreeMap<Integer, String>();
      hapPositions = new TreeMap<Integer, ArrayList<Integer>>();

      p.deleteFile(hapsFile);
      validateScaffs();
   }

   private void validateScaffs() {
      //Get list of all gff3 files
      fileLister = new GetFiles(p);
      File[] gff3files = fileLister.readFile();

      String positionsFile = p.getPositionsFile();
      p.deleteFile(positionsFile);
      writeVcfPosition(positionsFile);//write a list of positions in beagle file to use to filter vcf output

      //get alleles for all libraries in 012 format
      String file012 = chr;
      chroAllelePos = new HashMap<String, TreeMap<Integer, Short>>(); //Library <Position, Allele>
      p.getSampleNamesFrom012();//Library names
      p.getAllelePositions();
      chroAllelePos = p.getAllelesFrom012Input(chroAllelePos);

      //Ref and alt alleles in ACGT format by position from vcf file
      getRefAndAltAlleles(positionsFile);
      if (p.isBeagleComparison()) {
         //beagle alleles in 1,2,3,4 format by position
         //Assumed interpretation 1=ref/ref, 2 = alt/alt; 3 = ref/alt; 4 = alt/ref
         beagleAlleles = p.readBeagleFile();//calls p.readIlluminaHdFile after reading Beagle alleles
         //Get Ref and alt alleles in ACGT format by position from HD chip file
         hdRefAndAltAlleles = p.getHdRefAndAltAlleles();
         //Compare vcf and HD chip alleles and change Beagle call if vcf and HD chip inconsistent
         convertBeagleAllelesToSeqAlleles();
      }


      //Iterate over each gff3 file to get scaffolds
      System.out.println("Scanning " + gff3files.length + " gff3 files. RunAnalysis.validateScaffs line 113 ");
      for (int i = 0; i < gff3files.length; i++) { //gff3files.length; i++) {
         String fName = gff3files[i].getName();
         String lib = fName.substring(0, fName.indexOf("_") + 2);
         TreeMap<Integer, Integer> scaffs = p.readFile(gff3files[i]);
         testScaffs(scaffs, lib);
      }

      compareBadPostions();
      Double frac = (1.0 * totalMatchingPairs) / totalPairs;
      int mismatches = totalPairs - totalMatchingPairs;
      System.out.println("Fraction of pairs of sequence SNP that match pairs of Beagle alleles = " + floatFormat.format(frac) + " out of " + totalPairs + " pairs of loci");
      frac = (switchDist) / switchCount;
      System.out.println("Switch error distance between pairs of beagle alleles and pairs of sequence alleles = " + floatFormat.format(frac) + " from " + totalPairs + " pairs of loci");
      System.out.println(terminalErrors + " out of " + mismatches + " mismatches were at the start or end of the " + hapCount + " haplotypes analysed with total length " + hapLength);
   }

   private void testScaffs(TreeMap<Integer, Integer> scaffs, String lib) {
      TreeMap<Integer, Short> alleles = chroAllelePos.get(lib);
      TreeMap<Integer, Short> seqAlls = new TreeMap<Integer, Short>();
      TreeMap<Integer, Short> hdAlls = new TreeMap<Integer, Short>();

      Integer firstBeaglePos = beagleAlleles.firstKey();
      Integer lastBeaglePos = beagleAlleles.lastKey();

      int countSNPpairs = 0;
      int countMatchingSNPpairs = 0;
      int oneLength = 0;
      int countScaffoldsWithNoSNP = 0;


      if (scaffs == null) {
         System.out.println("No useable scaffs for library " + lib);
         return;
      }

      if (alleles == null) {
         System.out.println("No useable alleles for library " + lib);
         return;
      }
      for (Integer i : scaffs.keySet()) {
         if (alleles.lastKey() < i || alleles.firstKey() > scaffs.get(i)) {
            continue;
         }
         int seqStart = alleles.ceilingKey(i);
         int seqEnd = alleles.floorKey(scaffs.get(i));
         int hdStart = 0;
         int hdEnd = 0;
         seqAlls.clear();
         hdAlls.clear();
         //get alleles for this library for this scaffold
         try {
            if (seqEnd > seqStart) {
               seqAlls = new TreeMap<Integer, Short>(alleles.subMap(seqStart, seqEnd));
            }
         }
         catch (NullPointerException npe) {
            countScaffoldsWithNoSNP++;
            continue;
         }

         //If this scaffold has at least two alleles then get alleles for this position from database
         if (seqAlls.size() > 1 && i >= firstBeaglePos && scaffs.get(i) <= lastBeaglePos) {
            hdStart = beagleAlleles.ceilingKey(i);
            hdEnd = beagleAlleles.floorKey(scaffs.get(i));
            //get hd alleles for this scaffold
            try {
               if (hdEnd > hdStart) {
                  hdAlls = new TreeMap<Integer, Short>(beagleAlleles.subMap(hdStart, hdEnd));
               }
            }
            catch (NullPointerException npe) {
               continue;
            }
         }
         else {
            continue;
         }
         Short ml = p.getMatchLength();
         if (hdAlls.size() > ml - 1) {
            String meta = "\nLibrary: " + lib + "; " + seqStart + "-" + seqEnd;
            StringBuilder seqHap = new StringBuilder();
            StringBuilder hdRefHap = new StringBuilder();
            StringBuilder hdAltHap = new StringBuilder();
            StringBuilder hdHap = new StringBuilder();
            StringBuilder hdHapUn = new StringBuilder();
            StringBuilder data = new StringBuilder();
            StringBuilder switchDistRef = new StringBuilder();
            StringBuilder switchDistAlt = new StringBuilder();

            ArrayList<Integer> positions = new ArrayList<Integer>();
            for (Integer pos : seqAlls.keySet()) {
               if (hdAlls.containsKey(pos)) {
                  seqHap.append(seqAlls.get(pos));
                  hdRefHap.append(beagleRefCodes.get(hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype().shortValue()));
                  hdAltHap.append(beagleAltCodes.get(hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype().shortValue()));
                  hdHap.append(hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype().shortValue());
                  hdHapUn.append(hdRefAndAltAlleles.get(pos).getUncorrectedBeagleGenotype().shortValue());
                  data.append(hdRefAndAltAlleles.get(pos).toString() + " " + seqRefAndAltAlleles.get(pos).getRefAllele() + " " + seqRefAndAltAlleles.get(pos).getAltAllele() + "\n");
                  positions.add(pos);
                  int refDist = Math.abs(seqAlls.get(pos) - beagleRefCodes.get(hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype()));
                  int altDist = Math.abs(seqAlls.get(pos) - beagleAltCodes.get(hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype()));
                  switchDistRef.append(refDist);
                  switchDistAlt.append(altDist);

               }
            }
            int minLength = 3;
            if (seqHap.length() > minLength) {
               HashMap<String, Double> refSwitch = getSwitchErrorDist(switchDistRef.toString());
               HashMap<String, Double> altSwitch = getSwitchErrorDist(switchDistAlt.toString());
               if (refSwitch.get("frac") >= altSwitch.get("frac")) {
                  switchDist += refSwitch.get("frac") * seqHap.length();
                  terminalErrors += refSwitch.get("terminalErrors");
               }
               else {
                  switchDist += altSwitch.get("frac") * seqHap.length();
                  terminalErrors += altSwitch.get("terminalErrors");
               }
               switchCount += seqHap.length();
            }
            //Calculate match for HDchip and sequence haplotypes
            if (seqHap.length() > minLength) {
               hapCount++;
               hapLength += seqHap.length();
               String sh = seqHap.toString();
               String hrh = hdRefHap.toString();
               String hah = hdAltHap.toString();
               if (!sh.contains("1")) {// skip loci with any hets
                  String log = (meta + "\n" + sh + "\n" + hrh + "\n" + hah + "\n" + hdHap.toString() + "\n" + hdHapUn.toString() + "\n" + data.toString());
                  haplotypes.put(positions.get(0), log);
                  hapPositions.put(positions.get(0), positions);
                  countSNPpairs += sh.length();
                  char[] sha = sh.toCharArray();
                  char[] hrha = hrh.toCharArray();
                  char[] haha = hah.toCharArray();
                  int refMatches = 0;
                  int altMatches = 0;
                  for (int j = 0; j < sha.length; j++) {
                     if (sha[j] == hrha[j]) {
                        refMatches++;
                        Integer pos = positions.get(j);
                        setBadPositions(pos, lib, sha, j, "Good");
                     }
                     else if (sha[j] == haha[j]) {
                        altMatches++;
                        Integer pos = positions.get(j);
                        setBadPositions(pos, lib, sha, j, "Good");
                     }
                     else {
                        String status = "Bad";
                        Integer pos = positions.get(j);
                        setBadPositions(pos, lib, sha, j, status);
                     }
                  }
                  countMatchingSNPpairs += Math.max(refMatches, altMatches);
               }
               else {
                  oneLength += sh.length();
               }
            }
         }
         else {
            continue;
         }
      }
      Double frac = (1.0 * countMatchingSNPpairs) / countSNPpairs;

      System.out.println("Lib   " + lib + ";\tProp matching SNP pairs = " + floatFormat.format(frac) + " out of " + countSNPpairs + " pairs of loci with " + oneLength + " pairs in haplotypes with at least one heterozygote");
      totalMatchingPairs += countMatchingSNPpairs;
      totalPairs += countSNPpairs;
   }

   private void setBadPositions(Integer pos, String lib, char[] sha, int j, String status) {
      if (badPos.containsKey(pos)) {
         badPos.get(pos).addLibrary(lib, shortAlleles.get(String.valueOf(sha[j])));
         if (status.contains("Bad")) {
            badPos.get(pos).setStatus(status);
         }
      }
      else {
         if (hdRefAndAltAlleles.containsKey(pos) && seqRefAndAltAlleles.containsKey(pos)) {
            badPos.put(pos, new BadPosition(status, pos, lib, shortAlleles.get(String.valueOf(sha[j])), hdRefAndAltAlleles.get(pos).getUncorrectedBeagleGenotype(), hdRefAndAltAlleles.get(pos).getCorrectedBeagleGenotype(), seqRefAndAltAlleles.get(pos).getRefAllele(), seqRefAndAltAlleles.get(pos).getAltAllele(), hdRefAndAltAlleles.get(pos).getRefAllele(), hdRefAndAltAlleles.get(pos).getAltAllele(), hdRefAndAltAlleles.get(pos).getStrand()));
         }
      }

   }

   private void compareBadPostions() {
      BufferedWriter out = getOutputFile(hapsFile);
      try {
         for (Integer pos1 : haplotypes.keySet()) {
            out.write(haplotypes.get(pos1));

            for (Integer pos : hapPositions.get(pos1)) {
               if (badPos.containsKey(pos)) {
                  out.write(badPos.get(pos).getOutputLine());
                  out.newLine();
               }
            }
         }
         out.flush();
         out.close();
      }
      catch (IOException ex) {
         ex.printStackTrace();
      }
   }

   //Illumina HDchip AB alleles seem to be randomly equal to the reference sequence alleles,
   //the complement of them or the reverse  of them or the reverse compelement of them.
   private void convertBeagleAllelesToSeqAlleles() {
      HashMap<Short, Short> rev = new HashMap<Short, Short>();
      rev.put(one, two);
      rev.put(two, one);
      rev.put(three, four);
      rev.put(four, three);
      HashMap<String, String> comp = new HashMap<String, String>();
      comp.put("A", "T");
      comp.put("C", "G");
      comp.put("G", "C");
      comp.put("T", "A");

      int countRemoved = 0;
      int totalPositions = beagleAlleles.size();
      int seqAllsCount = 0;
      int hdAllsCount = 0;
      int correctedAlleles = 0;
      Iterator it = beagleAlleles.keySet().iterator();
      while (it.hasNext()) {
         Integer beaglePos = (Integer) it.next();
         if (seqRefAndAltAlleles.containsKey(beaglePos)) {
            seqAllsCount++;
         }
         if (hdRefAndAltAlleles.containsKey(beaglePos)) {
            hdAllsCount++;
         }

         if (seqRefAndAltAlleles.containsKey(beaglePos) && hdRefAndAltAlleles.containsKey(beaglePos)) {
            RefAndAltAlleles seqAlls = seqRefAndAltAlleles.get(beaglePos);
            RefAndAltAlleles hdAlls = hdRefAndAltAlleles.get(beaglePos);
            String seqR = "";
            String seqA = "";
            String hdR = "";
            String hdA = "";

            if (!seqAlls.equals(hdAlls)) {
               seqR = seqAlls.getRefAllele();
               seqA = seqAlls.getAltAllele();
               hdR = hdAlls.getRefAllele();
               hdA = hdAlls.getAltAllele();

               if (seqR.contentEquals(hdA) && seqA.contentEquals(hdR) ||
                     seqR.contentEquals(comp.get(hdA)) && seqA.contentEquals(comp.get(hdR))) {
                  //beagleAlleles.put(beaglePos, rev.get(beagleAlleles.get(beaglePos)));
                  hdRefAndAltAlleles.get(beaglePos).setCorrectedBeagleGenotype(rev.get(hdRefAndAltAlleles.get(beaglePos).getUncorrectedBeagleGenotype()).shortValue());
                  //writeLog("Inside: " + hdRefAndAltAlleles.get(beaglePos).toString() + " " + seqR + " " + seqA + " " + hdR + " " + hdA);
                  correctedAlleles++;
               }
               else {
                  //These all seem to be loci where HD chip is complement but not reverse complement of VCF so Beagle genotype does not need modifying
                  hdRefAndAltAlleles.get(beaglePos).setCorrectedBeagleGenotype(beagleAlleles.get(beaglePos).shortValue());

               }
            }
            else {
               hdRefAndAltAlleles.get(beaglePos).setCorrectedBeagleGenotype(beagleAlleles.get(beaglePos).shortValue());
            }

         }
         else {
            it.remove();
            countRemoved++;
         }
      }
      System.out.println("Removed " + countRemoved + " out of " + totalPositions + " positions from Beagle genotypes file because could not find corresponding SNP in HDalles and vcf files");
      System.out.println("Seq alleles matching beagle Pos " + seqAllsCount);
      System.out.println("HD alleles matching beagle Pos " + hdAllsCount);
      System.out.println("Count loci where Beagle genotype reversed to match VCF genotypes " + correctedAlleles);
   }

   private void getRefAndAltAlleles(String positionsFile) {
      String lib = p.getSampleNames().get(0);
      String outfile = chr + "vcf";
      String command = p.getVcftools() + "vcftools --gzvcf " + p.getVcfFile() + " --indv " + lib + " --positions " + positionsFile + " --chr " + chr + " --out " + outfile + " --recode";
      p.runVcfTools(command);
      String filename = outfile + ".recode.vcf";
      File file = new File(filename);
      seqRefAndAltAlleles = p.readVCFFile(file);
      p.deleteFile(outfile + ".recode.vcf");
   }

   private void writeLog(String outString) {
      BufferedWriter out = getOutputFile(hapsFile);
      try {
         out.write(outString);
         out.newLine();
         out.flush();
         out.close();
      }
      catch (IOException ex) {
         ex.printStackTrace();
      }
   }

   private BufferedWriter getOutputFile(String filename) {
      BufferedWriter analysisFile = null;
      File file = new File(filename);
      try {
         FileWriter fstream = new FileWriter(file, true);
         analysisFile = new BufferedWriter(fstream);
      }
      catch (IOException e) {
         System.out.println("IOException : " + e);
      }
      return analysisFile;
   }

   private void writeVcfPosition(String filename) {
      BufferedWriter out = getOutputFile(filename);

      try {
         for (Integer pos : beagleAlleles.keySet()) {
            out.write(chr + "\t" + pos);
            out.newLine();
         }
         out.flush();
         out.close();

      }
      catch (IOException ex) {
         ex.printStackTrace();
      }

   }

   private HashMap<String, Double> getSwitchErrorDist(String snpDiff) {
      Integer count = snpDiff.length();
      Double endErrors = 0.0;
      HashMap<String, Double> ret = new HashMap<String, Double>();
      int length = snpDiff.length();
      for (int i = 0; i < length - 1; i += 2) {

         if (snpDiff.charAt(i) != snpDiff.charAt(i + 1)) {
            if (i == 0) {
               count--;
               endErrors++;
            }
            else if (i < length - 2) {
               if ((snpDiff.charAt(i + 1) != snpDiff.charAt(i + 2) ||
                     snpDiff.charAt(i) != snpDiff.charAt(i - 1))) {
                  count--;
               }
            }
            else if (i == length - 2) {
               count--;
               endErrors++;
            }
         }
      }
      Double frac = (1.0 * count) / length;
      ret.put("frac", frac);
      ret.put("terminalErrors", endErrors);
      return ret;

   }
}
