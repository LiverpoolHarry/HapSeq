/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package validatehaplotypes;
/*
 * from http://stackoverflow.com/questions/3008043/list-all-files-from-directories-and-subdirectories-in-java
 * Utility class for handling files
 * Gets a list of gff3 files in each sub directory
 */


/**
 *
 * @author harry
 */
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class GetFiles {

   static int spc_count = -1;
   private String fileType;//eg gff3 or bed
    private Params p;

   public GetFiles(Params p) {
      this.p = p;
      //aFile is an empty file in the path specified in the command line
      this.fileType = "gff3";
    }



    public File[] readFile() {
       ArrayList<File> files = new ArrayList<File>();

      try {
         // Open the file that is the first
         // command line parameter
         FileInputStream fstream = new FileInputStream(p.getFileList());
         // Get the object of DataInputStream
         DataInputStream in = new DataInputStream(fstream);
         BufferedReader br = new BufferedReader(new InputStreamReader(in));
         String strLine;
           //Read File Line By Line
         while ((strLine = br.readLine()) != null) {
           files.add(new File(strLine));
         }
         //Close the input stream
         in.close();
      }
      catch (Exception e) {//Catch exception if any
         System.err.println("Error in params.readFile(): " + e.getMessage());
         e.printStackTrace();
      }
       File[] infile = new File[files.size()];
       for(int i = 0; i < files.size(); i++){
          infile[i] = files.get(i);
       }
      return infile;
   }
 }

